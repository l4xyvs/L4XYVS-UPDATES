/* L4XYVS SUITE - Auto Tracker (L4XY_SUITE se, logic same). HTML ids: prog/log/btnCancel -> trk* (caption ke ids se takrao na ho) */
(function () {
  if (typeof require !== 'function' || !window.__adobe_cep__) return;   // L4XYVS: Auto Tracker sirf AE panel (node on) mein chalta hai
  var fs = require('fs'), path = require('path'), cp = require('child_process'), os = require('os');
  var https = require('https'), crypto = require('crypto'), zlib = require('zlib'), urlMod = require('url');
  var cep = window.__adobe_cep__;
  function $(id) { return document.getElementById(id); }

  // ---------- paths ----------
  function sysPath(type) { return decodeURI(cep.getSystemPath(type)).replace(/^file:\/\/\//, ''); }
  var extPath = sysPath('extension');
  var exe = path.join(extPath, 'bin', 'l4_tracker.exe');
  var work = path.join(process.env.APPDATA || os.tmpdir(), 'L4AutoTracker');   // purana cache chalta rahe
  var cacheDir = path.join(work, 'cache');
  try { fs.mkdirSync(cacheDir, { recursive: true }); } catch (e) {}

  // ---------- fixed settings (panel mein nahi dikhte) ----------
  var CFG = {
    smooth: 75, maxLost: 3, center: true, zoom: false, output: 'position', noCache: false,
    tracker: true,    // face detection + appearance tracker (helmet/topi/chasma). false = sirf face detection (purana)
    fit: true,        // layer ka FIXED scale (jitna zaroori utna, 100%..110%, scale keyframes nahi). Face X aur Y dono mein poora follow hota hai
    zoomMin: 1.0,     // kam se kam 100% (zaroorat na ho toh zoom nahi)
    zoomMax: 1.10,    // zyada se zyada +10%
    tileBudget: 0,    // 0 = tile bilkul nahi dikhega, scale utna badhega jitna zaroori (Alvar jaisa). Thoda tile chalega toh 0.01 try karo (zoom kam)
    polish: 0.1,      // extra zero-lag smoothing (seconds)
    pipe: { enable: true, trimStart: 3, trimEnd: 3, blend: 'pixel', mblur: true }
  };

  // ---------- helpers ----------
  function log(s) { var l = $('trkLog'); l.textContent += s + '\n'; l.scrollTop = l.scrollHeight; }
  function status(s, cls) { var e = $('trkStatus'); e.textContent = s; e.className = cls || ''; }
  function evalS(code) { return new Promise(function (res) { cep.evalScript(code, res); }); }
  function parse(s) { try { return JSON.parse(s); } catch (e) { return null; } }
  function setBar(p) { $('trkProgFill').style.width = Math.max(0, Math.min(100, p)) + '%'; }

  // ---------- progress bar (elapsed timer ke saath) ----------
  var timer = null, t0 = 0, progMsg = '';
  function fmt(s) { return Math.floor(s / 60) + ':' + ('0' + (s % 60)).slice(-2); }
  function tick() { $('trkProgTxt').textContent = progMsg + '  \u00b7  ' + fmt(Math.floor((Date.now() - t0) / 1000)) + ' elapsed'; }
  function progStart(msg, indeterminate) {
    progMsg = msg; t0 = Date.now();
    $('trkProg').className = indeterminate ? 'ind' : '';
    $('trkProg').style.display = 'flex'; $('trkProgFill').style.width = indeterminate ? '' : '0%';
    clearInterval(timer); timer = setInterval(tick, 500); tick();
  }
  function progMsgSet(m) { progMsg = m; tick(); }
  function progStop() { clearInterval(timer); timer = null; $('trkProg').style.display = 'none'; }

  // ---------- review toggle ----------
  try { $('chkReview').checked = localStorage.getItem('l4xy_review') !== '0'; } catch (e) {}
  $('chkReview').addEventListener('change', function () { try { localStorage.setItem('l4xy_review', this.checked ? '1' : '0'); } catch (e) {} });

  // ---------- motion (Both / X only / Y only) ----------
  var motion = 'both';
  try { motion = localStorage.getItem('l4xy_motion') || 'both'; } catch (e) {}
  function setMotion(m) {
    motion = m;
    var bs = $('motion').querySelectorAll('button');
    for (var i = 0; i < bs.length; i++) bs[i].className = (bs[i].getAttribute('data-v') === m) ? 'on' : '';
    try { localStorage.setItem('l4xy_motion', m); } catch (e) {}
  }
  $('motion').addEventListener('click', function (ev) {
    var v = ev.target && ev.target.getAttribute && ev.target.getAttribute('data-v');
    if (v) setMotion(v);
  });
  setMotion(motion);

  // ---------- run exe ----------
  var proc = null;
  function runExe(args, onProgress) {
    return new Promise(function (resolve) {
      var out = '', err = '', lastErr = '', result = '', buf = '';
      var p;
      try { p = cp.spawn(exe, args, { windowsHide: true }); }
      catch (e) { return resolve({ code: -1, error: 'exe chali nahi: ' + e.message }); }
      proc = p;
      p.on('error', function (e) { resolve({ code: -1, error: 'exe error: ' + e.message }); });
      p.stdout.on('data', function (d) {
        buf += d.toString('utf8');
        var lines = buf.split(/\r?\n/); buf = lines.pop();
        lines.forEach(function (ln) {
          if (ln.indexOf('PROGRESS ') === 0) {
            var m = /^PROGRESS (\d+) ?(.*)$/.exec(ln);
            if (m && onProgress) onProgress(parseInt(m[1], 10), m[2]);
          } else if (ln.indexOf('RESULT ') === 0) result = ln.substr(7);
          else if (ln.indexOf('ERROR ') === 0) lastErr = ln.substr(6);
        });
      });
      p.stderr.on('data', function (d) { err += d.toString('utf8'); });
      p.on('close', function (code) {
        proc = null;
        resolve({ code: code, result: result, error: lastErr || (code !== 0 ? err.slice(-400) : ''), cancelled: p._cancelled });
      });
    });
  }

  // ---------- state ----------
  // layers = selected layers (queue), qi = abhi kaunsi layer ka "shot" pick ho raha hai, picks = ho chuke picks
  // anchors = [{t, box, manual}] (is shot ke), rin/rout = tracking range (source seconds), tmin/tmax = layer span
var state = { info: null, faces: null, sel: null, busy: false, t: 0, layers: [], qi: 0, picks: [], cancelAll: false,
                anchors: [], rin: 0, rout: 0, tmin: 0, tmax: 1, curAnc: -1 };

  function setBusy(b) {
    state.busy = b;
    $('btnStart').disabled = b;
    $('btnDone').disabled = b || state.anchors.length === 0;
  }
  function showIdle() {
    $('pickWrap').style.display = 'none'; $('revWrap').style.display = 'none'; $('drop').style.display = '';
    $('btnSkip').style.display = 'none';
    state.fixResolve = null; rev = null;
    state.layers = []; state.picks = []; state.qi = 0; state.anchors = [];
    setBusy(false);
  }

  function renderFaces() {
    var f = state.faces, W = f.width, H = f.height;
    $('img').src = encodeURI('file:///' + path.join(work, 'prev.jpg').replace(/\\/g, '/')) + '?t=' + Date.now();
    var holder = $('boxes'); holder.innerHTML = '';
    f.faces.forEach(function (face) {
      var d = document.createElement('div');
      d.className = 'box';
      d.style.left = (face.box[0] / W * 100) + '%';
      d.style.top = (face.box[1] / H * 100) + '%';
      d.style.width = (face.box[2] / W * 100) + '%';
      d.style.height = (face.box[3] / H * 100) + '%';
      d.title = 'Face ' + face.id;
      d.onclick = function () { if (!state.busy) { state.sel = face.id; onPick(face); } };
      holder.appendChild(d);
    });
    $('selTxt').textContent = f.faces.length ? f.faces.length + (f.faces.length === 1 ? ' face' : ' faces') : 'no face here';
    $('drop').style.display = 'none'; $('pickWrap').style.display = 'block';
  }

  // ---------- timeline: range (In/Out) + anchors + playhead ----------
  function fpsOf() { return (state.faces && state.faces.fps) || 30; }
  function ancAt(t) {                                   // t ke paas (aadhe frame ke andar) wala anchor ka index, warna -1
    var tol = 0.51 / fpsOf(), i;
    for (i = 0; i < state.anchors.length; i++) if (Math.abs(state.anchors[i].t - t) <= tol) return i;
    return -1;
  }
  function tl2x(t) { var sp = Math.max(1e-6, state.tmax - state.tmin); return Math.max(0, Math.min(1, (t - state.tmin) / sp)) * 100 + '%'; }
  function x2tl(ev) {
    var r = $('tlbar').getBoundingClientRect();
    var f = Math.max(0, Math.min(1, (ev.clientX - r.left) / Math.max(1, r.width)));
    return state.tmin + f * (state.tmax - state.tmin);
  }
  function fmtT(t) { return t.toFixed(2) + 's'; }
  function renderTl() {
    if (!state.info) return;
    var a = $('tlrange').style; a.left = tl2x(state.rin); a.width = (parseFloat(tl2x(state.rout)) - parseFloat(tl2x(state.rin))) + '%';
    $('hIn').style.left = tl2x(state.rin); $('hOut').style.left = tl2x(state.rout);
    $('tlplay').style.left = tl2x(state.t);
    var holder = $('tlancs'); holder.innerHTML = '';
    var cur = ancAt(state.t); state.curAnc = cur;
    state.anchors.forEach(function (an, i) {
      var d = document.createElement('div');
      d.className = 'anc' + (i === cur ? ' cur' : ''); d.style.left = tl2x(an.t); d.title = 'Anchor ' + (i + 1) + ' @ ' + fmtT(an.t);
      d.setAttribute('data-i', i);
      holder.appendChild(d);
    });
    $('btnRemAnc').style.display = cur >= 0 ? '' : 'none';
    $('btnDone').disabled = state.busy || state.anchors.length === 0;
  }
  function renderAncBox() {
    var holder = $('boxes'), old = holder.querySelectorAll('.ancbox'), i;
    for (i = 0; i < old.length; i++) holder.removeChild(old[i]);
    var k = ancAt(state.t);
    if (k < 0 || !state.faces) return;
    var b = state.anchors[k].box, W = state.faces.width, H = state.faces.height, d = document.createElement('div');
    d.className = 'ancbox';
    d.style.left = (b[0] / W * 100) + '%'; d.style.top = (b[1] / H * 100) + '%';
    d.style.width = (b[2] / W * 100) + '%'; d.style.height = (b[3] / H * 100) + '%';
    holder.appendChild(d);
  }
  function momentLabel() {
    var n = state.anchors.length;
    $('momentTxt').textContent = 'Moment ' + fmtT(state.t) + '  \u00b7  Range ' + fmtT(state.rin) + ' \u2013 ' + fmtT(state.rout) +
      '  \u00b7  ' + n + (n === 1 ? ' anchor' : ' anchors');
    renderTl(); renderAncBox();
  }
  function clampT(t) { return Math.max(state.tmin, Math.min(state.tmax - 0.05, t)); }
  function anchorLimits() {                              // range handles anchors ke andar nahi ja sakte
    var lo = Infinity, hi = -Infinity;
    state.anchors.forEach(function (an) { lo = Math.min(lo, an.t); hi = Math.max(hi, an.t); });
    return [lo, hi];
  }
  var tlDrag = null;
  $('tl').addEventListener('mousedown', function (ev) {
    if (state.busy || !state.faces || ev.button !== 0) return;
    ev.preventDefault();
    var id = ev.target && ev.target.id, cls = ev.target && ev.target.className || '';
    if (id === 'hIn' || id === 'hOut') tlDrag = { kind: id };
    else if (typeof cls === 'string' && cls.indexOf('anc') === 0) {
      var an = state.anchors[parseInt(ev.target.getAttribute('data-i'), 10)];
      tlDrag = { kind: 'play', t0: state.t }; state.t = an.t; momentLabel();
    } else { tlDrag = { kind: 'play', t0: state.t }; state.t = clampT(x2tl(ev)); momentLabel(); }
    document.addEventListener('mousemove', onTlMove); document.addEventListener('mouseup', onTlUp);
  });
  function onTlMove(ev) {
    if (!tlDrag) return;
    var t = x2tl(ev), lim = anchorLimits(), minLen = 0.2;
    if (tlDrag.kind === 'play') { state.t = clampT(t); }
    else if (tlDrag.kind === 'hIn') state.rin = Math.max(state.tmin, Math.min(t, state.rout - minLen, lim[0]));
    else state.rout = Math.min(state.tmax, Math.max(t, state.rin + minLen, lim[1]));
    momentLabel();
  }
  async function onTlUp() {
    document.removeEventListener('mousemove', onTlMove); document.removeEventListener('mouseup', onTlUp);
    var d = tlDrag; tlDrag = null; if (!d) return;
    if (d.kind === 'play' && Math.abs(state.t - d.t0) > 0.5 / fpsOf()) await goTo(state.t, d.t0);
  }
  async function goTo(t, prevT) {                        // playhead naye moment par: preview + faces dobara
    if (state.busy || !state.info) return;
    setBusy(true);
    var r = await detectAt(clampT(t));
    setBusy(false);
    if (r === 'ok') { var h = faceHint(); status(h[0], h[1]); return; }
    // detect fail/cancel: session (anchors, range, baaki layers ke picks) nahi tootna chahiye. Preview purane moment ka hi hai,
    // isliye playhead wapas wahin; user kisi aur moment par try kare ya Track dabaye.
    if (prevT !== undefined) state.t = prevT;
    momentLabel();
    if (r === 'cancel') status('Cancelled. Anchors safe hain, doosre moment par try karo ya Track dabao.', '');
  }
  $('btnRemAnc').onclick = function () {
    if (state.busy) return;
    var k = ancAt(state.t); if (k < 0) return;
    state.anchors.splice(k, 1); momentLabel();
    status(state.anchors.length ? 'Anchor hata diya.' : 'Koi anchor nahi. Face par click karo.', '');
  };
  $('btnResetRange').onclick = function () {
    if (state.busy) return;
    state.rin = state.tmin; state.rout = state.tmax; momentLabel();
  };
  function shotLabel() {
    var n = state.layers.length;
    $('shotTxt').textContent = (n > 1 ? 'Shot ' + (state.qi + 1) + ' of ' + n + '  \u00b7  ' : '') + state.info.layerName;
    $('btnSkip').style.display = n > 1 ? '' : 'none';
    $('btnDone').textContent = n > 1 ? (state.qi + 1 < n ? 'Next shot' : 'Track all') : 'Track';
  }
  function faceHint() {
    var multi = state.layers.length > 1;
    if (state.faces.faces.length) return ['Face par click karo (ya head par box kheencho) = anchor.', ''];
    return [multi ? 'Face nahi mila. Head par box kheencho / click karo, timeline hilao ya Skip shot dabao.'
                  : 'Face nahi mila. Head (helmet/topi) par box kheencho ya click karo, ya timeline doosre moment par le jao.', 'err'];
  }

  // ---------- free box / click: helmet, topi, ya jahan face detect na ho ----------
  var drag = null;
  function pvFrac(ev) {
    var r = $('pv').getBoundingClientRect();
    return { x: Math.min(1, Math.max(0, (ev.clientX - r.left) / r.width)), y: Math.min(1, Math.max(0, (ev.clientY - r.top) / r.height)), w: r.width, h: r.height };
  }
  function onDragMove(ev) {
    if (!drag) return;
    var f = pvFrac(ev); drag.x1 = f.x; drag.y1 = f.y;
    var st = drag.el.style;
    st.left = (Math.min(drag.x0, drag.x1) * 100) + '%'; st.top = (Math.min(drag.y0, drag.y1) * 100) + '%';
    st.width = (Math.abs(drag.x1 - drag.x0) * 100) + '%'; st.height = (Math.abs(drag.y1 - drag.y0) * 100) + '%';
  }
  function onDragEnd(ev) {
    document.removeEventListener('mousemove', onDragMove); document.removeEventListener('mouseup', onDragEnd);
    var d = drag; drag = null; if (!d) return;
    if (d.el.parentNode) d.el.parentNode.removeChild(d.el);
    var f = pvFrac(ev); d.x1 = f.x; d.y1 = f.y;
    var W = state.faces.width, H = state.faces.height, x, y, w, h;
    var pw = Math.abs(d.x1 - d.x0) * f.w, ph = Math.abs(d.y1 - d.y0) * f.h;
    if (pw < 8 && ph < 8) { h = 0.2 * H; w = h; x = d.x1 * W - w / 2; y = d.y1 * H - h / 2; }   // sirf click: frame height ka 20% ka box
    else { x = Math.min(d.x0, d.x1) * W; y = Math.min(d.y0, d.y1) * H; w = Math.abs(d.x1 - d.x0) * W; h = Math.abs(d.y1 - d.y0) * H; }
    w = Math.max(16, Math.min(w, W)); h = Math.max(16, Math.min(h, H));
    x = Math.max(0, Math.min(x, W - w)); y = Math.max(0, Math.min(y, H - h));
    onPick({ id: 0, box: [x, y, w, h], manual: true });
  }
  $('pv').addEventListener('mousedown', function (ev) {
    if (state.busy || !state.faces || ev.button !== 0) return;
    if (ev.target && ev.target.className === 'box') return;       // face box ka apna click hai
    ev.preventDefault();
    var f = pvFrac(ev);
    drag = { x0: f.x, y0: f.y, x1: f.x, y1: f.y, el: document.createElement('div') };
    drag.el.className = 'draw'; $('boxes').appendChild(drag.el);
    document.addEventListener('mousemove', onDragMove); document.addEventListener('mouseup', onDragEnd);
  });
  $('img').ondragstart = function (e) { e.preventDefault(); };

  // ---------- face detect (given moment par) ----------
  async function detectAt(t) {
    progStart('Finding faces...', true);
    var prev = path.join(work, 'prev.jpg');
    var r = await runExe(['detect', '--video', state.info.file, '--time', String(t), '--out', prev]);
    progStop();
    if (r.cancelled) return 'cancel';
    if (r.code !== 0) { log(r.error || ''); status('Detect fail: ' + (r.error || 'unknown'), 'err'); return 'fail'; }
    var faces = null;
    try { faces = parse(fs.readFileSync(path.join(work, 'prev.json'), 'utf8')); } catch (e) { faces = null; }
    if (!faces || !faces.faces) { log('prev.json padh nahi paya'); status('Detect result padh nahi paya', 'err'); return 'fail'; }
    state.faces = faces; state.t = t; state.sel = null;
    log('Detector: ' + faces.detector + ' | faces: ' + faces.faces.length);
    renderFaces(); momentLabel();
    return 'ok';
  }

  // queue ki state.qi wali layer ka shot dikhao (face detect + pick screen)
  async function showShot() {
    var info = state.layers[state.qi];
    state.info = info;
    state.tmin = info.sIn; state.tmax = Math.max(info.sIn + 0.1, info.sOut);
    state.rin = state.tmin; state.rout = state.tmax; state.anchors = [];
    setBusy(true);
    var r = await detectAt(info.sFace);
    setBusy(false);
    if (r !== 'ok') return r;
    shotLabel(); momentLabel();
    var h = faceHint(); status(h[0], h[1]);
    return 'ok';
  }

  // current shot ho gaya (pick ya skip) -> agla shot, ya sab ho gaye toh batch
  async function advance() {
    for (;;) {
      state.qi++;
      if (state.qi >= state.layers.length) return finishPicking();
      var r = await showShot();
      if (r === 'ok') return;
      if (r === 'cancel') { showIdle(); return status('Cancelled.'); }
      log('Shot skip (detect fail): ' + state.layers[state.qi].layerName);
    }
  }
  function finishPicking() {
    if (state.picks.length === 0) { showIdle(); return status('Koi layer track nahi hui (sab skip).'); }
    return runBatch();
  }
  // click/box = is moment par anchor (replace agar wahi frame par pehle se hai). Range anchors ko cover karne ke liye badh jaati hai.
  function onPick(face) {
    if (state.busy) return;
    var t = state.t, k = ancAt(t), an = { t: t, box: face.box.slice(), manual: !!face.manual };
    if (k >= 0) state.anchors[k] = an; else state.anchors.push(an);
    state.anchors.sort(function (x, y) { return x.t - y.t; });
    state.rin = Math.min(state.rin, t); state.rout = Math.max(state.rout, Math.min(state.tmax, t + 0.05));
    momentLabel();
    var n = state.anchors.length;
    status('Anchor ' + fmtT(t) + ' (' + n + '). ' + (n === 1 ? 'Kaafi hai toh Track dabao, ya galat jagah par aur anchor daalo.' : 'Aur anchor daalo ya Track dabao.'), 'ok');
  }
  $('btnDone').onclick = function () {
    if (state.busy || state.anchors.length === 0) return;
    var an = state.anchors;
    if (state.fixResolve) {                                  // review se "Fix here": isi layer ko naye anchors se dobara track
      var fp = state.fixPk;
      fp.anchors = an.slice(); fp.rin = state.rin; fp.rout = state.rout; fp.seedTime = an[0].t;
      $('pickWrap').style.display = 'none'; setBusy(true);
      return state.fixResolve('tracked');
    }
    state.picks.push({ info: state.info, anchors: an.slice(), rin: state.rin, rout: state.rout, seedTime: an[0].t });
    setBusy(true);
    advance();
  };

  // ---------- engine (bin + models) auto-download: GitHub Release se, SHA-256 + signature check ----------
  var ENGINE_FEED = 'https://raw.githubusercontent.com/l4xyvs/L4XYVS-UPDATES/main/engine.json';
  var EHOSTS = ['raw.githubusercontent.com', 'github.com', 'objects.githubusercontent.com', 'release-assets.githubusercontent.com'];
  var engineChecked = false;
  function engVer() {
    try { return parseInt(JSON.parse(fs.readFileSync(path.join(extPath, 'bin', 'engine_version.json'), 'utf8').replace(/^\uFEFF/, '')).version, 10) || 0; } catch (e) { return 0; }
  }
  function eGet(u, maxBytes, onProg) {
    return new Promise(function (resolve, reject) {
      var hops = 0;
      (function go(x) {
        var p = urlMod.parse(x);
        if (p.protocol !== 'https:') return reject(new Error('Blocked non-HTTPS address'));
        if (EHOSTS.indexOf(p.hostname) < 0) return reject(new Error('Blocked host: ' + p.hostname));
        var req = https.get({ hostname: p.hostname, port: p.port, path: p.path, headers: { 'User-Agent': 'L4XYVS-Engine', 'Cache-Control': 'no-cache' } }, function (res) {
          if ([301, 302, 303, 307, 308].indexOf(res.statusCode) >= 0 && res.headers.location) {
            res.resume(); if (++hops > 6) return reject(new Error('Too many redirects'));
            return go(urlMod.resolve(x, res.headers.location));
          }
          if (res.statusCode !== 200) { res.resume(); return reject(new Error('Server replied HTTP ' + res.statusCode)); }
          var total = +res.headers['content-length'] || 0, got = 0, chunks = [];
          res.on('data', function (c) {
            got += c.length; if (got > maxBytes) { req.abort(); return reject(new Error('Download too large')); }
            chunks.push(c); if (onProg && total) onProg(Math.min(1, got / total), got);
          });
          res.on('end', function () { resolve(Buffer.concat(chunks)); });
          res.on('error', reject);
        });
        req.setTimeout(30000, function () { req.abort(); reject(new Error('Connection timed out')); });
        req.on('error', reject);
      })(u);
    });
  }
  function eZip(buf) {                                   // minimal zip reader (central directory), sirf bin/ aur models/ allowed
    var min = Math.max(0, buf.length - 22 - 65535), i = buf.length - 22, out = [], n, p;
    for (; i >= min; i--) if (buf.readUInt32LE(i) === 0x06054b50) break;
    if (i < min) throw new Error('Package is not a valid zip');
    var count = buf.readUInt16LE(i + 10); p = buf.readUInt32LE(i + 16);
    for (n = 0; n < count; n++) {
      if (buf.readUInt32LE(p) !== 0x02014b50) throw new Error('Corrupt zip directory');
      var nl = buf.readUInt16LE(p + 28), el = buf.readUInt16LE(p + 30), cl = buf.readUInt16LE(p + 32);
      var e = { method: buf.readUInt16LE(p + 10), csize: buf.readUInt32LE(p + 20), usize: buf.readUInt32LE(p + 24), lho: buf.readUInt32LE(p + 42), name: buf.toString('utf8', p + 46, p + 46 + nl).replace(/\\/g, '/') };
      if (e.csize === 0xFFFFFFFF || e.usize === 0xFFFFFFFF || e.lho === 0xFFFFFFFF) throw new Error('Zip64 packages are not supported');
      p += 46 + nl + el + cl;
      if (e.name.slice(-1) === '/') continue;
      if (!/^(bin|models)\/[A-Za-z0-9_.\-]+$/.test(e.name) || e.name.indexOf('..') >= 0) throw new Error('Unexpected file in engine package: ' + e.name);
      var l = e.lho; if (buf.readUInt32LE(l) !== 0x04034b50) throw new Error('Corrupt zip entry');
      var s = l + 30 + buf.readUInt16LE(l + 26) + buf.readUInt16LE(l + 28), raw = buf.slice(s, s + e.csize);
      e.data = e.method === 0 ? raw : e.method === 8 ? zlib.inflateRawSync(raw) : null;
      if (!e.data || e.data.length !== e.usize) throw new Error('Bad zip entry: ' + e.name);
      out.push(e);
    }
    return out;
  }
  async function installEngine(feed) {
    var keyFile = path.join(extPath, 'updater_pubkey.pem'), key = '';
    try { key = fs.readFileSync(keyFile, 'utf8'); } catch (e) { key = ''; }
    if (!/BEGIN PUBLIC KEY/.test(key)) throw new Error('updater_pubkey.pem nahi mili, engine download band');
    var sha = String(feed.sha256 || '').toLowerCase();
    if (!/^[0-9a-f]{64}$/.test(sha) || !feed.signature || !feed.packageUrl) throw new Error('engine.json adhoora hai');
    progStart('Tracker engine download ho raha hai...', false);
    var buf = await eGet(feed.packageUrl, 400 * 1024 * 1024, function (f, got) { setBar(f * 80); progMsgSet('Tracker engine download: ' + Math.round(got / 1048576) + ' MB'); });
    progMsgSet('Verify ho raha hai...'); setBar(85);
    if (crypto.createHash('sha256').update(buf).digest('hex') !== sha) throw new Error('Download corrupt (checksum mismatch)');
    var ok = false;
    try { ok = crypto.createVerify('RSA-SHA256').update('L4XYVS-ENGINE|' + feed.version + '|' + sha).verify(key, String(feed.signature), 'base64'); } catch (e) { ok = false; }
    if (!ok) throw new Error('Signature check fail, engine reject');
    var files = eZip(buf);
    if (!files.some(function (f) { return f.name === 'bin/l4_tracker.exe'; })) throw new Error('Package mein l4_tracker.exe nahi hai');
    progMsgSet('Install ho raha hai...'); setBar(92);
    var done = [];
    try {
      files.forEach(function (f) {
        var target = path.join(extPath, f.name), tmp = target + '.l4new';
        fs.mkdirSync(path.dirname(target), { recursive: true });
        var bak = null; if (fs.existsSync(target)) { bak = target + '.l4old'; try { fs.unlinkSync(bak); } catch (e0) {} fs.renameSync(target, bak); }
        fs.writeFileSync(tmp, f.data); fs.renameSync(tmp, target); done.push({ target: target, bak: bak });
      });
      fs.writeFileSync(path.join(extPath, 'bin', 'engine_version.json'), JSON.stringify({ version: feed.version }));
    } catch (err) {
      done.forEach(function (d) { try { fs.unlinkSync(d.target); if (d.bak) fs.renameSync(d.bak, d.target); } catch (e2) {} });
      throw new Error('Install fail (exe chal rahi ho toh band karo): ' + err.message);
    }
    done.forEach(function (d) { if (d.bak) { try { fs.unlinkSync(d.bak); } catch (e3) {} } });
    log('Engine v' + feed.version + ' install ho gaya (' + files.length + ' files)');
  }
  async function ensureEngine() {
    var have = fs.existsSync(exe);
    if (have && engineChecked) return { ok: true };
    setBusy(true); status('Engine check ho raha hai...', '');
    try {
      var feed = null;
      try { feed = JSON.parse((await eGet(ENGINE_FEED + '?t=' + Date.now(), 200000)).toString('utf8').replace(/^\uFEFF/, '')); }
      catch (e) { if (have) { engineChecked = true; return { ok: true }; } return { ok: false, msg: 'Tracker engine nahi hai aur download nahi ho paya: ' + e.message }; }
      engineChecked = true;
      if (!feed || feed.product !== 'L4XYVS ENGINE' || !(parseInt(feed.version, 10) > 0)) {
        return have ? { ok: true } : { ok: false, msg: 'Engine feed galat hai. Developer se engine publish karwao.' };
      }
      feed.version = parseInt(feed.version, 10);
      if (have && feed.version <= engVer()) return { ok: true };
      await installEngine(feed);
      return { ok: true };
    } catch (e) {
      log('Engine: ' + e.message);
      return fs.existsSync(exe) ? { ok: true } : { ok: false, msg: 'Engine install fail: ' + e.message };
    } finally { progStop(); setBusy(false); status('', ''); }
  }

  // ---------- Start tracking ----------
  $('btnStart').onclick = async function () {
    if (state.busy) return;
    var er = await ensureEngine();
    if (!er.ok) return status(er.msg, 'err');
    if (!fs.existsSync(exe)) return status('l4_tracker.exe nahi mili: ' + exe, 'err');
    setBusy(true); status(''); state.cancelAll = false;
    var info = parse(await evalS('l4_info()'));
    if (!info || info.error) { setBusy(false); return status(info ? info.error : 'AE se jawab nahi aaya', 'err'); }
    (info.skipped || []).forEach(function (w) { log('Layer skip: ' + w.name + ' - ' + w.reason); });
    state.compId = info.compId; state.layers = info.layers; state.qi = 0; state.picks = [];
    log('Layers: ' + info.layers.map(function (l) { return l.layerName; }).join(', '));
    var r = await showShot();
    if (r !== 'ok') { showIdle(); if (r === 'cancel') status('Cancelled.'); return; }
  };

  $('btnSkip').onclick = function () { if (state.busy) return; setBusy(true); advance(); };
  $('btnCancelPick').onclick = function () {
    if (state.busy) return;
    if (state.fixResolve) { $('pickWrap').style.display = 'none'; setBusy(true); return state.fixResolve('back'); }
    showIdle(); status('');
  };
  $('trkCancel').onclick = function () { state.cancelAll = true; if (proc) { proc._cancelled = true; try { proc.kill(); } catch (e) {} } };

  // ---------- review screen: confidence bar + preview + fix ----------
  var rev = null;            // {tr, pv, dir, cls, cur, resolve, t}
  var CLS_COL = ['#ff5a67', '#ff5a67', '#ff9a3c', '#e5b93c', '#4fcf70'];
  var CLS_TXT = ['lost', 'tracks disagree (jump/drift?)', 'shaky', 'tracker', 'face detect'];
  function classify(tr) {
    var n = tr.points.length, c = new Array(n), src = tr.source || [], dis = tr.disagree || [], meas = tr.measured || [], i;
    for (i = 0; i < n; i++) {
      if (meas[i] === 0) c[i] = 0;
      else if (dis[i] > 0.5) c[i] = 1;
      else if (dis[i] > 0.25) c[i] = 2;
      else c[i] = src[i] === 2 ? 4 : 3;
    }
    return c;
  }
  // laal/narangi nahi, sirf bharosa-kam hisse: lost ya fwd/bwd bahut farak, kam se kam 3 frames. Return [{t0, t1, label, lost}]
  function issueRuns(tr) {
    var c = classify(tr), n = c.length, out = [], i = 0, j, k, lost;
    while (i < n) {
      if (c[i] > 1) { i++; continue; }
      j = i; lost = false;
      while (j < n && c[j] <= 1) { if (c[j] === 0) lost = true; j++; }
      if (j - i >= 3) out.push({ t0: tr.start + i / tr.fps, t1: tr.start + j / tr.fps, label: lost ? 'L4: face hidden / lost' : 'L4: check tracking', lost: lost });
      i = j;
    }
    return out;
  }
  function runsTxt(runs, lostOnly) {
    return runs.filter(function (r) { return !lostOnly || r.lost; }).map(function (r) { return r.t0.toFixed(1) + '-' + r.t1.toFixed(1) + 's'; }).join(', ');
  }
  function revFrameT(i) { return rev.tr.start + i / rev.tr.fps; }
  function revTx(i) { return (i + 0.5) / Math.max(1, rev.tr.points.length) * 100; }
  function drawConf() {
    var cv = $('confc'), w = Math.max(10, $('conf').clientWidth), n = rev.cls.length, x, ctx, i;
    cv.width = w; ctx = cv.getContext('2d');
    for (x = 0; x < w; x++) {
      i = Math.min(n - 1, Math.floor(x / w * n));
      ctx.fillStyle = CLS_COL[rev.cls[i]]; ctx.fillRect(x, 0, 1, cv.height);
    }
    var holder = $('confancs'); holder.innerHTML = '';
    (rev.tr.anchors || []).forEach(function (a) {
      var j = Math.round((a.t - rev.tr.start) * rev.tr.fps), d = document.createElement('div');
      d.style.left = revTx(Math.max(0, Math.min(n - 1, j))) + '%'; holder.appendChild(d);
    });
  }
  function showRev(i) {
    var tr = rev.tr, n = tr.points.length;
    i = Math.max(0, Math.min(n - 1, i)); rev.cur = i; rev.t = revFrameT(i);
    var fi = Math.min(rev.pv.count - 1, Math.floor(i / rev.pv.stride));
    var name = rev.pv.files.replace('%05d', ('00000' + fi).slice(-5));
    $('rvimg').src = encodeURI('file:///' + path.join(rev.dir, name).replace(/\\/g, '/'));
    var p = tr.points[i], W = tr.width, H = tr.height, h = p[3], w = h * 0.85, b = $('rvbox').style, col = CLS_COL[rev.cls[i]];
    b.left = ((p[1] - w / 2) / W * 100) + '%'; b.top = ((p[2] - h / 2) / H * 100) + '%';
    b.width = (w / W * 100) + '%'; b.height = (h / H * 100) + '%'; b.borderColor = col;
    $('confplay').style.left = revTx(i) + '%';
    var dis = (tr.disagree || [])[i] || 0;
    $('revTxt').textContent = fmtT(rev.t) + '  ·  ' + CLS_TXT[rev.cls[i]] + (dis > 0 ? '  ·  fwd/bwd diff ' + Math.round(dis * 100) + '%' : '');
  }
  function revIssue(dir) {                                   // agla/pichla problem-segment ka shuru
    var c = rev.cls, n = c.length, i = rev.cur, bad = function (k) { return c[k] <= 2; };
    if (dir > 0) { while (i < n && bad(i)) i++; while (i < n && !bad(i)) i++; if (i >= n) return; }
    else { while (i >= 0 && bad(i)) i--; while (i >= 0 && !bad(i)) i--; if (i < 0) return; while (i > 0 && bad(i - 1)) i--; }
    showRev(i);
  }
  var confDrag = false;
  function confSeek(ev) {
    var r = $('confc').getBoundingClientRect(), f = Math.max(0, Math.min(1, (ev.clientX - r.left) / Math.max(1, r.width)));
    showRev(Math.floor(f * rev.cls.length));
  }
  $('conf').addEventListener('mousedown', function (ev) {
    if (!rev || ev.button !== 0) return; ev.preventDefault(); confDrag = true; confSeek(ev);
  });
  document.addEventListener('mousemove', function (ev) { if (confDrag && rev) confSeek(ev); });
  document.addEventListener('mouseup', function () { confDrag = false; });
  document.addEventListener('keydown', function (ev) {
    if (!rev || $('revWrap').style.display === 'none') return;
    if (ev.key === 'ArrowLeft') { showRev(rev.cur - (ev.shiftKey ? 10 : 1)); ev.preventDefault(); }
    else if (ev.key === 'ArrowRight') { showRev(rev.cur + (ev.shiftKey ? 10 : 1)); ev.preventDefault(); }
  });
  $('rvPrev').onclick = function () { if (rev) revIssue(-1); };
  $('rvNext').onclick = function () { if (rev) revIssue(1); };
  $('rvApply').onclick = function () { if (rev && rev.resolve) rev.resolve('apply'); };
  $('rvSkip').onclick = function () { if (rev && rev.resolve) rev.resolve('skip'); };
  $('rvFix').onclick = function () { if (rev && rev.resolve) rev.resolve('fix'); };

  async function ensurePreview(tr, info) {
    progStart('Preparing preview...', false);
    var r = await runExe(['preview', '--video', info.file, '--start', String(tr.start), '--end', String(tr.end),
      '--out-dir', path.join(cacheDir, 'preview'), '--max-w', '480', '--max-frames', '400'],
      function (p, msg) { setBar(p); progMsgSet('Preparing preview...  ' + (msg || '')); });
    progStop();
    if (r.cancelled || r.code !== 0 || !r.result) { log('Preview fail: ' + (r.error || '')); return null; }
    var pv = null;
    try { pv = parse(fs.readFileSync(r.result, 'utf8')); } catch (e) { pv = null; }
    if (!pv || !pv.count) return null;
    return { pv: pv, dir: path.dirname(r.result) };
  }

  // review: 'apply' | 'skip' | 'retrack' (fix ke baad naye anchors) | 'cancel'
  async function reviewLoop(pk, tr, i, n) {
    var pw = await ensurePreview(tr, pk.info);
    if (!pw) { log('Preview nahi bana: review skip, seedha apply.'); return 'apply'; }
    for (;;) {
      var act = await new Promise(function (res) {
        rev = { tr: tr, pv: pw.pv, dir: pw.dir, cls: classify(tr), cur: 0, t: tr.start, resolve: res };
        $('pickWrap').style.display = 'none'; $('drop').style.display = 'none'; $('revWrap').style.display = 'block';
        $('revShot').textContent = (n > 1 ? 'Shot ' + (i + 1) + ' of ' + n + '  ·  ' : '') + pk.info.layerName;
        var sc = tr.src_counts || {}, bad = rev.cls.filter(function (c) { return c <= 2; }).length;
        $('revSel').textContent = bad ? bad + ' issue frame' + (bad > 1 ? 's' : '') : 'looks good';
        $('rvNext').disabled = $('rvPrev').disabled = !bad;
        drawConf();
        var first = rev.cls.indexOf(0); if (first < 0) first = rev.cls.findIndex(function (c) { return c <= 2; });
        showRev(first >= 0 ? first : Math.min(rev.cls.length - 1, Math.round((tr.anchors && tr.anchors[0] ? (tr.anchors[0].t - tr.start) * tr.fps : 0))));
        var hid = runsTxt(issueRuns(tr), true);
        status((bad ? 'Review karo: laal/narangi hisse mein galti ho sakti hai. Scrub karo, galat ho toh Fix here.' : 'Sab theek lag raha hai? Scrub karke dekho, phir Apply.') + (hid ? '  Hidden: ' + hid : ''), bad ? 'err' : 'ok');
      });
      var t = rev.t;
      $('revWrap').style.display = 'none';
      if (act !== 'fix') { rev = null; return act; }
      // fix: usi moment par pick screen (purane anchors + range ke saath), phir dobara track
      var info = pk.info;
      state.fixPk = pk; state.info = info; state.layers = [info]; state.qi = 0;
      state.tmin = info.sIn; state.tmax = Math.max(info.sIn + 0.1, info.sOut);
      state.anchors = pk.anchors.map(function (a) { return { t: a.t, box: a.box.slice(), manual: !!a.manual }; });
      state.rin = pk.rin; state.rout = pk.rout;
      setBusy(true);
      var r = await detectAt(clampT(t));
      if (r !== 'ok') { setBusy(false); continue; }               // detect fail: review par wapas (busy flag chhodo)
      shotLabel(); momentLabel(); $('btnDone').textContent = 'Re-track';
      setBusy(false);
      status('Fix: galat jagah par sahi face/head par click karke anchor daalo (range bhi badal sakte ho), phir Re-track.', '');
      var fr = await new Promise(function (res) { state.fixResolve = function (v) { state.fixResolve = null; res(v); }; });
      if (fr === 'tracked') { rev = null; return 'retrack'; }
      // 'back': review par wapas (purana result)
    }
  }

  // ---------- ek layer: track (+ review) + apply ----------
  async function runTrackOnce(pk, i, n, tag, out) {
    var info = pk.info;
    var af = path.join(work, 'anchors_' + i + '.json');
    var rout = pk.rout;
    try {
      fs.writeFileSync(af, JSON.stringify(pk.anchors.map(function (a) { return { time: Math.min(a.t, rout - 0.001), box: a.box, manual: !!a.manual }; })));
    } catch (e) { return { error: 'anchors file likh nahi paya: ' + e.message }; }
    var args = ['track', '--video', info.file, '--start', String(pk.rin), '--end', String(rout),
      '--anchors', af, '--out', out,
      '--smooth', String(CFG.smooth / 100), '--max-lost', String(CFG.maxLost), '--cache-dir', cacheDir];
    if (CFG.noCache) args.push('--no-cache');
    if (!CFG.tracker) args.push('--mode', 'face');
    if (!timer) progStart(n > 1 ? 'Tracking ' + n + ' layers...' : 'Tracking...', false);
    progMsgSet(tag + 'Tracking...');
    var r = await runExe(args, function (p, msg) { setBar((i + p / 100 * 0.9) / n * 100); progMsgSet(tag + (msg || 'Tracking...')); });
    if (r.cancelled) return { cancelled: true };
    if (r.code !== 0) { log(r.error || ''); return { error: 'Track fail: ' + (r.error || 'unknown') }; }
    var tr = null;
    try { tr = parse(fs.readFileSync(out, 'utf8')); } catch (e) { tr = null; }
    if (!tr || !tr.points) return { error: 'Track result padh nahi paya' };
    if (tr.truncated) log(tag + 'WARNING: video sirf ' + tr.frames_read + ' frames (' + (tr.frames_read / tr.fps).toFixed(1) + ' s) padhi gayi, layer range ke ' + tr.frames_expected + ' frames the.');
    log(tag + info.layerName + ' | coverage ' + Math.round(tr.coverage * 100) + '% | lost segments: ' + JSON.stringify(tr.lost));
    if (tr.src_counts) {
      var sc = tr.src_counts, tot = Math.max(1, sc.detect + sc.tracker + sc.lost);
      log(tag + 'Source: detect ' + Math.round(sc.detect / tot * 100) + '% | tracker ' + Math.round(sc.tracker / tot * 100) + '% | lost ' + Math.round(sc.lost / tot * 100) + '%  (' + (tr.tracker || '?') + ')');
    }
    if (tr.identity) log(tag + 'Identity: ' + (tr.identity.sface ? 'SFace (gallery ' + tr.identity.gallery + ', tracker galat insaan par ' + tr.identity.wrong_tracker_frames + ' frames)' : 'histogram only' + (tr.identity.err ? ' (SFace error: ' + tr.identity.err + ')' : ' (models\\sface.onnx nahi mila, get_model.bat)')));
    var runsL = issueRuns(tr);
    if (runsL.length) log(tag + 'Low confidence: ' + runsL.map(function (r) { return (r.lost ? 'hidden ' : 'check ') + r.t0.toFixed(2) + '-' + r.t1.toFixed(2) + 's'; }).join(', '));
    if (tr.anchors) log(tag + 'Anchors: ' + tr.anchors.length + ' @ ' + tr.anchors.map(function (a) { return a.t.toFixed(2) + 's'; }).join(', ') + ' | range ' + tr.start.toFixed(2) + '-' + tr.end.toFixed(2) + 's');
    if (tr.disagree_stat && tr.anchors && tr.anchors.length > 1)
      log(tag + 'Blend: fwd/bwd disagree mean ' + Math.round(tr.disagree_stat.mean * 100) + '% | max ' + Math.round(tr.disagree_stat.max * 100) + '% @ ' + tr.disagree_stat.max_t.toFixed(2) + 's | bad frames ' + tr.disagree_stat.bad);
    (tr.warnings || []).forEach(function (w) { log(tag + 'WARN: ' + w); });
    if (tr.tracker === 'mil') log(tag + 'WARN: kamzor fallback tracker (MIL) chala. models\\vittrack.onnx nahi mila ya khula nahi - get_model.bat chalao. ' + (tr.tracker_err || ''));
    else if (tr.tracker === 'face-only' && CFG.tracker && tr.tracker_err) log(tag + 'Tip: ' + tr.tracker_err + ' (helmet/topi tracking ke liye)');
    return { tr: tr };
  }

  async function trackOne(pk, i, n) {
    var info = pk.info, tag = n > 1 ? '[' + (i + 1) + '/' + n + '] ' : '';
    var out = path.join(work, 'track_' + i + '.json');
    var tr = null;
    for (;;) {
      var r = await runTrackOnce(pk, i, n, tag, out);
      if (r.cancelled || r.error) return r;
      tr = r.tr;
      if (!$('chkReview').checked || state.cancelAll) break;
      var act = await reviewLoop(pk, tr, i, n);
      if (act === 'apply') break;
      if (act === 'skip') { log(tag + 'Skipped (review): ' + info.layerName); return { skipped: true }; }
      if (act === 'retrack') { log(tag + 'Re-track with ' + pk.anchors.length + ' anchors'); continue; }
      return { cancelled: true };
    }
    if (!timer) progStart('Applying...', false);
    progMsgSet(tag + 'Applying in After Effects...'); setBar((i + 0.92) / n * 100);
    var opts = {
      compId: state.compId, layerId: info.layerId, layerIndex: info.layerIndex, layerName: info.layerName, trackPath: out,
      center: CFG.center, zoom: CFG.zoom, output: CFG.output, axis: motion, pipe: CFG.pipe,
      fit: CFG.fit, zoomMin: CFG.zoomMin, zoomMax: CFG.zoomMax, tileBudget: CFG.tileBudget, polish: CFG.polish,
      markers: issueRuns(tr).map(function (r) { return { t0: r.t0, t1: r.t1, label: r.label }; })
    };
    var ap = parse(await evalS('l4_apply(' + JSON.stringify(JSON.stringify(opts)) + ')'));
    if (ap && ap.diag) log(tag + 'DIAG: ' + JSON.stringify(ap.diag));
    if (!ap || ap.error) return { error: ap ? ap.error : 'AE se jawab nahi aaya' };
    if (ap.warnings && ap.warnings.length) ap.warnings.forEach(function (w) { log(tag + 'WARN: ' + w); });
    if (ap.precomp) log(tag + 'Precomp: ' + ap.precomp);
    return { ok: true, keys: ap.keys, coverage: tr.coverage };
  }

  // ---------- batch: picks wali saari layers ek ke baad ek ----------
  async function runBatch() {
    var picks = state.picks, n = picks.length, i, res, done = [], failed = [], skippedL = [], cancelled = false, lowCov = [];
    state.cancelAll = false;
    $('pickWrap').style.display = 'none'; $('drop').style.display = '';
    setBusy(true); status('');
    progStart(n > 1 ? 'Tracking ' + n + ' layers...' : 'Tracking...', false);
    for (i = 0; i < n; i++) {
      if (state.cancelAll) { cancelled = true; break; }
      try { res = await trackOne(picks[i], i, n); }
      catch (e) { res = { error: 'Panel error: ' + (e && e.message ? e.message : e) }; }
      if (res.cancelled) { cancelled = true; break; }
      if (res.skipped) { skippedL.push(picks[i].info.layerName); continue; }
      if (res.error) { failed.push(picks[i].info.layerName); log('FAIL ' + picks[i].info.layerName + ': ' + res.error); continue; }
      done.push(picks[i].info.layerName);
      if (res.coverage < 0.6) lowCov.push(picks[i].info.layerName + ' ' + Math.round(res.coverage * 100) + '%');
    }
    progStop(); showIdle();
    var msg, cls = 'ok';
    if (n === 1 && skippedL.length === 1) return status('Skipped: layer par kuch apply nahi hua.', 'err');
    if (n === 1 && done.length === 1) {
      msg = 'Done: ' + res.keys + ' keyframes (' + motion.toUpperCase() + '). Coverage ' + Math.round(res.coverage * 100) + '%.';
      if (lowCov.length) { msg += ' (Dhyan: coverage kam hai, result check karo)'; cls = 'err'; }
      return status(msg, cls);
    }
    msg = 'Done: ' + done.length + '/' + n + ' layers (' + motion.toUpperCase() + ').';
    if (cancelled) { msg = 'Cancelled. ' + done.length + ' layer(s) ho chuki thi.'; cls = 'err'; }
    if (skippedL.length) msg += ' Skipped: ' + skippedL.join(', ') + '.';
    if (failed.length) { msg += ' Fail: ' + failed.join(', ') + ' (Details dekho).'; cls = 'err'; }
    if (lowCov.length) { msg += ' Coverage kam: ' + lowCov.join(', ') + '.'; cls = 'err'; }
    status(msg, cls);
  }

  log('Ready. exe: ' + exe + (fs.existsSync(exe) ? '' : '  (NAHI MILI)'));
})();
