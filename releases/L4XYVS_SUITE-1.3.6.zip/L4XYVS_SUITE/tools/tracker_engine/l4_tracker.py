#!/usr/bin/env python3
"""L4 AutoTracker engine (local, offline).

Subcommands
  detect : ek frame se faces nikaal ke numbered preview jpg + faces.json banata hai
  track  : anchors se poore range mein track karta hai (multi-anchor, Kalman + RTS smoother)
  preview: range ke low-res frames (jpg) + index.json, review screen mein turant scrub ke liye

stdout protocol (panel ke liye):
  PROGRESS <0-100> <msg>
  RESULT <json path>
  ERROR <msg>            (exit code 1)
"""
import argparse, hashlib, json, math, os, pickle, sys
import numpy as np
import cv2

ENGINE_VERSION = "1.1"            # 1.1: analysis mein SFace embeddings (cache invalidate)
TRACK_VERSION = "3.0"      # fusion + multi-anchor bidirectional blend ka version, track cache key mein
SCORE_MIN = 0.25           # tracker confidence isse kam ho toh frame "lost" maana jaata hai
ID_SAME = 0.363           # SFace cosine: isse upar = wahi insaan (OpenCV ka recommended threshold)
ID_REJECT = 0.20          # isse neeche = pakka koi aur insaan (us detection/tracker ko reject)
REINIT_EVERY = 15          # tracker ko itne frame baad detection par re-center karte hain (drift rokne ke liye)


# ----------------------------------------------------------------- utils
def say(kind, *a):
    print(kind, *a, flush=True)


def fail(msg):
    say("ERROR", msg)
    sys.exit(1)


def app_dir():
    if getattr(sys, "frozen", False):
        return os.path.dirname(sys.executable)
    return os.path.dirname(os.path.abspath(__file__))


def default_model():
    base = app_dir()
    for p in (os.path.join(base, "..", "models", "yunet.onnx"),
              os.path.join(base, "models", "yunet.onnx")):
        if os.path.isfile(p) and os.path.getsize(p) > 100000:
            return os.path.abspath(p)
    return ""


def default_tracker_model():
    base = app_dir()
    for p in (os.path.join(base, "..", "models", "vittrack.onnx"),
              os.path.join(base, "models", "vittrack.onnx")):
        if os.path.isfile(p) and os.path.getsize(p) > 100000:   # LFS pointer (chhoti file) reject
            return os.path.abspath(p)
    return ""


def default_sface_model():
    base = app_dir()
    for p in (os.path.join(base, "..", "models", "sface.onnx"),
              os.path.join(base, "models", "sface.onnx")):
        if os.path.isfile(p) and os.path.getsize(p) > 1000000:      # LFS pointer (chhoti file) reject
            return os.path.abspath(p)
    return ""


def sha(*parts):
    h = hashlib.sha1()
    for p in parts:
        h.update(str(p).encode("utf-8"))
        h.update(b"|")
    return h.hexdigest()[:20]


def atomic_write(path, data):
    """Pehle temp file, phir os.replace: process beech mein kill ho jaye (Cancel) toh adhoori/corrupt cache file nahi bachti."""
    d = os.path.dirname(os.path.abspath(path))
    os.makedirs(d, exist_ok=True)
    tmp = "%s.tmp%d" % (path, os.getpid())
    with open(tmp, "wb") as fh:
        fh.write(data if isinstance(data, bytes) else data.encode("utf-8"))
    os.replace(tmp, path)


def imwrite(path, img, params=None):
    """cv2.imwrite Windows par non-ASCII path (jaise Hindi username) par chupchaap fail hota hai; imencode + normal file write nahi."""
    try:
        ok, buf = cv2.imencode(os.path.splitext(path)[1] or ".jpg", img, params or [])
        if not ok:
            return False
        with open(path, "wb") as fh:
            fh.write(buf.tobytes())
        return True
    except Exception:
        return False


# -------------------------------------------------------------- detector
class Detector:
    """YuNet (ONNX) primary. Model na mile toh Haar fallback (kamzor, sirf backup).
    sface_path diya ho (aur YuNet chal raha ho) toh har face ka SFace embedding (128-d, L2-normalized) bhi nikalta hai."""

    def __init__(self, model_path, max_w=960, score=0.6, sface_path=""):
        self.max_w = max_w
        self.kind = "haar"
        self.yn = None
        self.rec = None
        self.rec_err = ""
        if model_path and os.path.isfile(model_path) and os.path.getsize(model_path) > 100000:
            self.yn = cv2.FaceDetectorYN.create(model_path, "", (320, 320), score, 0.3, 100)
            self.kind = "yunet"
            if sface_path and os.path.isfile(sface_path) and os.path.getsize(sface_path) > 1000000:
                try:
                    self.rec = cv2.FaceRecognizerSF.create(sface_path, "")
                except Exception as e:
                    self.rec = None
                    self.rec_err = str(e)[:160]
        else:
            self.haar = None
            try:
                self.haar = cv2.CascadeClassifier(
                    os.path.join(cv2.data.haarcascades, "haarcascade_frontalface_default.xml"))
            except Exception:
                self.haar = None                      # Haar bhi nahi: detection khaali (manual box + tracker phir bhi chalte hain)

    @property
    def tag(self):
        """cache key ke liye: detector + embedding on/off."""
        return self.kind + ("+sface" if self.rec is not None else "")

    def _embed(self, small, row):
        try:
            al = self.rec.alignCrop(small, np.asarray(row, dtype=np.float32))
            f = np.asarray(self.rec.feature(al), dtype=np.float32).reshape(-1)
            n = float(np.linalg.norm(f))
            return (f / n).astype(np.float32) if n > 1e-6 else None
        except Exception:
            return None

    def detect(self, frame):
        """Return [(x, y, w, h, score, emb|None)] original pixels."""
        H, W = frame.shape[:2]
        s = min(1.0, self.max_w / float(W))
        small = cv2.resize(frame, (int(W * s), int(H * s))) if s < 1.0 else frame
        out = []
        if self.yn is not None:
            self.yn.setInputSize((small.shape[1], small.shape[0]))
            _, res = self.yn.detect(small)
            if res is not None:
                for r in res:
                    x, y, w, h = r[0] / s, r[1] / s, r[2] / s, r[3] / s
                    emb = self._embed(small, r) if self.rec is not None else None
                    out.append((float(x), float(y), float(w), float(h), float(r[14]), emb))
        else:
            if self.haar is None:
                return out
            g = cv2.cvtColor(small, cv2.COLOR_BGR2GRAY)
            for (x, y, w, h) in self.haar.detectMultiScale(g, 1.1, 5, minSize=(40, 40)):
                out.append((x / s, y / s, w / s, h / s, 0.9, None))
        return out


def face_hist(frame, box):
    """Chehre ke beech wale hisse ka HSV histogram (identity check ke liye)."""
    x, y, w, h = box[:4]
    H, W = frame.shape[:2]
    x0 = int(max(0, x + 0.2 * w)); x1 = int(min(W, x + 0.8 * w))
    y0 = int(max(0, y + 0.2 * h)); y1 = int(min(H, y + 0.8 * h))
    if x1 - x0 < 4 or y1 - y0 < 4:
        return None
    hsv = cv2.cvtColor(frame[y0:y1, x0:x1], cv2.COLOR_BGR2HSV)
    hist = cv2.calcHist([hsv], [0, 1], None, [12, 6], [0, 180, 0, 256])
    cv2.normalize(hist, hist, 1.0, 0.0, cv2.NORM_L1)
    return hist.astype(np.float32)


def hist_dist(a, b):
    if a is None or b is None:
        return 0.5
    return float(cv2.compareHist(a, b, cv2.HISTCMP_BHATTACHARYYA))


def emb_sim(gal, e):
    """gallery (list of normalized embeddings) ke saath e ki sabse badi cosine similarity. Embedding/gallery na ho toh None."""
    if not gal or e is None:
        return None
    return max(float(g @ e) for g in gal)


def is_other(gal, d):
    """Detection d pakka koi aur insaan hai? (SFace similarity bahut kam aur detection score achha, taaki blur/profile face par galat reject na ho)"""
    sm = emb_sim(gal, d.get("emb"))
    return sm is not None and sm < ID_REJECT and d.get("score", 1.0) >= 0.75


def short_path(path):
    """Windows par non-ASCII path ke liye 8.3 short path (OpenCV/ffmpeg ke liye)."""
    try:
        import ctypes
        buf = ctypes.create_unicode_buffer(1024)
        if ctypes.windll.kernel32.GetShortPathNameW(path, buf, 1024):
            return buf.value
    except Exception:
        pass
    return path


def open_video(path):
    cap = cv2.VideoCapture(path)
    if not cap.isOpened() and os.name == "nt":
        cap = cv2.VideoCapture(short_path(path))
    if not cap.isOpened():
        fail("Video file khul nahi rahi (codec support nahi ho sakta): " + path)
    fps = cap.get(cv2.CAP_PROP_FPS) or 0.0
    if fps <= 0 or fps > 480:
        fail("Video ka FPS padh nahi paya")
    n = int(cap.get(cv2.CAP_PROP_FRAME_COUNT) or 0)
    W = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH)); H = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
    return cap, fps, n, W, H


def read_frame_at(cap, fps, t):
    cap.set(cv2.CAP_PROP_POS_FRAMES, int(round(t * fps)))
    ok, fr = cap.read()
    return fr if ok else None


# ---------------------------------------------------------------- detect
def cmd_detect(a):
    cap, fps, n, W, H = open_video(a.video)
    fr = read_frame_at(cap, fps, a.time)
    if fr is None:
        fail("Is time par frame nahi mila: %.3f s" % a.time)
    det = Detector(a.model or default_model())
    faces = det.detect(fr)
    faces.sort(key=lambda f: f[0] + f[2] / 2)          # left -> right numbering
    prev = fr.copy()
    for i, (x, y, w, h, sc, _emb) in enumerate(faces, 1):
        p0 = (int(x), int(y)); p1 = (int(x + w), int(y + h))
        th = max(2, int(H / 270))
        cv2.rectangle(prev, p0, p1, (60, 220, 60), th)
        fs = max(0.8, h / 90.0)
        (tw, tht), _ = cv2.getTextSize(str(i), cv2.FONT_HERSHEY_SIMPLEX, fs, th + 1)
        bx0, by0 = p0[0], max(0, p0[1] - tht - 14)
        cv2.rectangle(prev, (bx0, by0), (bx0 + tw + 14, by0 + tht + 14), (60, 220, 60), -1)
        cv2.putText(prev, str(i), (bx0 + 7, by0 + tht + 6), cv2.FONT_HERSHEY_SIMPLEX,
                    fs, (0, 0, 0), th + 1, cv2.LINE_AA)
    s = min(1.0, 1280.0 / prev.shape[1])
    if s < 1.0:
        prev = cv2.resize(prev, (int(prev.shape[1] * s), int(prev.shape[0] * s)))
    ok = imwrite(a.out, prev, [cv2.IMWRITE_JPEG_QUALITY, 88])
    if not ok:
        fail("Preview jpg save nahi hui: " + a.out)
    info = {"video": a.video, "time": a.time, "width": W, "height": H, "fps": fps,
            "detector": det.kind,
            "faces": [{"id": i, "box": [f[0], f[1], f[2], f[3]], "score": f[4]}
                      for i, f in enumerate(faces, 1)]}
    jp = os.path.splitext(a.out)[0] + ".json"
    with open(jp, "w") as fh:
        json.dump(info, fh)
    say("RESULT", jp)


# --------------------------------------------------------------- analyze
def analyze(a, det, cap, fps, n, W, H):
    """Range ke har frame par sab faces detect karke cache karta hai."""
    start = a.start
    end = a.end if a.end > 0 else (n / fps if n else 0)
    f0 = int(round(start * fps)); f1 = int(round(end * fps))
    if f1 <= f0:
        fail("Range khaali hai (start/end check karo)")
    st = os.stat(a.video)
    key = sha("an", ENGINE_VERSION, os.path.abspath(a.video), st.st_size, int(st.st_mtime),
              f0, f1, det.tag)
    cdir = os.path.join(a.cache_dir, "analysis") if a.cache_dir else ""
    cpath = os.path.join(cdir, key + ".pkl") if cdir else ""
    if cpath and not a.no_cache and os.path.isfile(cpath):
        try:
            with open(cpath, "rb") as fh:
                data = pickle.load(fh)
            if not (isinstance(data, dict) and data.get("frames")):
                raise ValueError("bad cache")
            say("PROGRESS", 70, "analysis cache se mila (dobara analyze nahi kiya)")
            return data
        except Exception:                                  # adhoori/corrupt cache (Cancel ke waqt kill hui) -> dobara analyze
            try:
                os.remove(cpath)
            except OSError:
                pass
    cap.set(cv2.CAP_PROP_POS_FRAMES, f0)
    frames = []
    total = f1 - f0
    for i in range(total):
        ok, fr = cap.read()
        if not ok:
            break
        ds = []
        for (x, y, w, h, sc, emb) in det.detect(fr):
            ds.append({"box": (x, y, w, h), "score": sc, "hist": face_hist(fr, (x, y, w, h)), "emb": emb})
        frames.append(ds)
        if i % 5 == 0:
            say("PROGRESS", int(5 + 65.0 * i / total), "analyzing %d/%d" % (i, total))
    if len(frames) < 2:
        fail("Range mein frames padhe nahi ja sake")
    data = {"f0": f0, "fps": fps, "frames": frames, "detector": det.tag, "expected": total}
    if cpath:
        try:
            atomic_write(cpath, pickle.dumps(data, protocol=pickle.HIGHEST_PROTOCOL))
        except Exception:
            pass                                           # cache likh nahi paye toh bhi tracking chalti rahe
    return data


# --------------------------------------------------------------- kalman
class CV1D:
    """1D velocity-decay Kalman filter. state=[pos, vel]."""

    def __init__(self, pos, vel_var, pos_var, accel_sigma, r_sigma, tau=0.7):
        self.x = np.array([pos, 0.0])
        self.P = np.diag([pos_var, vel_var])
        self.q = accel_sigma ** 2
        self.r = r_sigma ** 2
        self.tau = tau

    def _F(self, dt):
        e = math.exp(-dt / self.tau)
        return np.array([[1.0, self.tau * (1 - e)], [0.0, e]])

    def _Q(self, dt):
        return self.q * np.array([[dt ** 3 / 3, dt ** 2 / 2], [dt ** 2 / 2, dt]])

    def predict(self, dt):
        F = self._F(dt)
        self.x = F @ self.x
        self.P = F @ self.P @ F.T + self._Q(dt)

    def update(self, z, r_sigma=None):
        r = (r_sigma ** 2) if r_sigma else self.r
        S = self.P[0, 0] + r
        K = self.P[:, 0] / S
        self.x = self.x + K * (z - self.x[0])
        self.P = self.P - np.outer(K, self.P[0, :])


def rts_smooth(meas, dt, hs, smooth, pin=None, tau=0.7):
    """meas: (n,3) [cx,cy,h] NaN = no measurement. pin[k]=True (user anchor) par measurement ka noise bahut kam,
    taaki result anchor par (lagbhag) exact baithe. Forward Kalman + RTS backward."""
    n = meas.shape[0]
    k_acc = 30.0 * (1.0 - smooth) ** 2 + 1.0           # face-heights / s^2
    out = np.zeros((n, 3))
    for c in range(3):
        scale = hs
        acc = (k_acc * scale) * (0.5 if c == 2 else 1.0)
        r_sig = 0.03 * scale * (1.5 if c == 2 else 1.0)
        valid = np.where(~np.isnan(meas[:, c]))[0]
        first = meas[valid[0], c]
        f = CV1D(first, (3 * scale) ** 2, (r_sig) ** 2, acc, r_sig, tau)
        xp = np.zeros((n, 2)); Pp = np.zeros((n, 2, 2))
        xf = np.zeros((n, 2)); Pf = np.zeros((n, 2, 2))
        for k in range(n):
            if k > 0:
                f.predict(dt)
            xp[k] = f.x; Pp[k] = f.P
            if not np.isnan(meas[k, c]):
                f.update(meas[k, c], r_sig * 0.1 if (pin is not None and pin[k]) else None)
            xf[k] = f.x; Pf[k] = f.P
        xs = xf.copy()
        F = f._F(dt)
        for k in range(n - 2, -1, -1):
            C = Pf[k] @ F.T @ np.linalg.inv(Pp[k + 1])
            xs[k] = xf[k] + C @ (xs[k + 1] - xp[k + 1])
        out[:, c] = xs[:, 0]
    return out


# ------------------------------------------------------------- association
def iou(a, b):
    ax0, ay0, ax1, ay1 = a[0], a[1], a[0] + a[2], a[1] + a[3]
    bx0, by0, bx1, by1 = b[0], b[1], b[0] + b[2], b[1] + b[3]
    iw = max(0, min(ax1, bx1) - max(ax0, bx0)); ih = max(0, min(ay1, by1) - max(ay0, by0))
    inter = iw * ih
    u = a[2] * a[3] + b[2] * b[3] - inter
    return inter / u if u > 0 else 0.0


def associate(frames, order, seed_box, seed_hist, fps, max_lost, gal=None):
    """order: frame indices seed ke baad ki taraf (forward ya backward).
    Return {frame_idx: (cx, cy, h, hist)} sirf jahan sach mein detection mili."""
    cx = seed_box[0] + seed_box[2] / 2; cy = seed_box[1] + seed_box[3] / 2; h = seed_box[3]
    sc = h
    fx = CV1D(cx, (3 * sc) ** 2, (0.03 * sc) ** 2, 8 * sc, 0.03 * sc)
    fy = CV1D(cy, (3 * sc) ** 2, (0.03 * sc) ** 2, 8 * sc, 0.03 * sc)
    fh = CV1D(h, (1 * sc) ** 2, (0.03 * sc) ** 2, 2 * sc, 0.05 * sc)
    dt = 1.0 / fps
    ref_hist = seed_hist
    misses = 0
    found = {}
    for idx in order:
        fx.predict(dt); fy.predict(dt); fh.predict(dt)
        px, py, ph = fx.x[0], fy.x[0], max(fh.x[0], 8.0)
        lost_s = misses * dt
        long_lost = lost_s > max_lost
        gate = (0.7 + 0.25 * min(misses, 24)) * ph
        best = None; best_cost = 1e9
        for d in frames[idx]:
            x, y, w, hh = d["box"]
            dx = (x + w / 2) - px; dy = (y + hh / 2) - py
            dist = math.hypot(dx, dy)
            ratio = hh / ph
            if not (0.55 < ratio < 1.8):
                continue
            hd = hist_dist(ref_hist, d["hist"])
            sim = emb_sim(gal, d.get("emb"))
            if is_other(gal, d):
                continue                                  # pakka koi aur insaan
            if long_lost:
                if sim is not None:
                    if sim < 0.85 * ID_SAME:
                        continue
                    cost = 1.0 - sim
                else:
                    if hd > 0.35:
                        continue
                    cost = hd
            else:
                if dist > gate:
                    continue
                if sim is None:
                    if misses > 0 and hd > 0.6:
                        continue
                    if hd > 0.8:
                        continue
                    cost = dist / ph + 1.5 * hd
                else:
                    cost = dist / ph + 1.5 * (1.0 - sim)
            if cost < best_cost:
                best_cost, best = cost, (x + w / 2, y + hh / 2, hh, d["hist"], w)
        if best is None:
            misses += 1
            continue
        if long_lost:               # re-lock: filter ko naye point par reset karo
            fx.x[:] = [best[0], 0.0]; fy.x[:] = [best[1], 0.0]; fh.x[:] = [best[2], 0.0]
        fx.update(best[0]); fy.update(best[1]); fh.update(best[2])
        if best[3] is not None and ref_hist is not None:
            ref_hist = (0.9 * ref_hist + 0.1 * best[3]).astype(np.float32)
        misses = 0
        found[idx] = best
    return found


# ------------------------------------------------------ appearance tracker
class AppTracker:
    """VitTrack (ONNX, shakal se follow karta hai: helmet/topi/chasma sab). Model na mile toh MIL fallback."""

    def __init__(self, model_path):
        self.model_path = model_path
        self.kind = "none"
        self.t = None
        self.err = ""
        self._make()

    def _make(self):
        if self.model_path:
            try:
                p = cv2.TrackerVit_Params()
                p.net = self.model_path
                self.t = cv2.TrackerVit_create(p)
                self.kind = "vit"
                return
            except Exception as e:
                self.err = str(e)[:160]
        try:
            self.t = cv2.TrackerMIL_create()
            self.kind = "mil"
        except Exception as e:
            self.t = None
            self.kind = "none"
            self.err = self.err or str(e)[:160]

    def init(self, frame, box):
        x, y, w, h = [int(round(v)) for v in box]
        self.t.init(frame, (x, y, max(8, w), max(8, h)))

    def update(self, frame):
        try:
            ok, b = self.t.update(frame)
            if self.kind == "vit":
                sc = float(self.t.getTrackingScore())
            else:
                sc = 1.0 if ok else 0.0
            return bool(ok), tuple(float(v) for v in b), sc
        except Exception:
            return False, (0.0, 0.0, 0.0, 0.0), 0.0


def track_step(trk, sm, i, st, frames, A, s, manual):
    """Tracker ka ek frame. Return [cx,cy,h,score] (original pixels) ya None (lost).
    Face-seed mode mein tracker detection par re-center hota hai (drift nahi), aur lost hone par wapas dikhe face par re-lock."""
    ok, (bx, by, bw, bh), sc = trk.update(sm)
    valid = ok and bw >= 6 and bh >= 6 and sc >= SCORE_MIN
    out = [(bx + bw / 2) / s, (by + bh / 2) / s, bh / s, sc] if valid else None
    st["since"] += 1
    if not manual:
        reinit = None
        if valid and st["since"] >= REINIT_EVERY:
            tb = (bx / s, by / s, bw / s, bh / s)
            best = 0.35
            for d in frames[i]:
                if is_other(st.get("gal"), d):
                    continue                              # tracker ko kisi aur insaan par re-center nahi karte
                v = iou(d["box"], tb)
                if v > best:
                    best, reinit = v, d["box"]
        elif (not valid) and A and i in A:
            a = A[i]
            reinit = (a[0] - a[4] / 2, a[1] - a[2] / 2, a[4], a[2])
        if reinit is not None:
            try:
                trk.init(sm, [v * s for v in reinit])
                st["since"] = 0
            except Exception:
                pass
    return out


def blend_pair(j, f, b, w, frames, manual, gal=None):
    """Do anchors ke beech frame j: f = pehle anchor se aage wala track, b = agle anchor se peeche wala track.
    Dono hain toh time-weight (w: 0 pehle anchor ke paas .. 1 agle ke paas) se blend. Agar dono bahut alag hain (ek jump/drift kar gaya)
    aur sirf ek detection ke paas hai, toh wahi chuna jaata hai. Return (cx,cy,h,score) ya None, disagreement (face-heights mein)."""
    if f is not None and b is not None:
        h = max(0.5 * (f[2] + b[2]), 1e-6)
        dis = math.hypot(f[0] - b[0], f[1] - b[1]) / h
        if dis > 0.35 and not manual:
            gf, wf = gate_det(frames[j], f[0], f[1], f[2], gal); gb, wb = gate_det(frames[j], b[0], b[1], b[2], gal)
            if wf and not wb:                                 # F kisi aur insaan par chala gaya
                return b, dis
            if wb and not wf:
                return f, dis
            if gf is not None and gb is None:
                return f, dis
            if gb is not None and gf is None:
                return b, dis
        v = [(1.0 - w) * f[i] + w * b[i] for i in range(3)]
        v.append(min(f[3], b[3]))
        return v, dis
    if f is not None:
        return f, 0.0
    if b is not None:
        return b, 0.0
    return None, 0.0


def run_tracker_multi(cap, f0, N, anc, frames, A, manual, model, W, H, gal=None):
    """Appearance tracker, multi-anchor.
      * pehle anchor se pehle: peeche ki taraf;  aakhri anchor ke baad: aage ki taraf
      * do anchors ke beech: pehle se aage (F) + agle se peeche (B), smoothstep time-weight se blend
      * anchor wale frame par result exact anchor box
    Return (T[N,4] = cx,cy,h,score / NaN lost, Dis[N] = F-B disagreement, kind, err)."""
    T = np.full((N, 4), np.nan)
    Dis = np.zeros(N)
    probe = AppTracker(model)
    if probe.kind == "none":
        return T, Dis, "none", probe.err
    kind, err = probe.kind, probe.err
    s = min(1.0, 960.0 / W)
    store = []
    cap.set(cv2.CAP_PROP_POS_FRAMES, f0)
    for i in range(N):
        ok, fr = cap.read()
        if not ok:
            break
        sm = cv2.resize(fr, (int(W * s), int(H * s))) if s < 1.0 else fr
        store.append(cv2.imencode(".jpg", sm, [cv2.IMWRITE_JPEG_QUALITY, 95])[1].tobytes())
        if i % 10 == 0:
            say("PROGRESS", int(73 + 3.0 * i / max(1, N)), "reading %d/%d" % (i, N))
    NR = len(store)

    def decode(j):
        return cv2.imdecode(np.frombuffer(store[j], np.uint8), cv2.IMREAD_COLOR)

    def sbox_of(box):
        sx, sy, sw, sh = [v * s for v in box]
        sw = max(8.0, sw); sh = max(8.0, sh)
        sx = min(max(0.0, sx), W * s - sw - 1); sy = min(max(0.0, sy), H * s - sh - 1)
        return (sx, sy, sw, sh)

    idx = [an["i"] for an in anc]
    total = max(1, sum(max(0, (idx[k + 1] - idx[k] - 1) * 2) for k in range(len(idx) - 1)) + idx[0] + (N - 1 - idx[-1]))
    done = [0]

    def run(seed_i, box, order):
        res = {}
        if seed_i >= NR:
            return res, None
        trk = AppTracker(model)
        trk.init(decode(seed_i), sbox_of(box))
        st = {"since": 0, "gal": gal}
        bad = None                       # pehla frame jahan tracker lost hua (uske baad ka hissa bharosemand nahi)
        for j in order:
            if j >= NR or j < 0:
                break
            r = track_step(trk, decode(j), j, st, frames, A, s, manual)
            if r is not None:
                res[j] = r
            elif bad is None:
                bad = j
            done[0] += 1
            if done[0] % 10 == 0:
                say("PROGRESS", int(77 + 10.0 * done[0] / total), "tracking %d/%d" % (done[0], total))
        return res, bad

    for an in anc:                                           # anchor frame = exact pick
        sx, sy, sw, sh = sbox_of(an["box"])
        if an["i"] < NR:
            T[an["i"]] = [(sx + sw / 2) / s, (sy + sh / 2) / s, sh / s, 1.0]
    if idx[0] > 0:
        for j, r in run(idx[0], anc[0]["box"], range(idx[0] - 1, -1, -1))[0].items():
            T[j] = r
    if idx[-1] < N - 1:
        for j, r in run(idx[-1], anc[-1]["box"], range(idx[-1] + 1, N))[0].items():
            T[j] = r
    for k in range(len(anc) - 1):
        ai, bi = idx[k], idx[k + 1]
        if bi - ai < 2:
            continue
        Fw, badF = run(ai, anc[k]["box"], range(ai + 1, bi))
        Bw, badB = run(bi, anc[k + 1]["box"], range(bi - 1, ai, -1))
        for j in range(ai + 1, bi):
            w = (j - ai) / float(bi - ai)
            w = w * w * (3.0 - 2.0 * w)
            f = Fw.get(j); b = Bw.get(j)
            f_ok = badF is None or j < badF           # F lost ho chuka ho toh uske baad F par bharosa nahi
            b_ok = badB is None or j > badB
            if f is not None and b is not None and f_ok != b_ok:
                f, b = (f, None) if f_ok else (None, b)
            v, dis = blend_pair(j, f, b, w, frames, manual, gal)
            if v is not None:
                T[j] = v
            Dis[j] = dis
    return T, Dis, kind, err


def gate_det(dets, tcx, tcy, th, gal=None):
    """Tracker box ke paas wali (usi shakhs ki) detection. Return (det|None, wrong).
    wrong=True: paas mein detection thi par identity (SFace) alag insaan ki nikli, yaani tracker shayad kisi aur par hai."""
    best = None; bd = 1e18; wrong = False
    for d in dets:
        x, y, w, h = d["box"]
        cx = x + w / 2; cy = y + h / 2
        dist = math.hypot(cx - tcx, cy - tcy)
        r = h / max(th, 1e-6)
        if dist < 0.45 * th and 0.7 < r < 1.4:
            if is_other(gal, d):
                wrong = True
                continue
            if dist < bd:
                bd, best = dist, (cx, cy, h)
    return best, (wrong and best is None)


def local_offset(i, di, off, take=15):
    """Detection - tracker ka median offset, sabse nazdeeki `take` frames (dono taraf) se. Face-center aur tracker-center ka farak
    head ke saath lagbhag constant rehta hai, isliye door ke samples bhi kaam ke hain (switch par jhatka nahi aata). Koi sample nahi toh zero."""
    import bisect
    k = bisect.bisect_left(di, i)
    cand = []
    lo = k - 1; hi = k
    while len(cand) < 2 * take and (lo >= 0 or hi < len(di)):
        dl = (i - di[lo]) if lo >= 0 else 1e9
        dh = (di[hi] - i) if hi < len(di) else 1e9
        if min(dl, dh) >= 1e9:
            break
        if dl <= dh:
            cand.append(off[di[lo]]); lo -= 1
        else:
            cand.append(off[di[hi]]); hi += 1
    if not cand:
        return 0.0, 0.0, 1.0
    arr = np.array(cand)
    return float(np.median(arr[:, 0])), float(np.median(arr[:, 1])), float(np.median(arr[:, 2]))


def fuse(N, T, A, frames, anc, manual, gal=None):
    """Detection + tracker + association ko ek measurement array mein milata hai.
    Priority: (1) tracker box ke paas wali detection  (2) tracker (detection-offset se corrected)  (3) face-association.
    Anchors (user pick) har hal mein pinned. Return meas[N,3], src[N] (2 = detection, 1 = tracker, 0 = lost), pin[N]."""
    meas = np.full((N, 3), np.nan)
    src = np.zeros(N, dtype=np.int8)
    D = {}
    wrongT = set()                                            # tracker kisi aur insaan par (SFace identity mismatch)
    if not manual:
        for i in range(N):
            if np.isnan(T[i, 0]):
                continue
            g, wr = gate_det(frames[i], T[i, 0], T[i, 1], T[i, 2], gal)
            if g is not None:
                D[i] = g
            elif wr:
                wrongT.add(i)
    di = sorted(D.keys())
    off = {i: (D[i][0] - T[i, 0], D[i][1] - T[i, 1], D[i][2] / max(T[i, 2], 1e-6)) for i in di}
    for i in range(N):
        if i in D:
            meas[i] = D[i]; src[i] = 2
        elif i in wrongT:
            if A and i in A:                                  # tracker galat insaan par: sahi insaan ki association use karo
                meas[i] = [A[i][0], A[i][1], A[i][2]]; src[i] = 2
        elif not np.isnan(T[i, 0]):
            dx, dy, rt = local_offset(i, di, off) if di else (0.0, 0.0, 1.0)
            h = T[i, 2]
            dx = max(-0.5 * h, min(0.5 * h, dx)); dy = max(-0.5 * h, min(0.5 * h, dy)); rt = max(0.6, min(1.6, rt))
            meas[i] = [T[i, 0] + dx, T[i, 1] + dy, h * rt]; src[i] = 1
        elif A and i in A:
            meas[i] = [A[i][0], A[i][1], A[i][2]]; src[i] = 2
    pin = np.zeros(N, dtype=bool)
    for an in anc:
        b = an["box"]
        meas[an["i"]] = [b[0] + b[2] / 2, b[1] + b[3] / 2, b[3]]
        src[an["i"]] = 2 if an["snapped"] else 1
        pin[an["i"]] = True
    fuse.wrong = len(wrongT)
    return meas, src, pin


# ----------------------------------------------------------------- track
def load_anchors(a, fps):
    """--anchors json: [{"time": s, "box": [x,y,w,h], "manual": bool}, ...]  (ya purana --seed/--seed-time/--manual).
    Return time-sorted list, ek frame par ek anchor (baad wala jeetta hai)."""
    raw = []
    if a.anchors:
        with open(a.anchors, encoding="utf-8") as fh:
            for r in json.load(fh):
                b = [float(v) for v in r["box"]]
                if len(b) != 4:
                    fail("anchor box x,y,w,h chahiye")
                raw.append({"t": float(r["time"]), "box": tuple(b), "manual": bool(r.get("manual", False))})
    elif a.seed:
        b = [float(v) for v in a.seed.split(",")]
        if len(b) != 4:
            fail("--seed x,y,w,h chahiye")
        raw.append({"t": float(a.seed_time), "box": tuple(b), "manual": bool(a.manual)})
    if not raw:
        fail("--anchors ya --seed chahiye")
    byf = {}
    for r in raw:
        byf[int(round(r["t"] * fps))] = r
    out = []
    for fidx in sorted(byf):
        r = dict(byf[fidx]); r["frame"] = fidx
        out.append(r)
    return out


def cmd_track(a):
    cap, fps, n, W, H = open_video(a.video)
    det = Detector(a.model or default_model(), sface_path="" if a.no_identity else (a.sface_model or default_sface_model()))
    say("PROGRESS", 2, "detector: " + det.tag)
    anchors_in = load_anchors(a, fps)
    st = os.stat(a.video)
    end = a.end if a.end > 0 else (n / fps if n else 0)
    model_t = (a.tracker_model or default_tracker_model()) if a.mode != "face" else ""
    akey = "|".join("%d:%s:%d" % (r["frame"], ",".join("%.1f" % v for v in r["box"]), int(r["manual"])) for r in anchors_in)
    tkey = sha("tr", ENGINE_VERSION, TRACK_VERSION, os.path.abspath(a.video), st.st_size, int(st.st_mtime),
               round(a.start * fps), round(end * fps), akey,
               a.smooth, a.max_lost, det.tag,
               a.mode, (os.path.basename(model_t) + str(os.path.getsize(model_t))) if model_t else "-")
    tdir = os.path.join(a.cache_dir, "tracks") if a.cache_dir else ""
    tpath = os.path.join(tdir, tkey + ".json") if tdir else ""
    if tpath and not a.no_cache and os.path.isfile(tpath):
        try:
            with open(tpath, "rb") as fh:
                raw = fh.read()
            if not json.loads(raw.decode("utf-8")).get("points"):
                raise ValueError("bad cache")
            atomic_write(a.out, raw)
            say("PROGRESS", 100, "cache hit")
            say("RESULT", a.out)
            return
        except Exception:                                  # corrupt track cache -> dobara track
            try:
                os.remove(tpath)
            except OSError:
                pass

    data = analyze(a, det, cap, fps, n, W, H)
    frames = data["frames"]; f0 = data["f0"]; N = len(frames)
    warnings = []

    # anchors: face-click -> detection (IoU) se snap + histogram. Manual box (helmet/topi) -> user ka box jaisa hai waisa
    byi = {}
    for r in anchors_in:
        i = r["frame"] - f0
        if i < 0 or i >= N:
            if r["frame"] - f0 == N:          # range ke theek end par
                i = N - 1
            else:
                warnings.append("anchor %.2fs range ke bahar tha, hata diya" % r["t"])
                continue
        best_d = None; best_iou = 0.0
        if not r["manual"]:
            for d in frames[i]:
                v = iou(d["box"], r["box"])
                if v > best_iou:
                    best_iou, best_d = v, d
        if best_d is not None and best_iou > 0.3:
            byi[i] = {"i": i, "box": tuple(best_d["box"]), "hist": best_d["hist"], "snapped": True, "manual": False, "emb": best_d.get("emb")}
        else:
            byi[i] = {"i": i, "box": tuple(r["box"]), "hist": None, "snapped": False, "manual": r["manual"]}
    anc = [byi[i] for i in sorted(byi)]
    if not anc:
        fail("Koi anchor range ke andar nahi hai")
    manual = all(an["manual"] for an in anc)          # sab anchors box se diye gaye -> detection use nahi hoti
    gal = [an["emb"] for an in anc if an.get("emb") is not None]      # SFace identity gallery (face anchors se)
    say("PROGRESS", 72, "associating")

    # face association: har face-anchor apne aage/peeche, agle/pichle anchor tak. Do anchors ke beech jo anchor nazdeek ho uska result.
    Ad = {}
    if not manual:
        for k, an in enumerate(anc):
            if an["manual"]:
                continue
            nxt = anc[k + 1]["i"] if k + 1 < len(anc) else N
            prv = anc[k - 1]["i"] if k > 0 else -1
            for found in (associate(frames, range(an["i"] + 1, nxt), an["box"], an["hist"], fps, a.max_lost, gal),
                          associate(frames, range(an["i"] - 1, prv, -1), an["box"], an["hist"], fps, a.max_lost, gal)):
                for fr, v in found.items():
                    d = abs(fr - an["i"])
                    if fr not in Ad or d < Ad[fr][0]:
                        Ad[fr] = (d, v)
    A = {fr: v for fr, (d, v) in Ad.items()}

    T = np.full((N, 4), np.nan); Dis = np.zeros(N); tkind = "face-only"; terr = ""
    # tracker tabhi chalta hai jab VitTrack model ho, ya sab anchors manual box hon (tab MIL fallback chalega, koi aur raasta nahi)
    if a.mode != "face" and (model_t or manual):
        T, Dis, tkind, terr = run_tracker_multi(cap, f0, N, anc, frames, A, manual, model_t, W, H, gal)
        if tkind == "none" or (tkind == "mil" and not manual):
            T[:] = np.nan; Dis[:] = 0.0; tkind = "face-only"   # weak fallback sirf face-click par nahi lagate (purana behaviour)
    elif a.mode != "face":
        terr = "vittrack.onnx nahi mila (get_model.bat chalao)"
    if manual and tkind == "face-only":
        fail("Manual box ke liye tracker chahiye (OpenCV 4.9+ / models\\vittrack.onnx). " + terr)
    meas, srcarr, pin = fuse(N, T, A, frames, anc, manual, gal)
    measured = ~np.isnan(meas[:, 0])
    say("PROGRESS", 88, "smoothing")
    sm = rts_smooth(meas, 1.0 / fps, float(anc[0]["box"][3]), a.smooth, pin)

    pts = [[round((f0 + i) / fps, 5), round(float(sm[i, 0]), 2), round(float(sm[i, 1]), 2),
            round(float(sm[i, 2]), 2)] for i in range(N)]
    # lost segments
    segs = []; i = 0
    while i < N:
        if not measured[i]:
            j = i
            while j < N and not measured[j]:
                j += 1
            if j - i >= 2:
                segs.append([round((f0 + i) / fps, 3), round((f0 + j) / fps, 3)])
            i = j
        else:
            i += 1
    expected = data.get("expected", N)
    dmask = Dis > 0
    dstat = {"mean": round(float(Dis[dmask].mean()), 3) if dmask.any() else 0.0,
             "max": round(float(Dis.max()), 3),
             "max_t": round((f0 + int(Dis.argmax())) / fps, 3),
             "bad": int((Dis > 0.5).sum())}
    res = {"version": 1, "frames_read": N, "frames_expected": expected, "truncated": N < expected,
           "video": a.video, "fps": fps, "width": W, "height": H,
           "start": f0 / fps, "end": (f0 + N) / fps, "detector": det.tag,
           "identity": {"sface": det.rec is not None, "gallery": len(gal), "wrong_tracker_frames": int(getattr(fuse, "wrong", 0)), "err": det.rec_err},
           "seed_time": round((f0 + anc[0]["i"]) / fps, 5), "smooth": a.smooth,
           "anchors": [{"t": round((f0 + an["i"]) / fps, 5), "snapped": bool(an["snapped"]), "manual": bool(an["manual"])} for an in anc],
           "warnings": warnings,
           "coverage": round(float(measured.mean()), 4), "lost": segs,
           "measured": [int(m) for m in measured], "points": pts,
           "disagree": [round(float(v), 3) for v in Dis], "disagree_stat": dstat,
           "tracker": tkind, "tracker_err": terr, "manual": bool(manual),
           "source": [int(v) for v in srcarr],
           "src_counts": {"detect": int((srcarr == 2).sum()), "tracker": int((srcarr == 1).sum()), "lost": int((srcarr == 0).sum())}}
    blob = json.dumps(res).encode("utf-8")
    atomic_write(a.out, blob)
    if tpath:
        try:
            atomic_write(tpath, blob)
        except Exception:
            pass
    say("PROGRESS", 100, "done, coverage %.0f%%" % (100 * res["coverage"]))
    say("RESULT", a.out)


# --------------------------------------------------------------- preview
def cmd_preview(a):
    """Range ke frames chhote jpg mein (stride se max_frames tak) + index.json. Cache hota hai (index.json aakhir mein likhi jaati hai)."""
    cap, fps, n, W, H = open_video(a.video)
    f0 = int(round(a.start * fps))
    f1 = int(round(a.end * fps)) if a.end > 0 else n
    N = f1 - f0
    if N < 1:
        fail("Preview range khaali hai")
    stride = max(1, int(math.ceil(N / float(max(1, a.max_frames)))))
    st = os.stat(a.video)
    key = sha("pv", ENGINE_VERSION, os.path.abspath(a.video), st.st_size, int(st.st_mtime), f0, f1, stride, a.max_w)
    d = os.path.join(a.out_dir, key)
    idxp = os.path.join(d, "index.json")
    if os.path.isfile(idxp):
        say("PROGRESS", 100, "preview cache hit")
        say("RESULT", idxp)
        return
    os.makedirs(d, exist_ok=True)
    sc = min(1.0, a.max_w / float(W))
    cap.set(cv2.CAP_PROP_POS_FRAMES, f0)
    count = 0; read = 0
    for i in range(N):
        ok, fr = cap.read()
        if not ok:
            break
        read += 1
        if i % stride == 0:
            sm = cv2.resize(fr, (max(2, int(W * sc)), max(2, int(H * sc))), interpolation=cv2.INTER_AREA) if sc < 1.0 else fr
            if not imwrite(os.path.join(d, "f%05d.jpg" % count), sm, [cv2.IMWRITE_JPEG_QUALITY, 80]):
                fail("Preview frame save nahi hui: " + d)
            count += 1
        if i % 20 == 0:
            say("PROGRESS", int(100.0 * i / N), "preview %d/%d" % (i, N))
    if count < 1:
        fail("Preview ke frames padhe nahi ja sake")
    info = {"fps": fps, "f0": f0, "stride": stride, "count": count, "frames": read, "width": W, "height": H,
            "dir": d, "files": "f%05d.jpg"}
    with open(idxp, "w") as fh:
        json.dump(info, fh)
    say("PROGRESS", 100, "preview ready")
    say("RESULT", idxp)


# ------------------------------------------------------------------ main
def main():
    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except Exception:
        pass
    ap = argparse.ArgumentParser(prog="l4_tracker")
    sub = ap.add_subparsers(dest="cmd", required=True)
    d = sub.add_parser("detect")
    d.add_argument("--video", required=True); d.add_argument("--time", type=float, default=0.0)
    d.add_argument("--out", required=True); d.add_argument("--model", default="")
    t = sub.add_parser("track")
    t.add_argument("--video", required=True)
    t.add_argument("--start", type=float, default=0.0)
    t.add_argument("--end", type=float, default=0.0, help="0 = video ka end")
    t.add_argument("--seed", default="", help="x,y,w,h (pixels) detect se (single anchor; --anchors na ho tab)")
    t.add_argument("--anchors", default="", help="json file: [{time, box:[x,y,w,h], manual}, ...] multi-anchor")
    t.add_argument("--seed-time", dest="seed_time", type=float, default=None)
    t.add_argument("--out", required=True); t.add_argument("--model", default="")
    t.add_argument("--smooth", type=float, default=0.5, help="0..1, zyada = smooth")
    t.add_argument("--max-lost", dest="max_lost", type=float, default=3.0)
    t.add_argument("--cache-dir", dest="cache_dir", default="")
    t.add_argument("--no-cache", dest="no_cache", action="store_true")
    t.add_argument("--mode", choices=["auto", "face"], default="auto",
                   help="auto = detection + appearance tracker (helmet/topi), face = sirf face detection (purana)")
    t.add_argument("--manual", action="store_true", help="seed user ne box se diya (face detect nahi hua / helmet)")
    t.add_argument("--tracker-model", dest="tracker_model", default="")
    t.add_argument("--sface-model", dest="sface_model", default="", help="SFace onnx (default: models\\sface.onnx)")
    t.add_argument("--no-identity", dest="no_identity", action="store_true", help="SFace identity band (histogram fallback)")
    pv = sub.add_parser("preview")
    pv.add_argument("--video", required=True)
    pv.add_argument("--start", type=float, default=0.0)
    pv.add_argument("--end", type=float, default=0.0)
    pv.add_argument("--out-dir", dest="out_dir", required=True)
    pv.add_argument("--max-w", dest="max_w", type=int, default=480)
    pv.add_argument("--max-frames", dest="max_frames", type=int, default=400)
    a = ap.parse_args()
    try:
        if a.cmd == "detect":
            cmd_detect(a)
        elif a.cmd == "preview":
            cmd_preview(a)
        else:
            if a.seed_time is None:
                a.seed_time = a.start
            a.smooth = min(0.98, max(0.0, a.smooth))
            cmd_track(a)
    except SystemExit:
        raise
    except Exception as e:
        import traceback
        traceback.print_exc(file=sys.stderr)
        fail("%s: %s" % (type(e).__name__, e))


if __name__ == "__main__":
    main()
