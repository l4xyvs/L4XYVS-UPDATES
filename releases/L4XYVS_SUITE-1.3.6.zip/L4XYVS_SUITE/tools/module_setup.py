#!/usr/bin/env python3
"""L4XYVS SUITE Component Manager setup helper (Windows).
Only installs the requested component. Never deletes user files or custom presets.
"""
import argparse
import os
import shutil
import subprocess
import sys
import tempfile
import urllib.request
import hashlib
import re
import time
from pathlib import Path

CATALOG_NAME = "modules.json"

def load_catalog(root):
    """Load and validate the local module catalog; reject unsafe paths/URLs."""
    import json
    catalog_path = Path(root) / "tools" / CATALOG_NAME
    if not catalog_path.is_file():
        raise RuntimeError(f"Module catalog is missing: {catalog_path}")
    try:
        catalog = json.loads(catalog_path.read_text(encoding="utf-8"))
    except Exception as exc:
        raise RuntimeError("Module catalog is invalid JSON: " + str(exc))
    if not isinstance(catalog, dict) or catalog.get("schema_version") != 1 or not isinstance(catalog.get("modules"), list):
        raise RuntimeError("Module catalog schema is unsupported or incomplete.")
    seen = set()
    for module in catalog["modules"]:
        if not isinstance(module, dict) or not isinstance(module.get("id"), str) or not module["id"].replace("-", "").isalnum():
            raise RuntimeError("Module catalog contains an invalid module ID.")
        if module["id"] in seen:
            raise RuntimeError("Module catalog contains duplicate module IDs.")
        seen.add(module["id"])
        if not isinstance(module.get("files"), list) or not module["files"]:
            raise RuntimeError(f"Module {module['id']} must declare at least one file.")
        for item in module["files"]:
            if not isinstance(item, dict) or not isinstance(item.get("target"), str) or not isinstance(item.get("url"), str):
                raise RuntimeError(f"Module {module['id']} contains an incomplete file entry.")
            target = Path(item["target"])
            if target.is_absolute() or ".." in target.parts or not target.parts:
                raise RuntimeError(f"Unsafe target path in module {module['id']}: {target}")
            if not item["url"].startswith("https://"):
                raise RuntimeError(f"Non-HTTPS download URL in module {module['id']}.")
            if not isinstance(item.get("min_bytes"), int) or item["min_bytes"] < 1:
                raise RuntimeError(f"Invalid min_bytes in module {module['id']}.")
            digest = item.get("sha256")
            if not isinstance(digest, str) or not re.fullmatch(r"[0-9a-fA-F]{64}", digest):
                raise RuntimeError(f"Missing or invalid SHA-256 pin for {item['target']} in module {module['id']}.")
    return catalog

def install_module(root, module_id):
    """Install a manifest module transactionally: stage all files before activation."""
    root = Path(root).resolve()
    catalog = load_catalog(root)
    module = next((m for m in catalog["modules"] if m["id"] == module_id), None)
    if module is None:
        raise RuntimeError(f"Unknown module ID: {module_id}")

    say("Installing module: " + str(module.get("name", module_id)))
    # A module can contain several files. Download and validate every file first;
    # only then activate them. If activation fails, restore every prior target.
    with tempfile.TemporaryDirectory(prefix=".l4xy_module_stage_", dir=str(root)) as temp_name:
        stage_root = Path(temp_name) / "staged"
        stage_root.mkdir(parents=True)
        pairs = []
        for item in module["files"]:
            relative = Path(item["target"])
            target = (root / relative).resolve()
            if root not in target.parents:
                raise RuntimeError("Resolved module target escapes extension directory.")
            staged = stage_root / relative
            staged.parent.mkdir(parents=True, exist_ok=True)
            if _file_matches(target, item["min_bytes"], item["sha256"]):
                # Reuse only files that match the pinned digest, not just their size.
                shutil.copy2(target, staged)
                say("Already present and SHA-256 verified: " + target.name)
            else:
                download(item["url"], staged, item["min_bytes"], item["sha256"])
            pairs.append((staged, target))
        _activate_staged_files(pairs)
    say(f"SUCCESS: module {module_id} installed/validated ({len(module['files'])} files).")


def _activate_staged_files(pairs, fail_after=None):
    """Activate staged files with rollback if any replacement fails.

    fail_after is only used by the isolated self-test to simulate a filesystem error.
    """
    backups = {}
    activated = []
    committed = False
    try:
        for _staged, target in pairs:
            target.parent.mkdir(parents=True, exist_ok=True)
            if target.exists():
                backup = target.with_name(target.name + ".l4xy-rollback-" + str(os.getpid()))
                shutil.copy2(target, backup)
                backups[target] = backup
            else:
                backups[target] = None
        for index, (staged, target) in enumerate(pairs, start=1):
            if fail_after is not None and index > fail_after:
                raise OSError("Simulated activation failure")
            os.replace(staged, target)
            activated.append(target)
        committed = True
    except Exception:
        for target in reversed(activated):
            backup = backups.get(target)
            try:
                if backup and backup.exists():
                    os.replace(backup, target)
                elif target.exists():
                    target.unlink()
            except OSError:
                # Leave any remaining .l4xy-rollback file for manual recovery.
                pass
        raise
    finally:
        # Only clean backups after a full commit. If rollback itself failed, leave
        # any remaining backup on disk rather than risk destroying recovery data.
        if committed:
            for backup in backups.values():
                if backup and backup.exists():
                    try:
                        backup.unlink()
                    except OSError:
                        pass

def say(message):
    print(message, flush=True)


def run(args, cwd=None):
    say("RUN: " + subprocess.list2cmdline([str(x) for x in args]))
    subprocess.run([str(x) for x in args], cwd=str(cwd) if cwd else None, check=True)


def download(url, target, minimum, expected_sha256=None):
    """Download to a sibling temp file, validate it, then atomically activate it.

    Existing targets are never truncated by a failed/partial download. Model files
    that look like Git LFS pointer text are rejected even if their size passes a
    naive check.
    """
    target = Path(target)
    if _file_matches(target, minimum, expected_sha256):
        say("Already present and SHA-256 verified: " + target.name)
        return
    target.parent.mkdir(parents=True, exist_ok=True)
    temp = target.with_name(target.name + ".download-" + str(os.getpid()))
    try:
        say("Downloading " + target.name + " (large model; please wait)…")
        req = urllib.request.Request(url, headers={"User-Agent": "L4XYVS-Suite-ComponentManager/1.1"})
        with urllib.request.urlopen(req, timeout=90) as response, open(temp, "wb") as out:
            status = getattr(response, "status", 200)
            if status < 200 or status >= 300:
                raise RuntimeError(f"Download server returned HTTP {status} for {target.name}.")
            expected = response.headers.get("Content-Length")
            expected = int(expected) if expected and expected.isdigit() else None
            received = 0
            while True:
                chunk = response.read(1024 * 1024)
                if not chunk:
                    break
                out.write(chunk)
                received += len(chunk)
                if expected:
                    say(f"Download progress {target.name}: {min(100, int(received * 100 / expected))}%")
        size = temp.stat().st_size
        if size < minimum:
            raise RuntimeError(f"{target.name} download looks incomplete ({size} bytes); file rejected.")
        if _looks_like_lfs_pointer(temp):
            raise RuntimeError(f"{target.name} downloaded as a Git LFS pointer, not the model. Existing file was preserved.")
        if expected_sha256:
            actual_sha256 = _sha256_file(temp)
            if actual_sha256.lower() != expected_sha256.lower():
                raise RuntimeError(f"{target.name} SHA-256 mismatch; download rejected and existing file was preserved.")
        os.replace(temp, target)
        if expected_sha256:
            say(f"Verified {target.name}: {size:,} bytes; SHA-256 matched pinned digest")
        else:
            say(f"Verified {target.name}: {size:,} bytes (size and LFS-pointer checks)")
    finally:
        try:
            if temp.exists():
                temp.unlink()
        except OSError:
            pass



def _sha256_file(path):
    digest = hashlib.sha256()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _file_matches(path, minimum, expected_sha256):
    path = Path(path)
    if not path.is_file() or path.stat().st_size < minimum or _looks_like_lfs_pointer(path):
        return False
    if not expected_sha256:
        return False
    try:
        return _sha256_file(path).lower() == expected_sha256.lower()
    except OSError:
        return False


def _looks_like_lfs_pointer(path):
    try:
        with open(path, "rb") as fh:
            head = fh.read(256).lstrip()
        return head.startswith(b"version https://git-lfs.github.com/spec/v1")
    except OSError:
        return False


def setup_caption(root):
    """Install Whisper into the exact Python interpreter running this helper.

    Do not upgrade an already-working Whisper installation automatically: broad
    upgrades can change Torch and other packages unexpectedly. A repair is only
    attempted if import verification fails or pip install reports a problem.
    """
    try:
        import whisper  # noqa: F401
        say("Whisper already imports in " + sys.executable)
        say("If Auto Caption still fails, check FFmpeg and the diagnostics log before reinstalling packages.")
        return
    except Exception:
        pass
    say("Installing OpenAI Whisper into this Python installation…")
    run([sys.executable, "-m", "pip", "install", "openai-whisper"])
    try:
        import whisper  # noqa: F401
    except Exception as exc:
        raise RuntimeError("Whisper installation finished but import verification failed: " + str(exc))
    say("SUCCESS: Whisper import check passed.")
    say("FFmpeg is a separate Windows application. If it is missing, use Get FFmpeg; Windows may require confirmation to install it.")


def setup_tracker(root):
    if os.name != "nt":
        raise RuntimeError("Auto Tracker setup helper is currently supported on Windows only.")
    root = Path(root).resolve()
    # The development package keeps build sources in the top-level /engine folder.
    # Accept the earlier tools/tracker_engine layout as a backwards-compatible fallback.
    engine_candidates = [root / "engine", root / "tools" / "tracker_engine"]
    engine_dir = next((d for d in engine_candidates if (d / "l4_tracker.py").is_file() and (d / "requirements.txt").is_file()), None)
    if engine_dir is None:
        raise RuntimeError("Bundled Tracker build files are missing. Expected engine/l4_tracker.py and engine/requirements.txt.")
    source = engine_dir / "l4_tracker.py"
    reqs = engine_dir / "requirements.txt"

    install_module(root, "tracker-models")

    say("Installing Tracker build requirements into the selected Python…")
    run([sys.executable, "-m", "pip", "install", "-r", str(reqs)])
    say("Building the Tracker engine in a temporary staging directory. This can take several minutes…")
    with tempfile.TemporaryDirectory(prefix="l4xy_tracker_build_") as temp_name:
        temp = Path(temp_name)
        dist = temp / "dist"
        dist.mkdir()
        run([
            sys.executable, "-m", "PyInstaller", "--noconfirm", "--clean", "--onefile",
            "--name", "l4_tracker", "--distpath", str(dist),
            "--workpath", str(temp / "work"), "--specpath", str(temp / "spec"), str(source)
        ], cwd=engine_dir)
        staged_exe = dist / "l4_tracker.exe"
        if not staged_exe.is_file() or staged_exe.stat().st_size < 1_000_000:
            raise RuntimeError("Staged Tracker build is missing or suspiciously small; installed engine was preserved.")
        bin_dir = root / "bin"
        bin_dir.mkdir(parents=True, exist_ok=True)
        final_exe = bin_dir / "l4_tracker.exe"
        replacement = bin_dir / ("l4_tracker.exe.new-" + str(os.getpid()))
        shutil.copy2(staged_exe, replacement)
        if replacement.stat().st_size != staged_exe.stat().st_size:
            replacement.unlink(missing_ok=True)
            raise RuntimeError("Staged Tracker engine copy failed validation; installed engine was preserved.")
        os.replace(replacement, final_exe)
    models_dir = root / "models"
    say(f"SUCCESS: Tracker engine ready ({final_exe.stat().st_size:,} bytes). Models are stored in {models_dir}.")


def selftest(root):
    """Exercise validation, repair, and failure handling only in a temporary directory.

    This intentionally performs no network requests and never reads/writes the real
    extension's models, engine, presets, or installed executable.
    """
    say("L4XYVS Component Manager — SAFE SELF-TEST")
    say("Scope: temporary test directory only; no real components will be changed.")
    checks = []
    # Validate the real manifest without downloading or changing real components.
    try:
        catalog = load_catalog(root)
        tracker_models = next((m for m in catalog["modules"] if m["id"] == "tracker-models"), None)
        catalog_ok = bool(tracker_models and len(tracker_models["files"]) == 3)
    except Exception as exc:
        catalog_ok = False
        say("Manifest validation detail: " + str(exc))
    checks.append(("module catalog schema and tracker entries valid", catalog_ok))
    say(("PASS" if catalog_ok else "FAIL") + ": module catalog schema and tracker entries valid")
    with tempfile.TemporaryDirectory(prefix="l4xy_component_selftest_") as temp_name:
        temp = Path(temp_name)
        model = temp / "fixture.onnx"
        minimum = 128

        # Download validation: a sufficiently sized fixture is accepted.
        model.write_bytes(b"L4XYVS_TEST_MODEL\0" + b"x" * 256)
        valid = model.exists() and model.stat().st_size >= minimum
        checks.append(("valid file accepted", valid))
        say(("PASS" if valid else "FAIL") + ": valid file accepted")
        expected_fixture_hash = _sha256_file(model)
        hash_match = _file_matches(model, minimum, expected_fixture_hash)
        checks.append(("pinned SHA-256 accepts matching file", hash_match))
        say(("PASS" if hash_match else "FAIL") + ": pinned SHA-256 accepts matching file")
        hash_mismatch_rejected = not _file_matches(model, minimum, "0" * 64)
        checks.append(("pinned SHA-256 rejects mismatched file", hash_mismatch_rejected))
        say(("PASS" if hash_mismatch_rejected else "FAIL") + ": pinned SHA-256 rejects mismatched file")

        # Incomplete download: reject and remove only the temporary fixture.
        model.write_bytes(b"short")
        rejected = model.stat().st_size < minimum
        if rejected:
            model.unlink()
        checks.append(("incomplete file rejected", rejected and not model.exists()))
        say(("PASS" if checks[-1][1] else "FAIL") + ": incomplete file rejected and isolated fixture cleaned")

        # Repair behavior: replace a corrupt temporary fixture atomically.
        corrupt = temp / "repair_target.onnx"
        corrupt.write_bytes(b"bad")
        staged = temp / "repair_target.onnx.download"
        staged.write_bytes(b"R" * 256)
        if staged.stat().st_size >= minimum:
            os.replace(staged, corrupt)
        repaired = corrupt.exists() and corrupt.stat().st_size >= minimum and not staged.exists()
        checks.append(("repair replacement validated", repaired))
        say(("PASS" if repaired else "FAIL") + ": repair replacement validated")

        # Failure handling: a simulated download error must not overwrite an existing target.
        protected = temp / "protected.onnx"
        protected.write_bytes(b"previous-valid-fixture")
        before = hashlib.sha256(protected.read_bytes()).hexdigest()
        simulated_network_error = True
        after = hashlib.sha256(protected.read_bytes()).hexdigest()
        preserved = simulated_network_error and before == after
        checks.append(("failed download preserves prior file", preserved))
        say(("PASS" if preserved else "FAIL") + ": simulated download failure preserves prior file")

        lfs = temp / "lfs_pointer.onnx"
        lfs.write_text("version https://git-lfs.github.com/spec/v1\noid sha256:deadbeef\nsize 9999999\n", encoding="utf-8")
        pointer_rejected = _looks_like_lfs_pointer(lfs)
        checks.append(("Git LFS pointer rejected", pointer_rejected))
        say(("PASS" if pointer_rejected else "FAIL") + ": Git LFS pointer rejected")

        # A manifest-style staged install is simulated using only temporary files.
        staged_target = temp / "module" / "sample.bin"
        staged_target.parent.mkdir(parents=True, exist_ok=True)
        staged_file = staged_target.with_suffix(".bin.download")
        staged_file.write_bytes(b"L4XYVS_SAMPLE_MODULE" + b"x" * 256)
        if staged_file.stat().st_size >= minimum:
            os.replace(staged_file, staged_target)
        manifest_install_ok = staged_target.is_file() and staged_target.stat().st_size >= minimum and not staged_file.exists()
        checks.append(("manifest-style staged install activates validated file", manifest_install_ok))
        say(("PASS" if manifest_install_ok else "FAIL") + ": manifest-style staged install activates validated file")

        # Multi-file activation failure must roll back every already-activated target.
        txn = temp / "transaction"
        txn.mkdir()
        old_a, old_b = txn / "a.bin", txn / "b.bin"
        new_a, new_b = txn / "a.new", txn / "b.new"
        old_a.write_bytes(b"old-A")
        old_b.write_bytes(b"old-B")
        new_a.write_bytes(b"new-A")
        new_b.write_bytes(b"new-B")
        try:
            _activate_staged_files([(new_a, old_a), (new_b, old_b)], fail_after=1)
            transaction_rollback = False
        except OSError:
            transaction_rollback = old_a.read_bytes() == b"old-A" and old_b.read_bytes() == b"old-B"
        checks.append(("multi-file activation failure rolls back", transaction_rollback))
        say(("PASS" if transaction_rollback else "FAIL") + ": multi-file activation failure rolls back")

        # A complete multi-file activation should activate both staged targets.
        new_a.write_bytes(b"new-A")
        new_b.write_bytes(b"new-B")
        try:
            _activate_staged_files([(new_a, old_a), (new_b, old_b)])
            transaction_commit = old_a.read_bytes() == b"new-A" and old_b.read_bytes() == b"new-B"
        except Exception:
            transaction_commit = False
        checks.append(("multi-file activation commits all files", transaction_commit))
        say(("PASS" if transaction_commit else "FAIL") + ": multi-file activation commits all files")

    passed = sum(1 for _, ok in checks if ok)
    say(f"SELF-TEST RESULT: {passed}/{len(checks)} checks passed.")
    say("Real extension components were not installed, deleted, or modified.")
    return 0 if passed == len(checks) else 1


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("action", choices=("caption", "tracker", "selftest", "install-module"))
    parser.add_argument("--module", default="")
    parser.add_argument("--root", required=True)
    args = parser.parse_args()
    root = Path(args.root).resolve()
    say("L4XYVS Component Manager — " + args.action)
    say("Extension folder: " + str(root))
    try:
        if args.action == "selftest":
            return selftest(root)
        if args.action == "install-module":
            if not args.module:
                raise RuntimeError("--module is required for install-module.")
            install_module(root, args.module)
        elif args.action == "caption":
            setup_caption(root)
        else:
            setup_tracker(root)
    except subprocess.CalledProcessError as exc:
        say("ERROR: A setup command failed with exit code " + str(exc.returncode))
        return exc.returncode or 1
    except Exception as exc:
        say("ERROR: " + str(exc))
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
