"""L4XYVS SUITE — local Whisper word-timestamp CLI (called by the panel).
Same output schema as the original l4_word_timestamps.py, no GUI.
Protocol on stdout: STAGE|text, DONE|json_path, ERR|message
"""
import argparse, json, os, sys
from pathlib import Path

def say(kind, text=""):
    sys.stdout.write(f"{kind}|{text}\n"); sys.stdout.flush()

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--input", required=True)
    ap.add_argument("--output", required=True)
    ap.add_argument("--model", default="small")
    ap.add_argument("--check", action="store_true")
    a = ap.parse_args()
    try:
        import whisper
    except Exception as exc:
        say("ERR", f"Whisper not installed ({exc}). Run: py -3 -m pip install -U openai-whisper")
        return 2
    if a.check:
        say("DONE", "whisper-ok"); return 0
    try:
        say("STAGE", f"Loading Whisper model ({a.model})")
        model = whisper.load_model(a.model)
        say("STAGE", "Transcribing")
        result = model.transcribe(a.input, word_timestamps=True, verbose=False, fp16=False)
        words = []
        for seg in result.get("segments", []):
            for w in seg.get("words", []) or []:
                t = str(w.get("word", "")).strip()
                if not t: continue
                words.append({"word": t, "start": round(float(w["start"]), 4), "end": round(float(w["end"]), 4),
                              "segment_start": round(float(seg.get("start", 0.0)), 4),
                              "segment_end": round(float(seg.get("end", 0.0)), 4)})
        payload = {"schema": "l4-text-style-1-word-timestamps-v1", "source_file": os.path.basename(a.input),
                   "language": result.get("language"), "transcript": str(result.get("text", "")).strip(),
                   "word_count": len(words),
                   "timing_note": "Whisper word timestamps are estimates; review against the audio.", "words": words}
        Path(a.output).write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")
        say("DONE", a.output)
        return 0
    except Exception as exc:
        say("ERR", f"{type(exc).__name__}: {exc}")
        return 1

if __name__ == "__main__":
    sys.exit(main())
