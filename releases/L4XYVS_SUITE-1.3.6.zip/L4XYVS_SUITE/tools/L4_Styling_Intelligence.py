#!/usr/bin/env python3
"""L4 Suite local caption styling: Ollama first, deterministic contextual fallback.
Uses only local Ollama; no cloud API. Input/output schema remains compatible with v16.4 JSX.
"""
import argparse
import json
import re
import urllib.request
from pathlib import Path

# Style IDs are semantic labels only; JSX owns the approved font/color registry.
VALID = {
    "neutral", "barber_chop", "basketball", "black_ops_one",
    "devil_candle", "game_of_thrones", "hooge_05_55", "limelight",
}

# These are semantic cues, not a blanket instruction to style every line.
# Orange is broadened to include grave, high-impact revelations, not only threats.
DRAMATIC_PATTERNS = [
    r"\b(destroy|kill|murder|burn|crush|revenge|pay for this|you will pay|you'll pay|i will find you|i'll find you|i will end you|i'll end you|you will regret|you'll regret|shut up|get out|leave me alone|i hate you|traitor)\b",
    r"\bcrime network\b",
    r"\bworld has ever seen\b",
    r"\bcocaine\b",
    r"\btime at a child\b",
    r"\byears straight every day\b",
    r"\bsell\b.{0,45}\b(child|kid|five year old|14 year old|fourteen year old)\b",
    r"\b(five year old kid|five to 10 times a day|10 years straight|times a day)\b",
    r"\btoo ugly for polite conversation\b",
]
EMOTIONAL_PATTERNS = [
    r"\b(most precious child|precious child)\b",
    r"\b(grew up so fast|she's grew up so fast|she grew up so fast)\b",
    r"\b(love you|loved you|loving you|never stopped loving|i miss you|miss you|forgive me|i'm sorry|i am sorry|please don't go|don't leave me|i need you|i lost you|i lost him|i lost her|i'm scared|i am scared|i'm afraid|i am afraid|believe in you|proud of you|heartbroken|goodbye forever|last goodbye|my son|my daughter|my mother|my father)\b",
]
IMPORTANT_PATTERNS = [
    r"\b14 years old\b",
    r"\bsince she was six\b",
    r"\bfastest growing international crime network\b",
    r"\bworld has ever seen\b",
    r"\bthey don't want to hear it\b",
]

def norm(s):
    return re.sub(r"\s+", " ", str(s or "")).strip().lower()

STYLE_IDS = ["barber_chop", "basketball", "black_ops_one", "devil_candle", "game_of_thrones", "hooge_05_55", "limelight"]
COLOR_IDS = ["coral", "amber", "ice_blue", "cyan", "silver", "crimson", "violet", "gold", "mint", "soft_gold"]

# Semantic family preferences; these are preferences, not fixed one-to-one mappings.
def semantic_family(text):
    t = norm(text)
    if re.search(r"\b(kill|murder|blood|dead|die|devil|monster|threat|destroy|revenge|traitor|hate you|pay for this|you will pay|you'll pay)\b", t):
        return "dark"
    if re.search(r"\b(run|hurry|quick|move|fight|attack|now|stop him|come on|let's go|lets go)\b", t):
        return "energetic"
    if any(re.search(p, t) for p in EMOTIONAL_PATTERNS):
        return "emotional"
    if re.search(r"\b(king|queen|kingdom|destiny|legend|warrior|throne|honor|honour|empire|prophecy|eternal|forever)\b", t):
        return "epic"
    if any(re.search(p, t) for p in DRAMATIC_PATTERNS + IMPORTANT_PATTERNS):
        return "revelation"
    if re.search(r"\b(showtime|look at me|remember this|watch this|surprise|welcome|the truth is|listen carefully)\b", t):
        return "theatrical"
    return "ordinary"

FAMILY_STYLES = {
    "dark": ["devil_candle", "black_ops_one", "barber_chop", "game_of_thrones"],
    "energetic": ["basketball", "barber_chop", "black_ops_one", "limelight"],
    "emotional": ["hooge_05_55", "limelight", "game_of_thrones", "black_ops_one"],
    "epic": ["game_of_thrones", "black_ops_one", "limelight", "barber_chop"],
    "revelation": ["black_ops_one", "game_of_thrones", "hooge_05_55", "limelight", "barber_chop"],
    "theatrical": ["limelight", "basketball", "hooge_05_55", "game_of_thrones"],
    "ordinary": STYLE_IDS,
}

STYLE_COLORS = {
    "barber_chop": ["crimson", "coral", "silver", "ice_blue", "violet"],
    "basketball": ["amber", "coral", "cyan", "ice_blue", "mint"],
    "black_ops_one": ["ice_blue", "silver", "cyan", "coral", "gold"],
    "devil_candle": ["crimson", "violet", "silver", "coral", "ice_blue"],
    "game_of_thrones": ["gold", "soft_gold", "ice_blue", "silver", "violet"],
    "hooge_05_55": ["mint", "cyan", "coral", "soft_gold", "silver"],
    "limelight": ["cyan", "coral", "gold", "violet", "mint"],
}


def choose_style(family, index, recent_styles):
    """Prefer suitable styles used least often recently; stable rotation breaks ties."""
    candidates = FAMILY_STYLES.get(family, STYLE_IDS)
    recent = recent_styles[-6:]
    counts = {style: recent.count(style) for style in candidates}
    min_count = min(counts.values()) if counts else 0
    least_used = [style for style in candidates if counts[style] == min_count]
    # Deterministic tie-breaker gives repeatable projects while not hard-coding one font per emotion.
    start_at = (index - 1) % max(1, len(candidates))
    rotated = candidates[start_at:] + candidates[:start_at]
    for candidate in rotated:
        if candidate in least_used and candidate not in recent[-2:]:
            return candidate
    for candidate in rotated:
        if candidate in least_used:
            return candidate
    return rotated[0]


def choose_color(style, index, recent_colors):
    """Choose from the palette while balancing recent global colour use, not just font-specific use."""
    candidates = STYLE_COLORS.get(style, ["ice_blue", "coral", "gold", "cyan", "silver"])
    recent = recent_colors[-7:]
    counts = {color: recent.count(color) for color in candidates}
    min_count = min(counts.values()) if counts else 0
    least_used = [color for color in candidates if counts[color] == min_count]
    start_at = (index - 1) % max(1, len(candidates))
    ordered = candidates[start_at:] + candidates[:start_at]
    for color in ordered:
        if color in least_used and color not in recent[-3:]:
            return color
    for color in ordered:
        if color in least_used and (not recent or color != recent[-1]):
            return color
    return least_used[0] if least_used else candidates[0]


def make_decisions(captions, model_styles=None):
    """Strict sequential lower-line font and colour rotation.

    Fonts rotate in the approved seven-font order. Colours rotate independently
    through the user's six HEX colours. Game of Thrones is always orange (#FFAE00).
    Only occasional ordinary captions remain natural white Arial; natural captions
    do not advance either rotation counter.
    """
    decisions = []
    styled_font_count = 0
    styled_color_count = 0
    last_was_natural = False
    natural_count = 0
    font_order = [
        "barber_chop", "basketball", "black_ops_one", "devil_candle",
        "game_of_thrones", "hooge_05_55", "limelight"
    ]
    color_order = ["ff0000", "ff0084", "9c00ff", "0078ff", "00ff30", "ffae00"]
    for pos, cap in enumerate(captions):
        idx = int(cap["index"])
        text = str(cap.get("text", ""))
        family = semantic_family(text)
        ordinary = family == "ordinary"
        # Keep natural styling rare: at most about one in twelve ordinary captions.
        # Use a stable position cadence, but never put natural captions back-to-back.
        recent_natural = sum(1 for d in decisions[-10:] if d["style_id"] == "neutral")
        natural_slot = (idx % 12 == 0) and ordinary and recent_natural == 0 and not last_was_natural
        if natural_slot:
            style = "neutral"
            color = "neutral_white"
            reason = "rare natural reset; fixed font/colour counters preserved"
            natural_count += 1
            last_was_natural = True
        else:
            style = font_order[styled_font_count % len(font_order)]
            color = color_order[styled_color_count % len(color_order)]
            styled_font_count += 1
            styled_color_count += 1
            if style == "game_of_thrones":
                color = "ffae00"  # locked orange regardless of colour-rotation slot
            reason = "fixed seven-font rotation; independent six-colour HEX rotation"
            last_was_natural = False
        decisions.append({
            "index": idx, "style_id": style, "color_id": color,
            "reason": reason, "family": family,
            "font_rotation_position": (styled_font_count - 1) % 7 if style != "neutral" else None,
            "color_rotation_position": (styled_color_count - 1) % 6 if style != "neutral" else None
        })
    return decisions

def analyze(captions):
    normalized = []
    for pos, cap in enumerate(captions):
        if isinstance(cap, dict):
            normalized.append({"index": int(cap.get("index", pos + 1)), "text": str(cap.get("text", ""))})

    payload = {
        "model": "qwen2.5:3b", "stream": False, "format": "json",
        "options": {"temperature": 0.0},
        "messages": [
            {"role": "system", "content": (
                "Classify each caption's best lower-line font style. Return JSON only: "
                "{\"decisions\":[{\"index\":1,\"style_id\":\"neutral\"}]}. "
                "Return exactly one decision per caption, preserve indices. Allowed style IDs: neutral, barber_chop, basketball, black_ops_one, devil_candle, game_of_thrones, hooge_05_55, limelight. "
                "Use neutral only for ordinary lines. dark threats prefer devil_candle/black_ops_one/barber_chop; energetic lines prefer basketball/barber_chop; "
                "emotional lines prefer hooge_05_55/limelight; epic lines prefer game_of_thrones/black_ops_one; theatrical lines prefer limelight. "
                "Do not output colours, font names, or extra IDs."
            )},
            {"role": "user", "content": json.dumps({"captions": normalized}, ensure_ascii=False)}
        ]
    }
    provider = "local_context_rules_fallback"
    model_by_index = {}
    try:
        req = urllib.request.Request(
            "http://127.0.0.1:11434/api/chat", data=json.dumps(payload).encode("utf-8"),
            headers={"Content-Type": "application/json"}, method="POST")
        with urllib.request.urlopen(req, timeout=180) as resp:
            response = json.loads(resp.read().decode("utf-8"))
        model_data = json.loads(response["message"]["content"])
        for item in model_data.get("decisions", []):
            if isinstance(item, dict):
                try:
                    idx = int(item.get("index", -1))
                    sid = str(item.get("style_id", "neutral"))
                    if sid in VALID:
                        model_by_index[idx] = sid
                except (TypeError, ValueError):
                    pass
        provider = "local_ollama+context_variety_rules"
    except Exception:
        pass

    decisions = make_decisions(normalized, model_by_index)
    return decisions, provider

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--input", required=True)
    ap.add_argument("--output", required=True)
    args = ap.parse_args()
    source = json.loads(Path(args.input).read_text(encoding="utf-8-sig"))
    captions = source.get("captions", [])
    try:
        decisions, provider = analyze(captions)
        result = {"ok": True, "decisions": decisions, "provider": provider, "model": "qwen2.5:3b" if "ollama" in provider else None,
                  "font_registry_version": "ae_font_audit_2026-10-17",
                  "styling_engine_version": "v10_fixed_rotation_visual_size_support",
                  "verified_fonts": {"barber_chop": "BarberChop", "basketball": "Basketball", "black_ops_one": "BlackOpsOne-Regular", "devil_candle": "DevilCandleAlt-PERSONALUSE", "game_of_thrones": "GameofThrones", "hooge_05_55": "hooge_05_55", "limelight": "Limelight"}}
    except Exception as exc:
        result = {"ok": False, "error": str(exc), "decisions": [{"index": int(c["index"]), "style_id": "neutral"} for c in captions]}
    Path(args.output).write_text(json.dumps(result, ensure_ascii=False), encoding="utf-8")

if __name__ == "__main__":
    main()
