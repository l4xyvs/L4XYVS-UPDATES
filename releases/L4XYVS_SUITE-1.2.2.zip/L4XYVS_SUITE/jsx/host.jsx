﻿// L4XYVS SUITE — host script (ExtendScript). Auto Caption / L4 Style 1 + L4 Style 2.
// Style 1 = approved L4 Text Style 1 v16.6.x; Style 2 (L4_generate2) = Full Dialogue Prototype v15 SMART LINE BREAKS; only its dialogs were replaced
// by panel configuration, plus progress/log hooks for the panel.

function L4_json(v) {
    if (v === null || v === undefined) return "null";
    var t = typeof v;
    if (t === "number") return isFinite(v) ? String(v) : "null";
    if (t === "boolean") return v ? "true" : "false";
    if (t === "string") {
        return '"' + v.replace(/\\/g, "\\\\").replace(/"/g, '\\"').replace(/\r/g, "\\r").replace(/\n/g, "\\n").replace(/\t/g, "\\t") + '"';
    }
    if (v instanceof Array) { var a = []; for (var i = 0; i < v.length; i++) a.push(L4_json(v[i])); return "[" + a.join(",") + "]"; }
    var o = []; for (var k in v) if (v.hasOwnProperty(k)) o.push(L4_json(k) + ":" + L4_json(v[k]));
    return "{" + o.join(",") + "}";
}

function L4_logFile() { return new File(Folder.temp.fsName + "/l4xyvs_progress.txt"); }
function L4_resetLog() { try { var f = L4_logFile(); if (f.exists) f.remove(); } catch (e) {} }
function L4_emit(kind, text) {
    try {
        var f = L4_logFile(); f.encoding = "UTF-8";
        if (f.open("a")) { f.writeln(kind + "|" + String(text).replace(/[\r\n]+/g, " ")); f.close(); }
    } catch (e) {}
}

function L4_preflight() {
    var r = { ok: true, temp: Folder.temp.fsName, ae: String(app.version), kind: "none" };
    try {
        r.perm = (app.preferences.getPrefAsLong("Main Pref Section", "Pref_SCRIPTING_FILE_NETWORK_SECURITY") === 1);
    } catch (e) { r.perm = true; }
    try {
        var c = app.project ? app.project.activeItem : null;
        r.isComp = (c instanceof CompItem);
        if (r.isComp) {
            r.comp = c.name;
            r.sel = c.selectedLayers.length;
            if (r.sel === 1) {
                var L = c.selectedLayers[0];
                r.layer = L.name;
                try {
                    if (L instanceof AVLayer && L.source) {
                        if (L.source instanceof CompItem) r.kind = "comp";
                        else if (L.source.mainSource instanceof FileSource && !L.source.mainSource.isStill) r.kind = "footage";
                        r.hasAudio = !!L.hasAudio;
                    }
                } catch (e3) {}
            }
        }
    } catch (e2) { r.isComp = false; }
    return L4_json(r);
}

// Resolves the audio for the selected layer: footage -> its own file; pre-comp -> rendered WAV.
function L4_getAudio(outPath) {
    var r = { ok: false, message: "" };
    var queued = [], item = null;
    try {
        var comp = app.project ? app.project.activeItem : null;
        if (!(comp instanceof CompItem)) { r.message = "Open a composition first."; return L4_json(r); }
        if (comp.selectedLayers.length !== 1) { r.message = "Select one audio, video or pre-comp layer."; return L4_json(r); }
        var L = comp.selectedLayers[0];
        r.layer = L.name; r.offset = Number(L.startTime) || 0; r.stretch = Number(L.stretch) || 100;
        var src = L.source;
        if (src instanceof CompItem) {
            r.kind = "comp";
            L4_emit("LOG", "Rendering audio from pre-comp: " + src.name);
            var f = new File(outPath); if (f.exists) f.remove();
            var rq = app.project.renderQueue, i;
            for (i = 1; i <= rq.numItems; i++) {
                if (rq.item(i).status === RQItemStatus.QUEUED) { queued.push(i); rq.item(i).render = false; }
            }
            item = rq.items.add(src);
            var om = item.outputModule(1);
            om.setSettings({ "Video Output": false, "Output Audio": "On", "Format": "WAV" });
            om.file = f;
            item.render = true;
            rq.render();
            try { item.remove(); } catch (e1) {}
            item = null;
            for (i = 0; i < queued.length; i++) { try { rq.item(queued[i]).render = true; } catch (e2) {} }
            queued = [];
            if (!f.exists || f.length < 1000) { r.message = "Audio render produced no file. Make sure the pre-comp has audio."; return L4_json(r); }
            r.audioPath = f.fsName;
        } else if (src && src.mainSource instanceof FileSource && src.mainSource.file) {
            r.kind = "footage";
            r.audioPath = src.mainSource.file.fsName;
        } else { r.message = "This layer has no audio source."; return L4_json(r); }
        r.ok = true;
    } catch (e) {
        r.message = e.toString();
        try { if (item) item.remove(); } catch (e4) {}
        try { var rq2 = app.project.renderQueue; for (var q = 0; q < queued.length; q++) rq2.item(queued[q]).render = true; } catch (e5) {}
    }
    return L4_json(r);
}

function L4_prepare(argJson) {
    var a = eval("(" + argJson + ")");
    var r = { ok: false, message: "" };
    var open = false;
    try {
        var comp = app.project ? app.project.activeItem : null;
        if (!(comp instanceof CompItem)) { r.message = "Open a composition first."; return L4_json(r); }
        var f = new File(a.ffx);
        if (!f.exists) { r.message = "Animation preset not found: " + a.ffx; return L4_json(r); }
        app.beginUndoGroup("L4 — Create template layer"); open = true;
        var tl = comp.layers.addText(a.name || "L4 STYLE");
        tl.name = (a.name || "L4 STYLE") + " — Template";
        tl.applyPreset(f);
        for (var i = 1; i <= comp.numLayers; i++) comp.layer(i).selected = false;
        tl.selected = true;
        app.endUndoGroup(); open = false;
        r.ok = true; r.layer = tl.name;
    } catch (e) {
        if (open) { try { app.endUndoGroup(); } catch (e2) {} }
        r.message = e.toString();
    }
    return L4_json(r);
}

function L4_generate(cfgJson) {
    var cfg = eval("(" + cfgJson + ")");
    var RESULT = { ok: false, message: "", summary: "" };
    (function () {
        var TITLE = "L4 Style 1";
        function tell(s) { RESULT.message = String(s); L4_emit("ERR", String(s).split("\n")[0]); }
        L4_emit("STAGE", "Checking project"); L4_emit("PROG", "0.01");
        if (!app.project) { tell("Open your After Effects project first."); return; }
        var comp = app.project.activeItem;
        if (!(comp instanceof CompItem)) { tell("Open the composition containing your original FFX-styled text layer."); return; }
        if (comp.selectedLayers.length !== 1) { tell("Select exactly ONE text layer with the original main text animation.ffx applied."); return; }
        var source = comp.selectedLayers[0];
        if (!source.property("ADBE Text Properties")) { tell("The selected layer is not a text layer."); return; }

        var jsonFile = new File(cfg.jsonPath);
        if (!jsonFile.exists) { tell("Timestamp JSON not found:\n" + cfg.jsonPath); return; }
        jsonFile.encoding = "UTF-8";
        if (!jsonFile.open("r")) { tell("Could not read the JSON file."); return; }
        var raw = jsonFile.read(); jsonFile.close();
        var data;
        try {
            if (typeof JSON !== "undefined" && JSON.parse) data = JSON.parse(raw);
            else data = eval("(" + raw + ")");
        } catch (e) { tell("Could not parse JSON:\n" + e.toString()); return; }
        if (!data.words || !data.words.length) { tell("JSON contains no word timestamps."); return; }

        // Audio-sync guard: match the JSON source filename to an audio-capable layer.
        // Only apply automatic offset when the exact source matches and layer stretch is 100%.
        // Never guess from an unrelated audio layer; the offset remains editable.
        function baseFileName(value) {
            return String(value || "").replace(/\\/g, "/").split("/").pop().toLowerCase();
        }
        var matchedAudioLayer = null;
        var autoOffset = 0;
        var autoOffsetApplied = false;
        var audioOffsetNote = "No exact matching audio layer found; offset remains manual (0 seconds).";
        var jsonSourceName = baseFileName(data.source_file || "");
        if (jsonSourceName) {
            for (var audioIndex = 1; audioIndex <= comp.numLayers; audioIndex++) {
                var audioCandidate = comp.layer(audioIndex);
                try {
                    if (!audioCandidate.hasAudio || !audioCandidate.source) continue;
                    if (baseFileName(audioCandidate.source.name) !== jsonSourceName) continue;
                    matchedAudioLayer = audioCandidate;
                    var stretchPercent = 100;
                    try { stretchPercent = Number(audioCandidate.stretch); } catch (stretchReadErr) {}
                    if (Math.abs(stretchPercent - 100) < 0.001) {
                        autoOffset = Number(audioCandidate.startTime) || 0;
                        autoOffsetApplied = true;
                        audioOffsetNote = "Matched audio layer: " + audioCandidate.name +
                            " (offset auto-filled from its start time; editable below).";
                    } else {
                        audioOffsetNote = "Matched audio layer: " + audioCandidate.name +
                            ", but its stretch is " + stretchPercent +
                            "%. Automatic offset was not applied; verify timing manually.";
                    }
                    break;
                } catch (audioMatchErr) {}
            }
        }


        var pauseThreshold = parseFloat(cfg.pause);
        var maxLinePercent = parseFloat(cfg.width);
        var offset = (cfg.offset === "auto" || cfg.offset === "" || cfg.offset === null) ? autoOffset : parseFloat(cfg.offset);
        var fadeDuration = parseFloat(cfg.fade);
        var wipeLead = parseFloat(cfg.wipeLead);
        var wipeDuration = parseFloat(cfg.wipeDuration);
        var disableSourceAfter = !!cfg.hideSource;
        if (cfg.offset === "auto") L4_emit("LOG", audioOffsetNote);
        L4_emit("LOG", "Offset " + (isNaN(offset) ? "?" : offset.toFixed(3)) + "s · " + data.words.length + " words loaded");
        L4_emit("PROG", "0.03"); L4_emit("STAGE", "Planning captions");
        if (isNaN(pauseThreshold) || pauseThreshold < 0 ||
            isNaN(maxLinePercent) || maxLinePercent < 40 || maxLinePercent > 98 ||
            isNaN(offset) || isNaN(fadeDuration) || fadeDuration <= 0 ||
            isNaN(wipeLead) || wipeLead < 0 ||
            isNaN(wipeDuration) || wipeDuration <= 0) {
            tell("Invalid settings. Pause/lead must be non-negative, safe width 40–98% of the composition, and fade/wipe durations positive."); return;
        }

        // Validate timestamps before changing the project.
        for (var vi = 0; vi < data.words.length; vi++) {
            var vw = data.words[vi];
            if (!vw || isNaN(Number(vw.start)) || isNaN(Number(vw.end)) || Number(vw.end) < Number(vw.start)) {
                tell("Invalid timestamp at word " + (vi + 1) + ". No layers were created."); return;
            }
            if (vi > 0 && Number(vw.start) < Number(data.words[vi - 1].start)) {
                tell("Word timestamps are not in chronological order near word " + (vi + 1) + ". No layers were created."); return;
            }
        }

        function cleanWord(w) { return String(w.word || "").replace(/^\s+|\s+$/g, ""); }

        // AE's sourceRectAtTime measurement on a temporary duplicate can under-report the
        // final rendered width of text that uses the template's tracking/effects. Apply a
        // conservative 15% layout allowance so captions split earlier, inside the safe area.
        // This does NOT scale text or change any FFX/animation properties.
        var SAFE_WIDTH_MEASURE_FACTOR = 1.15;

        function createCaptionGroups(allWords, widthPercent) {
            var measureLayer = null;
            try {
                // Measure on a temporary duplicate, never on the user's source layer.
                measureLayer = source.duplicate();
                measureLayer.name = "__L4_TEMP_WIDTH_MEASURE__";
                var measureTextProps = measureLayer.property("ADBE Text Properties");
                var measureDocProp = measureTextProps.property("ADBE Text Document");
                var baseDoc = measureDocProp.value;
                var fontSize = Number(baseDoc.fontSize) || 42;
                var scaleX = 100;
                try { scaleX = Math.abs(Number(measureLayer.property("ADBE Transform Group").property("ADBE Scale").value[0])) || 100; } catch (scaleErr) {}
                if (scaleX < 0.01) scaleX = 100;
                var maxWidth = comp.width * (widthPercent / 100) / (scaleX / 100);
                var widthCache = {};
                var usingFallback = false;

                // Remove text animators from the temporary measuring duplicate so its bounds
                // reflect the actual styled glyphs, not a keyed selector at the current time.
                var measureAnimators = measureTextProps.property("ADBE Text Animators");
                if (measureAnimators) {
                    for (var ma = measureAnimators.numProperties; ma >= 1; ma--) measureAnimators.property(ma).remove();
                }
                function fallbackWidth(text) {
                    var width = 0;
                    for (var fc = 0; fc < text.length; fc++) {
                        var ch = text.charAt(fc);
                        if (/\s/.test(ch)) width += fontSize * 0.32;
                        else if (/[I1\.,'!:;]/.test(ch)) width += fontSize * 0.30;
                        else if (/[MW@%]/.test(ch)) width += fontSize * 0.82;
                        else width += fontSize * 0.58;
                    }
                    return width;
                }
                function textWidth(text) {
                    var cacheKey = "$" + text;
                    if (widthCache[cacheKey] !== undefined) return widthCache[cacheKey];
                    var width = 0;
                    try {
                        var doc = measureDocProp.value;
                        doc.text = text;
                        measureDocProp.setValue(doc);
                        if (typeof measureLayer.sourceRectAtTime === "function") {
                            var rect = measureLayer.sourceRectAtTime(0, false);
                            width = Number(rect.width) || 0;
                        }
                    } catch (measureErr) { width = 0; }
                    if (!(width > 0)) { usingFallback = true; width = fallbackWidth(text); }
                    width = width * SAFE_WIDTH_MEASURE_FACTOR;
                    widthCache[cacheKey] = width;
                    return width;
                }
                function lineString(words) {
                    var tokens = [];
                    for (var i = 0; i < words.length; i++) tokens.push(cleanWord(words[i]).toUpperCase());
                    return tokens.join(" ");
                }
                function bestLineSplit(words) {
                    var n = words.length;
                    if (n <= 3) return textWidth(lineString(words)) <= maxWidth || n === 1 ? 0 : -1;
                    var best = -1, bestScore = 999999;
                    // Prefer natural phrase boundaries while still balancing both lines.
                    // Never alter font size, word order, audio timestamps, or animation keys.
                    var weakLineEnd = /^(A|AN|THE|OF|TO|IN|ON|AT|BY|FOR|FROM|WITH|AS|AND|OR|BUT|NOR|SO|YET|IF|THAT|THIS|IS|ARE|WAS|WERE|BE|BEEN|BEING|MY|YOUR|HIS|HER|OUR|THEIR)$/i;
                    for (var sp = 1; sp < n; sp++) {
                        var left = words.slice(0, sp), right = words.slice(sp);
                        var leftWidth = textWidth(lineString(left));
                        var rightWidth = textWidth(lineString(right));
                        if (leftWidth > maxWidth || rightWidth > maxWidth) continue;
                        var score = Math.abs(left.length - right.length) * 100 + Math.abs(leftWidth - rightWidth);
                        var leftToken = cleanWord(words[sp - 1]);
                        var rightToken = cleanWord(words[sp]);
                        // A comma/semicolon/colon/dash is a strong visual phrase boundary.
                        if (/[,:;—–-]["'\)\]]*$/.test(leftToken)) score -= 85;
                        // Avoid ending line one on a small connector/article where possible.
                        if (weakLineEnd.test(leftToken.replace(/[.!?…,:;]+$/, ""))) score += 145;
                        // Avoid beginning line two with a punctuation-only token.
                        if (/^[,;:!?…]+$/.test(rightToken)) score += 1000;
                        // Tiny final words often read better attached to the previous phrase.
                        if (sp === n - 1 && /^(A|AN|THE|OF|TO|IN|ON|AT|BY|FOR|WITH|AND|OR)$/i.test(rightToken)) score += 45;
                        if (score < bestScore) { bestScore = score; best = sp; }
                    }
                    return best;
                }
                function fitsCaption(words) {
                    if (words.length <= 3) return textWidth(lineString(words)) <= maxWidth || words.length === 1;
                    return bestLineSplit(words) >= 0;
                }
                function endsSentence(word) { return /[.!?…]["'\)\]]*$/.test(cleanWord(word)); }
                function makeText(words) {
                    var line = lineString(words);
                    if (words.length <= 3) {
                        words.captionSplitIndex = words.length;
                        return line;
                    }
                    var split = bestLineSplit(words);
                    if (split < 1) split = Math.ceil(words.length / 2); // fallback only for an exceptionally wide single token
                    words.captionSplitIndex = split;
                    return lineString(words.slice(0, split)) + "\r" + lineString(words.slice(split));
                }

                var result = [], current = [];
                for (var wi = 0; wi < allWords.length; wi++) {
                    var word = allWords[wi];
                    if (current.length > 0) {
                        var prev = current[current.length - 1];
                        var gap = Number(word.start) - Number(prev.end);
                        var candidate = current.concat([word]);
                        var splitForPause = gap >= pauseThreshold;
                        var splitForPunctuation = endsSentence(prev);
                        var splitForWordLimit = current.length >= 8;
                        var splitForWidth = !fitsCaption(candidate);
                        if (splitForPause || splitForPunctuation || splitForWordLimit || splitForWidth) {
                            current.captionText = makeText(current);
                            result.push(current);
                            current = [];
                        }
                    }
                    current.push(word);
                }
                if (current.length) { current.captionText = makeText(current); result.push(current); }
                result.usedWidthFallback = usingFallback;
                result.maxWidth = maxWidth;
                return result;
            } finally {
                if (measureLayer) { try { measureLayer.remove(); } catch (removeErr) {} }
            }
        }
        var groups;
        try { groups = createCaptionGroups(data.words, maxLinePercent); }
        catch (groupErr) { tell("Could not safely calculate caption layout:\n" + groupErr.toString() + "\nNo caption layers were generated."); return; }

        // Fixed safe-area audit. Font size is never changed; any individual word wider than
        // the safe width is left intact on its own caption line and reported to the user.
        var oversizedWords = [];
        try {
            var auditLayer = source.duplicate();
            auditLayer.name = "__L4_TEMP_SAFE_AREA_AUDIT__";
            var auditTextProps = auditLayer.property("ADBE Text Properties");
            var auditDocProp = auditTextProps.property("ADBE Text Document");
            var auditAnimators = auditTextProps.property("ADBE Text Animators");
            if (auditAnimators) {
                for (var aa = auditAnimators.numProperties; aa >= 1; aa--) auditAnimators.property(aa).remove();
            }
            var auditScaleX = 100;
            try { auditScaleX = Math.abs(Number(auditLayer.property("ADBE Transform Group").property("ADBE Scale").value[0])) || 100; } catch (auditScaleErr) {}
            if (auditScaleX < 0.01) auditScaleX = 100;
            var auditMaxWidth = comp.width * (maxLinePercent / 100) / (auditScaleX / 100);
            for (var aw = 0; aw < data.words.length; aw++) {
                var originalWord = cleanWord(data.words[aw]);
                var auditDoc = auditDocProp.value;
                auditDoc.text = originalWord.toUpperCase();
                auditDocProp.setValue(auditDoc);
                var auditWidth = 0;
                try { auditWidth = Number(auditLayer.sourceRectAtTime(0, false).width) || 0; } catch (auditMeasureErr) {}
                auditWidth = auditWidth * SAFE_WIDTH_MEASURE_FACTOR;
                if (auditWidth > auditMaxWidth) oversizedWords.push(originalWord);
            }
            auditLayer.remove();
        } catch (auditErr) {
            try { if (auditLayer) auditLayer.remove(); } catch (auditRemoveErr) {}
        }

        function findAnimator(animators, name) {
            for (var a = 1; a <= animators.numProperties; a++) if (animators.property(a).name === name) return animators.property(a);
            return null;
        }
        function findTrackingAmount(layer) {
            var textProps = layer.property("ADBE Text Properties");
            var animators = textProps ? textProps.property("ADBE Text Animators") : null;
            if (!animators) return null;
            for (var a = 1; a <= animators.numProperties; a++) {
                var animator = animators.property(a);
                if (animator.name !== "Tracking") continue;
                var props = animator.property("ADBE Text Animator Properties");
                if (!props) return null;
                try { return props.property("ADBE Text Tracking Amount"); } catch (e) { return null; }
            }
            return null;
        }
        function findWipeCompletion(layer) {
            var effects = layer.property("ADBE Effect Parade");
            if (!effects) return null;
            var wipe = null;
            for (var e = 1; e <= effects.numProperties; e++) if (effects.property(e).name === "Linear Wipe") { wipe = effects.property(e); break; }
            if (!wipe) return null;
            for (var p = 1; p <= wipe.numProperties; p++) {
                var prop = wipe.property(p);
                if (prop.name === "Transition Completion" || prop.matchName === "ADBE Linear Wipe-0001") return prop;
            }
            return null;
        }
        function copyKeyRecord(prop, k) {
            var r = {t:prop.keyTime(k), v:prop.keyValue(k)};
            try { r.inI = prop.keyInInterpolationType(k); r.outI = prop.keyOutInterpolationType(k); } catch (e1) {}
            try { r.inE = prop.keyInTemporalEase(k); r.outE = prop.keyOutTemporalEase(k); } catch (e2) {}
            try { r.autoB = prop.keyTemporalAutoBezier(k); r.cont = prop.keyTemporalContinuous(k); } catch (e3) {}
            return r;
        }
        function restoreKeys(prop, recs) {
            try {
                while (prop.numKeys > 0) prop.removeKey(1);
                for (var i = 0; i < recs.length; i++) prop.setValueAtTime(recs[i].t, recs[i].v);
                for (var j = 0; j < recs.length; j++) {
                    var idx = prop.nearestKeyIndex(recs[j].t);
                    try { if (recs[j].inI !== undefined) prop.setInterpolationTypeAtKey(idx, recs[j].inI, recs[j].outI); } catch (e4) {}
                    try { if (recs[j].inE && recs[j].outE) prop.setTemporalEaseAtKey(idx, recs[j].inE, recs[j].outE); } catch (e5) {}
                    try { if (recs[j].autoB !== undefined) prop.setTemporalAutoBezierAtKey(idx, recs[j].autoB); } catch (e6) {}
                    try { if (recs[j].cont !== undefined) prop.setTemporalContinuousAtKey(idx, recs[j].cont); } catch (e7) {}
                }
            } catch (restoreErr) {}
        }
        function shiftEffectKeysRecursive(group, delta, warnings) {
            // Only effect properties are shifted. Do not recursively shift text animator keys.
            for (var p = 1; p <= group.numProperties; p++) {
                var prop = group.property(p);
                if (prop.propertyType === PropertyType.PROPERTY) {
                    if (!prop.numKeys || prop.numKeys < 1) continue;
                    try { if (prop.expressionEnabled) continue; } catch (ignoreExpr) {}
                    var recs = [];
                    for (var k = 1; k <= prop.numKeys; k++) recs.push(copyKeyRecord(prop, k));
                    var ok = true;
                    try {
                        while (prop.numKeys > 0) prop.removeKey(1);
                        for (var q = 0; q < recs.length; q++) prop.setValueAtTime(recs[q].t + delta, recs[q].v);
                        for (var z = 0; z < recs.length; z++) {
                            var idx = prop.nearestKeyIndex(recs[z].t + delta);
                            try { if (recs[z].inI !== undefined) prop.setInterpolationTypeAtKey(idx, recs[z].inI, recs[z].outI); } catch (e1) {}
                            try { if (recs[z].inE && recs[z].outE) prop.setTemporalEaseAtKey(idx, recs[z].inE, recs[z].outE); } catch (e2) {}
                            try { if (recs[z].autoB !== undefined) prop.setTemporalAutoBezierAtKey(idx, recs[z].autoB); } catch (e3) {}
                            try { if (recs[z].cont !== undefined) prop.setTemporalContinuousAtKey(idx, recs[z].cont); } catch (e4) {}
                        }
                    } catch (shiftErr) { ok = false; restoreKeys(prop, recs); }
                    if (!ok) warnings.count++;
                } else {
                    try { shiftEffectKeysRecursive(prop, delta, warnings); } catch (ignoreChild) {}
                }
            }
        }
        function setWordSelectors(layer, words, start, fade) {
            var textProps = layer.property("ADBE Text Properties");
            var animators = textProps.property("ADBE Text Animators");
            var fadeAnimator = findAnimator(animators, "Fade Up Words");
            if (!fadeAnimator) throw new Error("Source layer has no animator named 'Fade Up Words'. Apply the original main text animation.ffx first.");
            var selectors = fadeAnimator.property("ADBE Text Selectors");
            for (var r = selectors.numProperties; r >= 1; r--) selectors.property(r).remove();
            for (var n = 0; n < words.length; n++) {
                var sel = selectors.addProperty("ADBE Text Selector");
                sel.name = "Word " + (n + 1);
                var adv = sel.property("ADBE Text Range Advanced");
                adv.property("ADBE Text Range Type2").setValue(3); // Words
                adv.property("ADBE Text Range Units").setValue(2); // Index
                adv.property("ADBE Text Selector Mode").setValue(1);
                adv.property("ADBE Text Levels Max Ease").setValue(0);
                adv.property("ADBE Text Levels Min Ease").setValue(0);
                adv.property("ADBE Text Randomize Order").setValue(false);
                sel.property("ADBE Text Index Start").setValue(n);
                sel.property("ADBE Text Index End").setValue(n + 1);
                sel.property("ADBE Text Index Offset").setValue(0);
                var amount = null;
                try { amount = adv.property("ADBE Text Selector Max Amount"); } catch (e1) {}
                if (!amount) {
                    for (var ap = 1; ap <= adv.numProperties; ap++) {
                        var candidate = adv.property(ap);
                        if (candidate.name === "Amount" && candidate.propertyType === PropertyType.PROPERTY) { amount = candidate; break; }
                    }
                }
                if (!amount) throw new Error("Could not locate writable Advanced > Amount for Word " + (n + 1) + ".");
                var wordStart = Number(words[n].start) + offset; // Never accumulate spacing: this must stay locked to Whisper audio timestamps.
                amount.setValueAtTime(wordStart, 100);
                amount.setValueAtTime(wordStart + fade, 0);
            }
        }
        function setTrackingKeys(layer, start) {
            var tracking = findTrackingAmount(layer);
            if (!tracking || tracking.numKeys < 2) return false;
            var recs = [];
            for (var k = 1; k <= tracking.numKeys; k++) recs.push(copyKeyRecord(tracking, k));
            var firstValue = recs[0].v, lastValue = recs[recs.length - 1].v;
            var duration = Math.max(0.35, recs[recs.length - 1].t - recs[0].t);
            try {
                while (tracking.numKeys > 0) tracking.removeKey(1);
                tracking.setValueAtTime(start, firstValue);
                tracking.setValueAtTime(start + duration, lastValue);
                return true;
            } catch (writeErr) {
                restoreKeys(tracking, recs);
                return false;
            }
        }
        function setWipeKeys(layer, start, end) {
            var completion = findWipeCompletion(layer);
            if (!completion) throw new Error("Could not locate Linear Wipe > Transition Completion on the duplicate.");
            var firstValue = 0, lastValue = 100;
            if (completion.numKeys >= 2) {
                firstValue = completion.keyValue(1);
                lastValue = completion.keyValue(completion.numKeys);
            } else {
                try { firstValue = completion.value; } catch (e) {}
            }
            while (completion.numKeys > 0) completion.removeKey(1);
            completion.setValueAtTime(start, firstValue);
            completion.setValueAtTime(end, lastValue);
        }

        var plans = [];
        for (var gi = 0; gi < groups.length; gi++) {
            var grp = groups[gi];
            var start = Number(grp[0].start) + offset;
            var spokenEnd = Number(grp[grp.length - 1].end) + offset;
            var wipeStart = Math.max(start, spokenEnd - wipeLead);
            var splitIndex = Number(grp.captionSplitIndex);
            if (!(splitIndex > 0)) splitIndex = grp.length;
            plans.push({words:grp, captionText:grp.captionText, splitIndex:splitIndex,
                        upperWords:grp.slice(0, splitIndex), lowerWords:grp.slice(splitIndex),
                        start:start, spokenEnd:spokenEnd, wipeStart:wipeStart,
                        wipeEnd:wipeStart + wipeDuration, layerEnd:wipeStart + wipeDuration + 0.20});
        }

        // RANGE GUARD: drop captions that fall completely outside the composition
        // (e.g. trimmed clip or comp shorter than the transcribed audio). Previously a
        // single out-of-range caption aborted the whole run with "invalid layer duration".
        (function () {
            var kept = [], dropped = [];
            for (var pi = 0; pi < plans.length; pi++) {
                var pl = plans[pi];
                var pEnd = Math.min(comp.duration, Math.max(pl.layerEnd, pl.spokenEnd + 0.80));
                var pStart = Math.max(0, pl.start);
                if (pEnd - pStart > 0.01) kept.push(pl); else dropped.push(pi + 1);
            }
            if (dropped.length) {
                L4_emit("LOG", "Skipped " + dropped.length + " caption(s) outside the composition length (" +
                    comp.duration.toFixed(2) + "s): original #" + dropped.join(", #") +
                    ". Extend the comp or check the audio offset if these should appear.");
                plans = kept;
            }
        })();

        // Optional local AI styling: decisions are constrained to this approved registry.
        // If Ollama/Python fails, the script safely keeps the original neutral style.
        var aiStyleDecisions = [];
        var aiStyleByIndex = {};
        var aiColorByIndex = {};
        var aiStylingUsed = false;
        var aiStyleSummary = [];
        function applyAnimatorFillColor(layer, rgb) {
            // TextDocument.fillColor can be visually overridden by a Fill Color property
            // inside a copied FFX text animator. Update those properties as well.
            function walk(group) {
                if (!group) return;
                for (var pi = 1; pi <= group.numProperties; pi++) {
                    var prop = group.property(pi);
                    if (prop.propertyType === PropertyType.PROPERTY) {
                        var mn = String(prop.matchName || "");
                        var nm = String(prop.name || "").toLowerCase();
                        if (mn === "ADBE Text Fill Color" || mn === "ADBE Text Fill Color RGB" || nm === "fill color" || nm === "fill color rgb") {
                            try { prop.setValue(rgb); } catch (colorErr) {}
                        }
                    } else {
                        try { walk(prop); } catch (walkErr) {}
                    }
                }
            }
            try { walk(layer.property("ADBE Text Properties").property("ADBE Text Animators")); } catch (e) {}
        }
        var enableAIStyling = !!cfg.ai;
        if (enableAIStyling) { L4_emit("STAGE", "Local AI styling"); L4_emit("LOG", "Running local styling (Ollama + rotation rules)…"); }
        if (enableAIStyling) {
            var pyModule = cfg.stylingPy ? new File(cfg.stylingPy) : null;
            if (pyModule && pyModule.exists) {
                try {
                    function jsonQuote(s) {
                        return '"' + String(s).replace(/\\/g, "\\\\").replace(/"/g, '\\"').replace(/\r/g, "\\r").replace(/\n/g, "\\n") + '"';
                    }
                    var inputFile = new File(Folder.temp.fsName + "/l4_style_input.json");
                    var outputFile = new File(Folder.temp.fsName + "/l4_style_output.json");
                    var inputText = '{"captions":[';
                    for (var ai = 0; ai < plans.length; ai++) {
                        if (ai) inputText += ',';
                        inputText += '{"index":' + (ai + 1) + ',"text":' + jsonQuote(plans[ai].captionText) + '}';
                    }
                    inputText += ']}';
                    inputFile.encoding = "UTF-8"; inputFile.open("w"); inputFile.write(inputText); inputFile.close();
                    if (outputFile.exists) outputFile.remove();
                    var pyExe = cfg.pythonCmd ? (String(cfg.pythonCmd) + " ") : "py -3 ";
                    var command = pyExe + '"' + pyModule.fsName + '" --input "' + inputFile.fsName + '" --output "' + outputFile.fsName + '"';
                    var cmdResult = system.callSystem(command);
                    if (outputFile.exists && outputFile.open("r")) {
                        outputFile.encoding = "UTF-8";
                        var aiRaw = outputFile.read(); outputFile.close();
                        var aiResult = (typeof JSON !== "undefined" && JSON.parse) ? JSON.parse(aiRaw) : eval("(" + aiRaw + ")");
                        // Only report AI styling as applied when the Python/Ollama call succeeded.
                        // The Python module can emit neutral fallback decisions with ok:false;
                        // those must not be mistaken for successful AI analysis.
                        if (aiResult && aiResult.ok === true && aiResult.decisions && aiResult.decisions.length === plans.length) {
                            aiStyleDecisions = aiResult.decisions;
                            for (var adi = 0; adi < aiStyleDecisions.length; adi++) {
                                var decision = aiStyleDecisions[adi];
                                var dIndex = Number(decision.index);
                                var dStyle = String(decision.style_id || "neutral");
                                if (dStyle !== "neutral" && dStyle !== "barber_chop" && dStyle !== "basketball" && dStyle !== "black_ops_one" && dStyle !== "devil_candle" && dStyle !== "game_of_thrones" && dStyle !== "hooge_05_55" && dStyle !== "limelight") dStyle = "neutral";
                                aiStyleByIndex[dIndex] = dStyle;
                                var dColor = String(decision.color_id || "neutral_white");
                                var allowedColors = ["neutral_white", "ff0000", "ff0084", "9c00ff", "0078ff", "00ff30", "ffae00"];
                                if (allowedColors.join("|").indexOf(dColor) < 0) dColor = "neutral_white";
                                aiColorByIndex[dIndex] = dColor;
                            }
                            aiStylingUsed = true;
                        } else {
                            aiStylingUsed = false;
                            aiStyleDecisions = [];
                        }
                    }
                } catch (aiBridgeErr) { aiStylingUsed = false; aiStyleDecisions = []; }
            }
        }

        L4_emit("LOG", enableAIStyling ? (aiStylingUsed ? "AI styling decisions received." : "AI styling unavailable — neutral style used.") : "AI styling off.");
        L4_emit("LOG", plans.length + " captions planned");
        L4_emit("PROG", "0.08");
        app.beginUndoGroup("L4 Style 1 — Auto Caption");
        var created = [], warnings = {count:0}, trackingWarnings = 0, currentStage = "starting";
        try {
            function textLine(layer, words) {
                var tp = layer.property("ADBE Text Properties").property("ADBE Text Document");
                var td = tp.value;
                var parts = [];
                for (var wi = 0; wi < words.length; wi++) parts.push(cleanWord(words[wi]).toUpperCase());
                td.text = parts.join(" ");
                tp.setValue(td);
                return tp;
            }
            function measureRect(layer) {
                try { return layer.sourceRectAtTime(0, false); }
                catch (e) { return {left:0, top:0, width:0, height:0}; }
            }
            function centerLayer(layer, centerX, centerY) {
                var rect = measureRect(layer);
                var tr = layer.property("ADBE Transform Group");
                var pos = tr.property("ADBE Position");
                var old = pos.value;
                // Comp-space centering compensates for the text bounds' offset from its anchor.
                pos.setValue([centerX - rect.left - rect.width / 2, centerY - rect.top - rect.height / 2]);
            }
            function fitLowerLine(layer, maxWidth) {
                // Lower line starts large (56 px) and shrinks only when needed to stay
                // inside the safe width. Upper line is separately locked at Arial Bold 42 px.
                var tp = layer.property("ADBE Text Properties").property("ADBE Text Document");
                var td = tp.value;
                var startSize = Number(td.fontSize) || 56;
                var minSize = 32;
                var maxSize = Math.min(72, Math.max(minSize, startSize));
                var size = maxSize;
                while (size > minSize) {
                    td.fontSize = size;
                    tp.setValue(td);
                    var r = measureRect(layer);
                    if (r.width * SAFE_WIDTH_MEASURE_FACTOR <= maxWidth) return {size:size, fits:true};
                    size -= 1;
                }
                td.fontSize = minSize;
                tp.setValue(td);
                var finalRect = measureRect(layer);
                return {size:minSize, fits:(finalRect.width * SAFE_WIDTH_MEASURE_FACTOR <= maxWidth)};
            }
            // The JSX enforces the approved rotation as the final authority. Python may
            // mark a rare caption natural, but cannot reorder or repeat styled fonts/colors.
            var fixedFontOrder = [
                {id:"barber_chop", font:"BarberChop"},
                {id:"basketball", font:"Basketball"},
                {id:"black_ops_one", font:"BlackOpsOne-Regular"},
                {id:"devil_candle", font:"DevilCandleAlt-PERSONALUSE"},
                {id:"game_of_thrones", font:"GameofThrones"},
                {id:"hooge_05_55", font:"hooge_05_55"},
                {id:"limelight", font:"Limelight"}
            ];
            var fixedColorOrder = ["ff0000", "ff0084", "9c00ff", "0078ff", "00ff30", "ffae00"];
            var fixedFontCounter = 0, fixedColorCounter = 0;
            function normalizeLowerVisualSize(layer, targetHeight) {
                // Normalize the rendered text bounds across fonts with different cap-height metrics.
                // Width fitting runs after this and may reduce size only when the safe area requires it.
                var tp = layer.property("ADBE Text Properties").property("ADBE Text Document");
                var doc = tp.value;
                var size = Number(doc.fontSize) || 56;
                var minSize = 32, maxSize = 72;
                for (var attempt = 0; attempt < 5; attempt++) {
                    doc.fontSize = Math.max(minSize, Math.min(maxSize, size));
                    tp.setValue(doc);
                    var rect = measureRect(layer);
                    var h = Number(rect.height) || 0;
                    if (h <= 0) break;
                    var ratio = targetHeight / h;
                    if (Math.abs(ratio - 1) < 0.035) break;
                    size = Math.max(minSize, Math.min(maxSize, size * ratio));
                    doc = tp.value;
                }
                doc = tp.value;
                return Number(doc.fontSize) || size;
            }
            for (var ci = 0; ci < plans.length; ci++) {
                L4_emit("PROG", (0.08 + 0.90 * ci / plans.length).toFixed(3)); L4_emit("STAGE", "Caption " + (ci + 1) + " of " + plans.length);
                var plan = plans[ci];
                currentStage = "duplicating source for caption " + (ci + 1);
                var upper = source.duplicate();
                upper.name = "L4 TEXT STYLE 1 — Caption " + (ci + 1) + " — Upper";
                // VISIBILITY FIX: duplicates inherit the source layer's enabled state.
                // Always enable generated caption layers, even if the source template was disabled by a prior run.
                upper.enabled = true;
                upper.shy = false;
                upper.startTime = source.startTime;
                upper.inPoint = Math.max(0, plan.start);
                upper.outPoint = Math.min(comp.duration, Math.max(plan.layerEnd, plan.spokenEnd + 0.80));
                if (upper.outPoint <= upper.inPoint) { upper.remove(); throw new Error("Caption " + (ci + 1) + " has an invalid layer duration."); }

                currentStage = "preserving effects and setting upper line " + (ci + 1);
                var upperEffects = upper.property("ADBE Effect Parade");
                if (upperEffects) shiftEffectKeysRecursive(upperEffects, plan.start, warnings);
                textLine(upper, plan.upperWords);
                // LOCKED USER RULE: upper line always Arial Bold 42 px white. Lower-line
                // contextual styling must never bleed into this line. Preserve all animators/effects.
                var upperDocProp = upper.property("ADBE Text Properties").property("ADBE Text Document");
                var upperDoc = upperDocProp.value;
                upperDoc.font = "Arial-BoldMT";
                upperDoc.fontSize = 42;
                upperDoc.fillColor = [1, 1, 1];
                upperDocProp.setValue(upperDoc);
                applyAnimatorFillColor(upper, [1, 1, 1]);
                setWordSelectors(upper, plan.upperWords, plan.start, fadeDuration);
                if (!setTrackingKeys(upper, plan.start)) trackingWarnings++;
                setWipeKeys(upper, plan.wipeStart, plan.wipeEnd);

                var pairLayers = [upper];
                if (plan.lowerWords.length > 0) {
                    currentStage = "creating lower line " + (ci + 1);
                    var lower = source.duplicate();
                    lower.name = "L4 TEXT STYLE 1 — Caption " + (ci + 1) + " — Lower";
                    // VISIBILITY FIX: generated lower line must not inherit a disabled source state.
                    lower.enabled = true;
                    lower.shy = false;
                    lower.startTime = source.startTime;
                    lower.inPoint = upper.inPoint;
                    lower.outPoint = upper.outPoint;
                    var lowerEffects = lower.property("ADBE Effect Parade");
                    if (lowerEffects) shiftEffectKeysRecursive(lowerEffects, plan.start, warnings);
                    textLine(lower, plan.lowerWords);
                    // Apply the decision by explicit caption index, then set both the text
                    // document style and any animator-level fill color that could override it.
                    var styleId = aiStylingUsed ? (aiStyleByIndex[ci + 1] || "neutral") : "neutral";
                    // Keep natural captions rare, but enforce a deterministic fixed rotation for every
                    // styled caption regardless of any model-proposed style ID.
                    if (aiStylingUsed && styleId !== "neutral") {
                        styleId = fixedFontOrder[fixedFontCounter % fixedFontOrder.length].id;
                    }
                    // Verified After Effects font names from the Font Name Audit. CC Light Sweep and all existing
                    // effects/keyframes are deliberately left untouched; only text font/size/color change.
                    var targetColor = [1, 1, 1];
                    var targetFont = "Arial-BoldMT";
                    var targetSize = 56;
                    if (styleId === "barber_chop") {
                        targetFont = "BarberChop"; targetSize = 56; targetColor = [1.0, 0.20, 0.16]; // hot coral red
                    } else if (styleId === "basketball") {
                        targetFont = "Basketball"; targetSize = 56; targetColor = [1.0, 0.48, 0.08]; // warm orange
                    } else if (styleId === "black_ops_one") {
                        targetFont = "BlackOpsOne-Regular"; targetSize = 56; targetColor = [0.60, 0.82, 1.0]; // ice blue
                    } else if (styleId === "devil_candle") {
                        targetFont = "DevilCandleAlt-PERSONALUSE"; targetSize = 56; targetColor = [0.86, 0.20, 0.32]; // crimson
                    } else if (styleId === "game_of_thrones") {
                        targetFont = "GameofThrones"; targetSize = 56; targetColor = [1.0, 0.72, 0.25]; // amber gold
                    } else if (styleId === "hooge_05_55") {
                        targetFont = "hooge_05_55"; targetSize = 56; targetColor = [0.32, 1.0, 0.68]; // soft mint
                    } else if (styleId === "limelight") {
                        targetFont = "Limelight"; targetSize = 56; targetColor = [0.35, 0.88, 1.0]; // bright cyan
                    }
                    // Palette is independently selected by the local analyzer so repeated font families
                    // can use compatible alternate colours. Existing CC Light Sweep/effects are untouched.
                    var colorId = "neutral_white";
                    if (aiStylingUsed && styleId !== "neutral") {
                        colorId = fixedColorOrder[fixedColorCounter % fixedColorOrder.length];
                        fixedFontCounter++;
                        fixedColorCounter++;
                    }
                    // User-approved exact HEX palette only. Game of Thrones is locked to orange.
                    if (styleId === "game_of_thrones") colorId = "ffae00";
                    var colorPalette = {
                        neutral_white:[1,1,1],
                        ff0000:[1,0,0],
                        ff0084:[1,0,132/255],
                        "9c00ff":[156/255,0,1],
                        "0078ff":[0,120/255,1],
                        "00ff30":[0,1,48/255],
                        ffae00:[1,174/255,0]
                    };
                    if (colorPalette[colorId]) targetColor = colorPalette[colorId];
                    var lowerDocProp = lower.property("ADBE Text Properties").property("ADBE Text Document");
                    var lowerDoc = lowerDocProp.value;
                    var appliedFont = targetFont;
                    // Some installed fonts expose a different internal/PostScript name to AE.
                    // Guard the font assignment so one unresolved font cannot abort caption generation.
                    try {
                        lowerDoc.font = targetFont;
                        lowerDoc.fontSize = targetSize;
                        lowerDoc.fillColor = targetColor;
                        lowerDocProp.setValue(lowerDoc);
                    } catch (fontApplyErr) {
                        appliedFont = "Arial-BoldMT (fallback; requested: " + targetFont + ")";
                        lowerDoc = lowerDocProp.value;
                        lowerDoc.font = "Arial-BoldMT";
                        lowerDoc.fontSize = 56;
                        lowerDoc.fillColor = targetColor;
                        lowerDocProp.setValue(lowerDoc);
                    }
                    setWordSelectors(lower, plan.lowerWords, plan.start, fadeDuration);
                    applyAnimatorFillColor(lower, targetColor);
                    if (!setTrackingKeys(lower, plan.start)) trackingWarnings++;
                    setWipeKeys(lower, plan.wipeStart, plan.wipeEnd);
                    // Match apparent lower-line height across the seven font families before width fit.
                    // A 50 px text-bounds target keeps lower text visibly larger than the 42 px upper line.
                    var calibratedSize = normalizeLowerVisualSize(lower, 50);
                    var maxSafeWidth = comp.width * (maxLinePercent / 100);
                    var fitResult = fitLowerLine(lower, maxSafeWidth);
                    if (!fitResult.fits) warnings.count++;
                    aiStyleSummary.push("Caption " + (ci + 1) + ": " + styleId + " / " + colorId + " (" + appliedFont + ", final " + fitResult.size + " px" + (fitResult.fits ? ", fits" : ", SAFE WIDTH WARNING") + ")");

                    L4_emit("LOG", aiStyleSummary[aiStyleSummary.length - 1]);
                    // Keep the two independently animated text layers visually centered as a group.
                    var upperRect = measureRect(upper), lowerRect = measureRect(lower);
                    // A firm minimum gap prevents tall/ornamental fonts from colliding with the fixed upper line.
                    // Keep the pair centered as a group after lower-font size calibration.
                    var gap = Math.max(6, (Number(upperRect.height) + Number(lowerRect.height)) * 0.03);
                    var totalHeight = upperRect.height + lowerRect.height + gap;
                    var groupTop = comp.height / 2 - totalHeight / 2;
                    centerLayer(upper, comp.width / 2, groupTop + upperRect.height / 2);
                    centerLayer(lower, comp.width / 2, groupTop + upperRect.height + gap + lowerRect.height / 2);
                    pairLayers.push(lower);
                } else {
                    centerLayer(upper, comp.width / 2, comp.height / 2);
                }

                // Save timing before precompose invalidates the original line-layer references.
                var captionInPoint = upper.inPoint, captionOutPoint = upper.outPoint;
                // Combine this caption's line layers into a dedicated pre-comp.
                currentStage = "precomposing caption " + (ci + 1);
                var indices = [];
                for (var pi = 0; pi < pairLayers.length; pi++) indices.push(pairLayers[pi].index);
                indices.sort(function(a,b){ return a-b; });
                var precompName = "L4 TEXT STYLE 1 — Caption " + (ci + 1);
                // In After Effects scripting, layers.precompose() returns the new CompItem,
                // not the new layer index. Resolve the inserted precomp layer by its source.
                var precompComp = comp.layers.precompose(indices, precompName, true);
                if (!precompComp || !(precompComp instanceof CompItem)) {
                    throw new Error("After Effects did not return the expected caption pre-comp for " + (ci + 1) + ".");
                }
                var precompLayer = null;
                for (var findLayerIndex = 1; findLayerIndex <= comp.numLayers; findLayerIndex++) {
                    var candidateLayer = comp.layer(findLayerIndex);
                    try {
                        if (candidateLayer.source === precompComp) { precompLayer = candidateLayer; break; }
                    } catch (findLayerErr) {}
                }
                if (!precompLayer) {
                    throw new Error("Caption pre-comp was created, but its layer could not be found in the parent composition.");
                }
                precompLayer.name = precompName;
                // VISIBILITY FIX: ensure each generated parent-comp caption is visible.
                precompLayer.enabled = true;
                precompLayer.shy = false;
                precompLayer.inPoint = captionInPoint;
                precompLayer.outPoint = captionOutPoint;
                created.push(precompLayer);
            }
            var glowTotal = created.length, glowCount = 0, glowTried = !!cfg.glowPath;
            if (cfg.glowPath) {
                var glowFile = new File(cfg.glowPath);
                if (glowFile.exists) {
                    currentStage = "applying text glow";
                    L4_emit("STAGE", "Applying glow"); L4_emit("PROG", "0.97");
                    var savedTime = comp.time;
                    function glowEffectCount(lyr) { try { return lyr.property("ADBE Effect Parade").numProperties; } catch (ce) { return 0; } }
                    for (var gi = 0; gi < created.length; gi++) {
                        var gl = created[gi], glBefore = glowEffectCount(gl), glApplied = false, glErr = "";
                        for (var gTry = 0; gTry < 2 && !glApplied; gTry++) {
                            try {
                                comp.time = gl.inPoint;
                                for (var gd = 1; gd <= comp.numLayers; gd++) comp.layer(gd).selected = false;
                                gl.selected = true;
                                gl.applyPreset(glowFile);
                            } catch (glowErr) { glErr = glowErr.toString(); }
                            glApplied = glowEffectCount(gl) > glBefore;
                        }
                        if (glApplied) glowCount++;
                        else L4_emit("LOG", "Glow issue on caption " + (gi + 1) + ": no effect was added" + (glErr ? " (" + glErr + ")" : ""));
                    }
                    try { comp.time = savedTime; for (var gs = 1; gs <= comp.numLayers; gs++) comp.layer(gs).selected = false; } catch (rs) {}
                    L4_emit("LOG", "text_glow applied to " + glowCount + " of " + glowTotal + " caption pre-comps");
                    if (glowCount === 0) L4_emit("LOG", "Glow issue: the preset added no effects. Check text_glow.ffx, it may need a plugin that is not installed.");
                } else { L4_emit("LOG", "Glow issue: text_glow.ffx not found at " + cfg.glowPath); glowTried = false; }
            }
            // Deterministically order generated caption layers top-to-bottom by audio chronology.
            // AE duplicate() insertion order can vary with the selected source's stack position;
            // explicitly rebuild the stack as Caption 1, Caption 2, ... Caption N, then source.
            for (var orderIndex = created.length - 1; orderIndex >= 0; orderIndex--) {
                created[orderIndex].moveBefore(source);
            }
            // Do not touch the original template unless the user explicitly checked the option.
            if (cfg.removeSource) { try { source.remove(); } catch (rmErr) { source.enabled = false; } }
            else if (disableSourceAfter) source.enabled = false;
            app.endUndoGroup();
            var summary = "Created " + created.length + " caption pre-comps in chronological layer-stack order from " + data.words.length + " word timestamps.\n" +
                "Upper line locked: Arial Bold 42 px white. Lower-line visual height is calibrated across fonts (target 50 px bounds), then auto-fits within 32–72 px to safe width; a subtle 6 px minimum measured gap separates the lines. Fixed font/colour rotation and visibility fix enforced in JSX. " + "Local AI styling: " + (aiStylingUsed ? "decisions received; style assignments below." : (enableAIStyling ? "unavailable; neutral style used." : "off; neutral style used.")) + "\n" +
                (aiStylingUsed ? aiStyleSummary.join("\n") + "\n" : "") +
                "Rules: max 8 words; split on punctuation/pauses; 4+ words use phrase-aware balanced lines; line breaks prefer comma/semicolon/colon/dash boundaries and avoid ending line one on small connector words. 2–3 words stay together only if they fit; oversized single words remain unchanged and are reported.\n" +
                "Fixed safe area: " + maxLinePercent.toFixed(0) + "% of composition width; lower lines are visually calibrated across fonts, then auto-fit between 32 and 72 px only as needed. Measured width " + (groups.usedWidthFallback ? "used approximate fallback (sourceRectAtTime unavailable)." : "uses source text bounds") + "; safe width " + groups.maxWidth.toFixed(0) + " px.\n" +
                "Fade Up Words: " + fadeDuration.toFixed(2) + "s; exact Whisper timestamps used (no cumulative spacing drift).\n" +
                "Linear Wipe: starts " + wipeLead.toFixed(2) + "s before spoken end and lasts " + wipeDuration.toFixed(2) + "s.\n" +
                "Original template layer: " + (disableSourceAfter ? "disabled by your checkbox (not deleted)." : "left unchanged and enabled.") + "\n" +
                "Effect-keyframe shift / lower-line fit warnings: " + warnings.count + "; Tracking warnings: " + trackingWarnings + ".\n\n";
            for (var si = 0; si < plans.length; si++) {
                summary += "Caption " + (si + 1) + " (" + plans[si].words.length + " words): " +
                    plans[si].start.toFixed(2) + "s–" + plans[si].spokenEnd.toFixed(2) + "s; wipe " +
                    plans[si].wipeStart.toFixed(2) + "s–" + plans[si].wipeEnd.toFixed(2) + "s\n";
            }
            if (oversizedWords.length > 0) {
                summary += "\nSAFE-AREA WARNING — " + oversizedWords.length + " word(s) remain wider than the fixed safe area even at the minimum 32 px. Each is kept intact and isolated where caption grouping allows:\n";
                var shownOversized = {};
                for (var ow = 0; ow < oversizedWords.length; ow++) {
                    var owKey = "$" + oversizedWords[ow].toUpperCase();
                    if (!shownOversized[owKey]) { summary += "• " + oversizedWords[ow] + "\n"; shownOversized[owKey] = true; }
                }
                summary += "If any listed word still crosses the safe boundary at 32 px, consider a different line split; the script does not distort text horizontally.";
            } else {
                summary += "\nSafe-area audit: all individual words fit the fixed safe width or are flagged if wider than the minimum 32 px.";
            }
            summary += "\n\nReview the full composition. If the original template text is visible underneath, undo or toggle its visibility manually; this script leaves it untouched by default.";
            RESULT.ok = true; RESULT.message = "Created " + created.length + " captions";
            RESULT.glow = glowCount; RESULT.glowTotal = glowTotal; RESULT.glowTried = glowTried; RESULT.count = created.length; RESULT.warnings = warnings.count + trackingWarnings; RESULT.oversized = oversizedWords.length;
            RESULT.summary = summary; L4_emit("PROG", "1"); L4_emit("STAGE", "Done");
        } catch (err) {
            try { app.endUndoGroup(); } catch (ignoreEnd) {}
            tell("Stopped at: " + currentStage + "\n\n" + err.toString() +
                 "\n\nThe original template was not intentionally modified (unless you checked the optional disable box, which is applied only after generation). If partial duplicates exist, press Ctrl+Z once to undo this run.");
        }
    })();
    return L4_json(RESULT);
}

function L4_generate2(cfgJson) {
    var cfg = eval("(" + cfgJson + ")");
    var RESULT = { ok: false, message: "", summary: "" };
    (function () {
        var TITLE = "L4 Style 2";
        function tell(s) { RESULT.message = String(s); L4_emit("ERR", String(s).split("\n")[0]); }
        L4_emit("STAGE", "Checking project"); L4_emit("PROG", "0.01");
        if (!app.project) { tell("Open your After Effects project first."); return; }
        var comp = app.project.activeItem;
        if (!(comp instanceof CompItem)) { tell("Open the composition containing your original FFX-styled text layer."); return; }
        if (comp.selectedLayers.length !== 1) { tell("Select exactly ONE text layer with the original main text animation.ffx applied."); return; }
        var source = comp.selectedLayers[0];
        if (!source.property("ADBE Text Properties")) { tell("The selected layer is not a text layer."); return; }

        var jsonFile = new File(cfg.jsonPath);
        if (!jsonFile.exists) { tell("Timestamp JSON not found:\n" + cfg.jsonPath); return; }
        jsonFile.encoding = "UTF-8";
        if (!jsonFile.open("r")) { tell("Could not read the JSON file."); return; }
        var raw = jsonFile.read(); jsonFile.close();
        var data;
        try {
            if (typeof JSON !== "undefined" && JSON.parse) data = JSON.parse(raw);
            else data = eval("(" + raw + ")");
        } catch (e) { tell("Could not parse JSON:\n" + e.toString()); return; }
        if (!data.words || !data.words.length) { tell("JSON contains no word timestamps."); return; }

        // Audio-sync guard: match the JSON source filename to an audio-capable layer.
        // Only apply automatic offset when the exact source matches and layer stretch is 100%.
        // Never guess from an unrelated audio layer; the offset remains editable.
        function baseFileName(value) {
            return String(value || "").replace(/\\/g, "/").split("/").pop().toLowerCase();
        }
        var matchedAudioLayer = null;
        var autoOffset = 0;
        var autoOffsetApplied = false;
        var audioOffsetNote = "No exact matching audio layer found; offset remains manual (0 seconds).";
        var jsonSourceName = baseFileName(data.source_file || "");
        if (jsonSourceName) {
            for (var audioIndex = 1; audioIndex <= comp.numLayers; audioIndex++) {
                var audioCandidate = comp.layer(audioIndex);
                try {
                    if (!audioCandidate.hasAudio || !audioCandidate.source) continue;
                    if (baseFileName(audioCandidate.source.name) !== jsonSourceName) continue;
                    matchedAudioLayer = audioCandidate;
                    var stretchPercent = 100;
                    try { stretchPercent = Number(audioCandidate.stretch); } catch (stretchReadErr) {}
                    if (Math.abs(stretchPercent - 100) < 0.001) {
                        autoOffset = Number(audioCandidate.startTime) || 0;
                        autoOffsetApplied = true;
                        audioOffsetNote = "Matched audio layer: " + audioCandidate.name +
                            " (offset auto-filled from its start time; editable below).";
                    } else {
                        audioOffsetNote = "Matched audio layer: " + audioCandidate.name +
                            ", but its stretch is " + stretchPercent +
                            "%. Automatic offset was not applied; verify timing manually.";
                    }
                    break;
                } catch (audioMatchErr) {}
            }
        }


        var pauseThreshold = parseFloat(cfg.pause);
        var maxLinePercent = parseFloat(cfg.width);
        var offset = (cfg.offset === "auto" || cfg.offset === "" || cfg.offset === null) ? autoOffset : parseFloat(cfg.offset);
        var fadeDuration = parseFloat(cfg.fade);
        var wipeLead = parseFloat(cfg.wipeLead);
        var wipeDuration = parseFloat(cfg.wipeDuration);
        var disableSourceAfter = !!cfg.hideSource;
        if (cfg.offset === "auto") L4_emit("LOG", audioOffsetNote);
        L4_emit("LOG", "Offset " + (isNaN(offset) ? "?" : offset.toFixed(3)) + "s · " + data.words.length + " words loaded");
        L4_emit("PROG", "0.03"); L4_emit("STAGE", "Planning captions");
        if (isNaN(pauseThreshold) || pauseThreshold < 0 ||
            isNaN(maxLinePercent) || maxLinePercent < 40 || maxLinePercent > 98 ||
            isNaN(offset) || isNaN(fadeDuration) || fadeDuration <= 0 ||
            isNaN(wipeLead) || wipeLead < 0 ||
            isNaN(wipeDuration) || wipeDuration <= 0) {
            tell("Invalid settings. Pause/lead must be non-negative, safe width 40–98% of the composition, and fade/wipe durations positive."); return;
        }

        // Validate timestamps before changing the project.
        for (var vi = 0; vi < data.words.length; vi++) {
            var vw = data.words[vi];
            if (!vw || isNaN(Number(vw.start)) || isNaN(Number(vw.end)) || Number(vw.end) < Number(vw.start)) {
                tell("Invalid timestamp at word " + (vi + 1) + ". No layers were created."); return;
            }
            if (vi > 0 && Number(vw.start) < Number(data.words[vi - 1].start)) {
                tell("Word timestamps are not in chronological order near word " + (vi + 1) + ". No layers were created."); return;
            }
        }

        function cleanWord(w) { return String(w.word || "").replace(/^\s+|\s+$/g, ""); }

        // AE's sourceRectAtTime measurement on a temporary duplicate can under-report the
        // final rendered width of text that uses the template's tracking/effects. Apply a
        // conservative 15% layout allowance so captions split earlier, inside the safe area.
        // This does NOT scale text or change any FFX/animation properties.
        var SAFE_WIDTH_MEASURE_FACTOR = 1.15;

        function createCaptionGroups(allWords, widthPercent) {
            var measureLayer = null;
            try {
                // Measure on a temporary duplicate, never on the user's source layer.
                measureLayer = source.duplicate();
                measureLayer.name = "__L4_TEMP_WIDTH_MEASURE__";
                var measureTextProps = measureLayer.property("ADBE Text Properties");
                var measureDocProp = measureTextProps.property("ADBE Text Document");
                var baseDoc = measureDocProp.value;
                var fontSize = Number(baseDoc.fontSize) || 42;
                var scaleX = 100;
                try { scaleX = Math.abs(Number(measureLayer.property("ADBE Transform Group").property("ADBE Scale").value[0])) || 100; } catch (scaleErr) {}
                if (scaleX < 0.01) scaleX = 100;
                var maxWidth = comp.width * (widthPercent / 100) / (scaleX / 100);
                var widthCache = {};
                var usingFallback = false;

                // Remove text animators from the temporary measuring duplicate so its bounds
                // reflect the actual styled glyphs, not a keyed selector at the current time.
                var measureAnimators = measureTextProps.property("ADBE Text Animators");
                if (measureAnimators) {
                    for (var ma = measureAnimators.numProperties; ma >= 1; ma--) measureAnimators.property(ma).remove();
                }
                function fallbackWidth(text) {
                    var width = 0;
                    for (var fc = 0; fc < text.length; fc++) {
                        var ch = text.charAt(fc);
                        if (/\s/.test(ch)) width += fontSize * 0.32;
                        else if (/[I1\.,'!:;]/.test(ch)) width += fontSize * 0.30;
                        else if (/[MW@%]/.test(ch)) width += fontSize * 0.82;
                        else width += fontSize * 0.58;
                    }
                    return width;
                }
                function textWidth(text) {
                    var cacheKey = "$" + text;
                    if (widthCache[cacheKey] !== undefined) return widthCache[cacheKey];
                    var width = 0;
                    try {
                        var doc = measureDocProp.value;
                        doc.text = text;
                        measureDocProp.setValue(doc);
                        if (typeof measureLayer.sourceRectAtTime === "function") {
                            var rect = measureLayer.sourceRectAtTime(0, false);
                            width = Number(rect.width) || 0;
                        }
                    } catch (measureErr) { width = 0; }
                    if (!(width > 0)) { usingFallback = true; width = fallbackWidth(text); }
                    width = width * SAFE_WIDTH_MEASURE_FACTOR;
                    widthCache[cacheKey] = width;
                    return width;
                }
                function lineString(words) {
                    var tokens = [];
                    for (var i = 0; i < words.length; i++) tokens.push(cleanWord(words[i]).toUpperCase());
                    return tokens.join(" ");
                }
                function bestLineSplit(words) {
                    var n = words.length;
                    if (n <= 3) return textWidth(lineString(words)) <= maxWidth || n === 1 ? 0 : -1;
                    var best = -1, bestScore = 999999;
                    // Prefer natural phrase boundaries while still balancing both lines.
                    // Never alter font size, word order, audio timestamps, or animation keys.
                    var weakLineEnd = /^(A|AN|THE|OF|TO|IN|ON|AT|BY|FOR|FROM|WITH|AS|AND|OR|BUT|NOR|SO|YET|IF|THAT|THIS|IS|ARE|WAS|WERE|BE|BEEN|BEING|MY|YOUR|HIS|HER|OUR|THEIR)$/i;
                    for (var sp = 1; sp < n; sp++) {
                        var left = words.slice(0, sp), right = words.slice(sp);
                        var leftWidth = textWidth(lineString(left));
                        var rightWidth = textWidth(lineString(right));
                        if (leftWidth > maxWidth || rightWidth > maxWidth) continue;
                        var score = Math.abs(left.length - right.length) * 100 + Math.abs(leftWidth - rightWidth);
                        var leftToken = cleanWord(words[sp - 1]);
                        var rightToken = cleanWord(words[sp]);
                        // A comma/semicolon/colon/dash is a strong visual phrase boundary.
                        if (/[,:;—–-]["'\)\]]*$/.test(leftToken)) score -= 85;
                        // Avoid ending line one on a small connector/article where possible.
                        if (weakLineEnd.test(leftToken.replace(/[.!?…,:;]+$/, ""))) score += 145;
                        // Avoid beginning line two with a punctuation-only token.
                        if (/^[,;:!?…]+$/.test(rightToken)) score += 1000;
                        // Tiny final words often read better attached to the previous phrase.
                        if (sp === n - 1 && /^(A|AN|THE|OF|TO|IN|ON|AT|BY|FOR|WITH|AND|OR)$/i.test(rightToken)) score += 45;
                        if (score < bestScore) { bestScore = score; best = sp; }
                    }
                    return best;
                }
                function fitsCaption(words) {
                    if (words.length <= 3) return textWidth(lineString(words)) <= maxWidth || words.length === 1;
                    return bestLineSplit(words) >= 0;
                }
                function endsSentence(word) { return /[.!?…]["'\)\]]*$/.test(cleanWord(word)); }
                function makeText(words) {
                    var line = lineString(words);
                    if (words.length <= 3) return line;
                    var split = bestLineSplit(words);
                    if (split < 1) split = Math.ceil(words.length / 2); // fallback only for an exceptionally wide single token
                    return lineString(words.slice(0, split)) + "\r" + lineString(words.slice(split));
                }

                var result = [], current = [];
                for (var wi = 0; wi < allWords.length; wi++) {
                    var word = allWords[wi];
                    if (current.length > 0) {
                        var prev = current[current.length - 1];
                        var gap = Number(word.start) - Number(prev.end);
                        var candidate = current.concat([word]);
                        var splitForPause = gap >= pauseThreshold;
                        var splitForPunctuation = endsSentence(prev);
                        var splitForWordLimit = current.length >= 8;
                        var splitForWidth = !fitsCaption(candidate);
                        if (splitForPause || splitForPunctuation || splitForWordLimit || splitForWidth) {
                            current.captionText = makeText(current);
                            result.push(current);
                            current = [];
                        }
                    }
                    current.push(word);
                }
                if (current.length) { current.captionText = makeText(current); result.push(current); }
                result.usedWidthFallback = usingFallback;
                result.maxWidth = maxWidth;
                return result;
            } finally {
                if (measureLayer) { try { measureLayer.remove(); } catch (removeErr) {} }
            }
        }
        var groups;
        try { groups = createCaptionGroups(data.words, maxLinePercent); }
        catch (groupErr) { tell("Could not safely calculate caption layout:\n" + groupErr.toString() + "\nNo caption layers were generated."); return; }

        // Fixed safe-area audit. Font size is never changed; any individual word wider than
        // the safe width is left intact on its own caption line and reported to the user.
        var oversizedWords = [];
        try {
            var auditLayer = source.duplicate();
            auditLayer.name = "__L4_TEMP_SAFE_AREA_AUDIT__";
            var auditTextProps = auditLayer.property("ADBE Text Properties");
            var auditDocProp = auditTextProps.property("ADBE Text Document");
            var auditAnimators = auditTextProps.property("ADBE Text Animators");
            if (auditAnimators) {
                for (var aa = auditAnimators.numProperties; aa >= 1; aa--) auditAnimators.property(aa).remove();
            }
            var auditScaleX = 100;
            try { auditScaleX = Math.abs(Number(auditLayer.property("ADBE Transform Group").property("ADBE Scale").value[0])) || 100; } catch (auditScaleErr) {}
            if (auditScaleX < 0.01) auditScaleX = 100;
            var auditMaxWidth = comp.width * (maxLinePercent / 100) / (auditScaleX / 100);
            for (var aw = 0; aw < data.words.length; aw++) {
                var originalWord = cleanWord(data.words[aw]);
                var auditDoc = auditDocProp.value;
                auditDoc.text = originalWord.toUpperCase();
                auditDocProp.setValue(auditDoc);
                var auditWidth = 0;
                try { auditWidth = Number(auditLayer.sourceRectAtTime(0, false).width) || 0; } catch (auditMeasureErr) {}
                auditWidth = auditWidth * SAFE_WIDTH_MEASURE_FACTOR;
                if (auditWidth > auditMaxWidth) oversizedWords.push(originalWord);
            }
            auditLayer.remove();
        } catch (auditErr) {
            try { if (auditLayer) auditLayer.remove(); } catch (auditRemoveErr) {}
        }

        function findAnimator(animators, name) {
            for (var a = 1; a <= animators.numProperties; a++) if (animators.property(a).name === name) return animators.property(a);
            return null;
        }
        function findTrackingAmount(layer) {
            var textProps = layer.property("ADBE Text Properties");
            var animators = textProps ? textProps.property("ADBE Text Animators") : null;
            if (!animators) return null;
            for (var a = 1; a <= animators.numProperties; a++) {
                var animator = animators.property(a);
                if (animator.name !== "Tracking") continue;
                var props = animator.property("ADBE Text Animator Properties");
                if (!props) return null;
                try { return props.property("ADBE Text Tracking Amount"); } catch (e) { return null; }
            }
            return null;
        }
        function findWipeCompletion(layer) {
            var effects = layer.property("ADBE Effect Parade");
            if (!effects) return null;
            var wipe = null;
            for (var e = 1; e <= effects.numProperties; e++) if (effects.property(e).name === "Linear Wipe") { wipe = effects.property(e); break; }
            if (!wipe) return null;
            for (var p = 1; p <= wipe.numProperties; p++) {
                var prop = wipe.property(p);
                if (prop.name === "Transition Completion" || prop.matchName === "ADBE Linear Wipe-0001") return prop;
            }
            return null;
        }
        function copyKeyRecord(prop, k) {
            var r = {t:prop.keyTime(k), v:prop.keyValue(k)};
            try { r.inI = prop.keyInInterpolationType(k); r.outI = prop.keyOutInterpolationType(k); } catch (e1) {}
            try { r.inE = prop.keyInTemporalEase(k); r.outE = prop.keyOutTemporalEase(k); } catch (e2) {}
            try { r.autoB = prop.keyTemporalAutoBezier(k); r.cont = prop.keyTemporalContinuous(k); } catch (e3) {}
            return r;
        }
        function restoreKeys(prop, recs) {
            try {
                while (prop.numKeys > 0) prop.removeKey(1);
                for (var i = 0; i < recs.length; i++) prop.setValueAtTime(recs[i].t, recs[i].v);
                for (var j = 0; j < recs.length; j++) {
                    var idx = prop.nearestKeyIndex(recs[j].t);
                    try { if (recs[j].inI !== undefined) prop.setInterpolationTypeAtKey(idx, recs[j].inI, recs[j].outI); } catch (e4) {}
                    try { if (recs[j].inE && recs[j].outE) prop.setTemporalEaseAtKey(idx, recs[j].inE, recs[j].outE); } catch (e5) {}
                    try { if (recs[j].autoB !== undefined) prop.setTemporalAutoBezierAtKey(idx, recs[j].autoB); } catch (e6) {}
                    try { if (recs[j].cont !== undefined) prop.setTemporalContinuousAtKey(idx, recs[j].cont); } catch (e7) {}
                }
            } catch (restoreErr) {}
        }
        function shiftEffectKeysRecursive(group, delta, warnings) {
            // Only effect properties are shifted. Do not recursively shift text animator keys.
            for (var p = 1; p <= group.numProperties; p++) {
                var prop = group.property(p);
                if (prop.propertyType === PropertyType.PROPERTY) {
                    if (!prop.numKeys || prop.numKeys < 1) continue;
                    try { if (prop.expressionEnabled) continue; } catch (ignoreExpr) {}
                    var recs = [];
                    for (var k = 1; k <= prop.numKeys; k++) recs.push(copyKeyRecord(prop, k));
                    var ok = true;
                    try {
                        while (prop.numKeys > 0) prop.removeKey(1);
                        for (var q = 0; q < recs.length; q++) prop.setValueAtTime(recs[q].t + delta, recs[q].v);
                        for (var z = 0; z < recs.length; z++) {
                            var idx = prop.nearestKeyIndex(recs[z].t + delta);
                            try { if (recs[z].inI !== undefined) prop.setInterpolationTypeAtKey(idx, recs[z].inI, recs[z].outI); } catch (e1) {}
                            try { if (recs[z].inE && recs[z].outE) prop.setTemporalEaseAtKey(idx, recs[z].inE, recs[z].outE); } catch (e2) {}
                            try { if (recs[z].autoB !== undefined) prop.setTemporalAutoBezierAtKey(idx, recs[z].autoB); } catch (e3) {}
                            try { if (recs[z].cont !== undefined) prop.setTemporalContinuousAtKey(idx, recs[z].cont); } catch (e4) {}
                        }
                    } catch (shiftErr) { ok = false; restoreKeys(prop, recs); }
                    if (!ok) warnings.count++;
                } else {
                    try { shiftEffectKeysRecursive(prop, delta, warnings); } catch (ignoreChild) {}
                }
            }
        }
        function setWordSelectors(layer, words, start, fade) {
            var textProps = layer.property("ADBE Text Properties");
            var animators = textProps.property("ADBE Text Animators");
            var fadeAnimator = findAnimator(animators, "Fade Up Words");
            if (!fadeAnimator) throw new Error("Source layer has no animator named 'Fade Up Words'. Apply the original main text animation.ffx first.");
            var selectors = fadeAnimator.property("ADBE Text Selectors");
            for (var r = selectors.numProperties; r >= 1; r--) selectors.property(r).remove();
            for (var n = 0; n < words.length; n++) {
                var sel = selectors.addProperty("ADBE Text Selector");
                sel.name = "Word " + (n + 1);
                var adv = sel.property("ADBE Text Range Advanced");
                adv.property("ADBE Text Range Type2").setValue(3); // Words
                adv.property("ADBE Text Range Units").setValue(2); // Index
                adv.property("ADBE Text Selector Mode").setValue(1);
                adv.property("ADBE Text Levels Max Ease").setValue(0);
                adv.property("ADBE Text Levels Min Ease").setValue(0);
                adv.property("ADBE Text Randomize Order").setValue(false);
                sel.property("ADBE Text Index Start").setValue(n);
                sel.property("ADBE Text Index End").setValue(n + 1);
                sel.property("ADBE Text Index Offset").setValue(0);
                var amount = null;
                try { amount = adv.property("ADBE Text Selector Max Amount"); } catch (e1) {}
                if (!amount) {
                    for (var ap = 1; ap <= adv.numProperties; ap++) {
                        var candidate = adv.property(ap);
                        if (candidate.name === "Amount" && candidate.propertyType === PropertyType.PROPERTY) { amount = candidate; break; }
                    }
                }
                if (!amount) throw new Error("Could not locate writable Advanced > Amount for Word " + (n + 1) + ".");
                var wordStart = Number(words[n].start) + offset; // Never accumulate spacing: this must stay locked to Whisper audio timestamps.
                amount.setValueAtTime(wordStart, 100);
                amount.setValueAtTime(wordStart + fade, 0);
            }
        }
        function setTrackingKeys(layer, start) {
            var tracking = findTrackingAmount(layer);
            if (!tracking || tracking.numKeys < 2) return false;
            var recs = [];
            for (var k = 1; k <= tracking.numKeys; k++) recs.push(copyKeyRecord(tracking, k));
            var firstValue = recs[0].v, lastValue = recs[recs.length - 1].v;
            var duration = Math.max(0.35, recs[recs.length - 1].t - recs[0].t);
            try {
                while (tracking.numKeys > 0) tracking.removeKey(1);
                tracking.setValueAtTime(start, firstValue);
                tracking.setValueAtTime(start + duration, lastValue);
                return true;
            } catch (writeErr) {
                restoreKeys(tracking, recs);
                return false;
            }
        }
        function setWipeKeys(layer, start, end) {
            var completion = findWipeCompletion(layer);
            if (!completion) throw new Error("Could not locate Linear Wipe > Transition Completion on the duplicate.");
            var firstValue = 0, lastValue = 100;
            if (completion.numKeys >= 2) {
                firstValue = completion.keyValue(1);
                lastValue = completion.keyValue(completion.numKeys);
            } else {
                try { firstValue = completion.value; } catch (e) {}
            }
            while (completion.numKeys > 0) completion.removeKey(1);
            completion.setValueAtTime(start, firstValue);
            completion.setValueAtTime(end, lastValue);
        }

        var plans = [];
        for (var gi = 0; gi < groups.length; gi++) {
            var grp = groups[gi];
            var start = Number(grp[0].start) + offset;
            var spokenEnd = Number(grp[grp.length - 1].end) + offset;
            var wipeStart = Math.max(start, spokenEnd - wipeLead);
            plans.push({words:grp, captionText:grp.captionText, start:start, spokenEnd:spokenEnd, wipeStart:wipeStart,
                        wipeEnd:wipeStart + wipeDuration, layerEnd:wipeStart + wipeDuration + 0.20});
        }

        // RANGE GUARD: drop captions that fall completely outside the composition
        // (e.g. trimmed clip or comp shorter than the transcribed audio). Previously a
        // single out-of-range caption aborted the whole run with "invalid layer duration".
        (function () {
            var kept = [], dropped = [];
            for (var pi = 0; pi < plans.length; pi++) {
                var pl = plans[pi];
                var pEnd = Math.min(comp.duration, Math.max(pl.layerEnd, pl.spokenEnd + 0.80));
                var pStart = Math.max(0, pl.start);
                if (pEnd - pStart > 0.01) kept.push(pl); else dropped.push(pi + 1);
            }
            if (dropped.length) {
                L4_emit("LOG", "Skipped " + dropped.length + " caption(s) outside the composition length (" +
                    comp.duration.toFixed(2) + "s): original #" + dropped.join(", #") +
                    ". Extend the comp or check the audio offset if these should appear.");
                plans = kept;
            }
        })();

        L4_emit("LOG", plans.length + " captions planned"); L4_emit("PROG", "0.08");
        app.beginUndoGroup("L4 Style 2 — Auto Caption");
        var created = [], warnings = {count:0}, trackingWarnings = 0, currentStage = "starting";
        try {
            for (var ci = 0; ci < plans.length; ci++) {
                L4_emit("PROG", (0.08 + 0.90 * ci / plans.length).toFixed(3)); L4_emit("STAGE", "Caption " + (ci + 1) + " of " + plans.length);
                var plan = plans[ci];
                currentStage = "duplicating source for caption " + (ci + 1);
                var dup = source.duplicate();
                dup.name = "L4 TEXT STYLE 2 — Caption " + (ci + 1);
                dup.startTime = source.startTime;
                dup.inPoint = Math.max(0, plan.start);
                dup.outPoint = Math.min(comp.duration, Math.max(plan.layerEnd, plan.spokenEnd + 0.80));
                if (dup.outPoint <= dup.inPoint) {
                    dup.remove();
                    throw new Error("Caption " + (ci + 1) + " has an invalid layer duration after applying its audio timestamps.");
                }

                currentStage = "shifting only effect keyframes for caption " + (ci + 1);
                var effects = dup.property("ADBE Effect Parade");
                if (effects) shiftEffectKeysRecursive(effects, plan.start, warnings);

                currentStage = "setting caption text for caption " + (ci + 1);
                var textProp = dup.property("ADBE Text Properties").property("ADBE Text Document");
                var doc = textProp.value;
                doc.text = plan.captionText;
                textProp.setValue(doc);

                currentStage = "setting Fade Up Words for caption " + (ci + 1);
                setWordSelectors(dup, plan.words, plan.start, fadeDuration);
                currentStage = "setting Increase Tracking for caption " + (ci + 1);
                if (!setTrackingKeys(dup, plan.start)) trackingWarnings++;
                currentStage = "setting Linear Wipe OUT for caption " + (ci + 1);
                setWipeKeys(dup, plan.wipeStart, plan.wipeEnd);
                created.push(dup);
            }
            // Deterministically order generated caption layers top-to-bottom by audio chronology.
            // AE duplicate() insertion order can vary with the selected source's stack position;
            // explicitly rebuild the stack as Caption 1, Caption 2, ... Caption N, then source.
            for (var orderIndex = created.length - 1; orderIndex >= 0; orderIndex--) {
                created[orderIndex].moveBefore(source);
            }
            // Do not touch the original template unless the user explicitly checked the option.
            if (cfg.removeSource) { try { source.remove(); } catch (rmErr) { source.enabled = false; } }
            else if (disableSourceAfter) source.enabled = false;
            app.endUndoGroup();
            var summary = "Created " + created.length + " caption layers in chronological layer-stack order from " + data.words.length + " word timestamps.\n" +
                "Rules: max 8 words; split on punctuation/pauses; 4+ words use phrase-aware balanced lines; line breaks prefer comma/semicolon/colon/dash boundaries and avoid ending line one on small connector words. 2–3 words stay together only if they fit; oversized single words remain unchanged and are reported.\n" +
                "Fixed safe area: " + maxLinePercent.toFixed(0) + "% of composition width; font size is never changed. Measured width " + (groups.usedWidthFallback ? "used approximate fallback (sourceRectAtTime unavailable)." : "uses source text bounds") + "; safe width " + groups.maxWidth.toFixed(0) + " px.\n" +
                "Fade Up Words: " + fadeDuration.toFixed(2) + "s; exact Whisper timestamps used (no cumulative spacing drift).\n" +
                "Linear Wipe: starts " + wipeLead.toFixed(2) + "s before spoken end and lasts " + wipeDuration.toFixed(2) + "s.\n" +
                "Original template layer: " + (disableSourceAfter ? "disabled by your checkbox (not deleted)." : "left unchanged and enabled.") + "\n" +
                "Effect-keyframe shift warnings: " + warnings.count + "; Tracking warnings: " + trackingWarnings + ".\n\n";
            for (var si = 0; si < plans.length; si++) {
                summary += "Caption " + (si + 1) + " (" + plans[si].words.length + " words): " +
                    plans[si].start.toFixed(2) + "s–" + plans[si].spokenEnd.toFixed(2) + "s; wipe " +
                    plans[si].wipeStart.toFixed(2) + "s–" + plans[si].wipeEnd.toFixed(2) + "s\n";
            }
            if (oversizedWords.length > 0) {
                summary += "\nSAFE-AREA WARNING — " + oversizedWords.length + " word(s) are wider than the fixed safe area at the existing font size. They were NOT shrunk. Each is kept intact and isolated where caption grouping allows:\n";
                var shownOversized = {};
                for (var ow = 0; ow < oversizedWords.length; ow++) {
                    var owKey = "$" + oversizedWords[ow].toUpperCase();
                    if (!shownOversized[owKey]) { summary += "• " + oversizedWords[ow] + "\n"; shownOversized[owKey] = true; }
                }
                summary += "If any listed word still crosses the red boundary, that word itself is wider than the safe area; font size remains unchanged as requested.";
            } else {
                summary += "\nSafe-area audit: all individual words fit the fixed safe width at the existing font size.";
            }
            summary += "\n\nReview the full composition. If the original template text is visible underneath, undo or toggle its visibility manually; this script leaves it untouched by default.";
            RESULT.ok = true; RESULT.message = "Created " + created.length + " captions";
            RESULT.glowTried = false; RESULT.count = created.length; RESULT.warnings = warnings.count + trackingWarnings; RESULT.oversized = oversizedWords.length;
            RESULT.summary = summary; L4_emit("PROG", "1"); L4_emit("STAGE", "Done");
        } catch (err) {
            try { app.endUndoGroup(); } catch (ignoreEnd) {}
            tell("Stopped at: " + currentStage + "\n\n" + err.toString() +
                 "\n\nThe original template was not intentionally modified (unless you checked the optional disable box, which is applied only after generation). If partial duplicates exist, press Ctrl+Z once to undo this run.");
        }
    })();
    return L4_json(RESULT);
}
