(function () {
  'use strict';
  var $ = function (id) { return document.getElementById(id); };
  var hasNode = typeof require === 'function';
  var fs = hasNode ? require('fs') : null;
  var path = hasNode ? require('path') : null;
  var cp = hasNode ? require('child_process') : null;

  var STYLES = {
    '1': { name: 'L4 Style 1', ffx: 'text_animation.ffx', glow: true, fn: 'L4_generate', note: 'Two-tone captions with rotating fonts and colours, plus glow.' },
    '2': { name: 'L4 Style 2', ffx: 'simple_text_animation.ffx', glow: false, fn: 'L4_generate2', note: 'Simple clean captions with fade-up words, tracking and wipe.' }
  };
  var S = { style: '1', view: 'home', running: false, child: null, pollTimer: null, valid: false, phase: '' };
  var ROOT = '';

  /* ---------- helpers ---------- */
  function esc(t) { return String(t).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }
  function pad2(n) { return (n < 10 ? '0' : '') + n; }
  function clock() { var d = new Date(); return pad2(d.getHours()) + ':' + pad2(d.getMinutes()) + ':' + pad2(d.getSeconds()); }
  var toastT;
  function toast(m) { var t = $('toast'); t.textContent = m; t.classList.add('show'); clearTimeout(toastT); toastT = setTimeout(function () { t.classList.remove('show'); }, 2200); }
  function extRoot() {
    try {
      var p = decodeURI(window.__adobe_cep__.getSystemPath('extension').replace(/^file:\/\//, ''));
      if (/^\/[A-Za-z]:/.test(p)) p = p.slice(1);
      return p;
    } catch (e) {
      try { var q = decodeURI(location.pathname).replace(/\/[^\/]*$/, ''); if (/^\/[A-Za-z]:/.test(q)) q = q.slice(1); return q; } catch (e2) { return ''; }
    }
  }
  function exists(p) { try { return fs.existsSync(p); } catch (e) { return false; } }

  /* ---------- progress ---------- */
  function setBar(p) {
    var el = $('bar'), wrap = el.parentNode;
    wrap.classList.remove('indet', 'done', 'fail');
    if (p === null) wrap.classList.add('indet');
    else { el.style.transform = 'scaleX(' + Math.max(0, Math.min(1, p)) + ')'; $('pct').textContent = Math.round(p * 100) + '%'; }
  }
  function stage(text, p) { $('stage').textContent = text; if (p === null) $('pct').textContent = ''; setBar(p); }

  /* ---------- log ---------- */
  var LOG = [];
  function log(kind, text) {
    text = String(text); if (!text) return;
    if (kind === 'info' && /warning|issue|skipped|not found/i.test(text)) kind = 'warn';
    LOG.push(clock() + '  ' + text);
    var box = $('log'), empty = box.querySelector('.empty'); if (empty) empty.remove();
    var row = document.createElement('div');
    row.innerHTML = '<time>' + clock() + '</time><span class="' + kind + '">' + esc(text) + '</span>';
    box.appendChild(row); box.scrollTop = box.scrollHeight;
    if (kind !== 'stage') $('logLast').textContent = text;
  }
  function copyLog() {
    var ta = document.createElement('textarea'); ta.value = LOG.join('\n'); document.body.appendChild(ta); ta.select();
    try { document.execCommand('copy'); toast('Log copied'); } catch (e) { toast('Could not copy'); }
    ta.remove();
  }

  /* ---------- host bridge ---------- */
  function host(fn, arg) {
    return new Promise(function (resolve, reject) {
      if (!window.__adobe_cep__) { reject(new Error('Not running inside After Effects')); return; }
      var call = fn + '(' + (arg === undefined ? '' : JSON.stringify(String(arg))) + ')';
      window.__adobe_cep__.evalScript(call, function (res) {
        if (res === 'EvalScript error.' || res === undefined) { reject(new Error('Host script error. Close and reopen the panel.')); return; }
        try { resolve(JSON.parse(res)); } catch (e) { reject(new Error('Unexpected host reply')); }
      });
    });
  }

  /* ---------- navigation ---------- */
  function go(name) {
    if (S.view === name) return;
    var from = $('view-' + S.view), to = $('view-' + name), sub = name !== 'home';
    from.classList.remove('active'); from.classList.add(sub ? 'left' : 'right');
    to.classList.remove('left', 'right'); to.classList.add('active');
    S.view = name; $('topbar').classList.toggle('sub', sub); $('btnBack').hidden = !sub;
    var t = $('topTitle'); t.style.opacity = 0;
    setTimeout(function () { t.innerHTML = sub ? '<b>Auto Caption</b>' : '<b>L4XYVS</b><span>SUITE</span>'; t.style.opacity = 1; }, 140);
    if (sub) refreshLayer();
  }

  /* ---------- styles + preview ---------- */
  function initPreview() {
    var dir = path.join(ROOT, 'assets', 'previews');
    var files = [];
    try { files = fs.readdirSync(dir); } catch (e) {}
    document.querySelectorAll('.style-tile').forEach(function (tile) {
      var n = tile.getAttribute('data-style'), v = tile.querySelector('video'), ph = tile.querySelector('.ph');
      // Accept l4_style_1.webm, "L4 Style 1.mp4", l4-style-1.webm ... (any case / separator)
      var re = new RegExp('^l4[ _-]?style[ _-]?' + n + '\\.(webm|mp4)$', 'i'), hit = null;
      ['webm', 'mp4'].some(function (ext) {
        return files.some(function (f) { if (re.test(f) && f.toLowerCase().slice(-ext.length) === ext) { hit = f; return true; } return false; });
      });
      if (!hit) return;
      v.muted = true; v.loop = true; v.setAttribute('playsinline', '');
      v.addEventListener('loadeddata', function () { ph.style.display = 'none'; var pr = v.play(); if (pr && pr.catch) pr.catch(function () {}); });
      v.addEventListener('error', function () { ph.style.display = ''; });
      v.src = 'assets/previews/' + encodeURIComponent(hit);
      v.load();
    });
  }
  function selectStyle(n) {
    if (S.running || !STYLES[n]) return;
    S.style = n; try { localStorage.setItem('l4xyvs.style', n); } catch (e) {}
    document.querySelectorAll('.style-tile').forEach(function (tile) {
      var on = tile.getAttribute('data-style') === n; tile.classList.toggle('active', on); tile.setAttribute('aria-pressed', String(on));
    });
    var note = $('styleNote'); note.style.opacity = 0;
    setTimeout(function () { note.textContent = STYLES[n].note; note.style.opacity = 1; }, 120);
    $('result').classList.add('hidden'); refreshLayer();
  }

  /* ---------- selection status ---------- */
  var KIND = { footage: 'Audio / video layer', comp: 'Pre-comp layer' };
  function refreshLayer() {
    if (S.view !== 'caption' || S.running || document.hidden) return;
    host('L4_preflight').then(function (r) {
      var cls = 'ok', msg, valid = false;
      if (!r.isComp) { cls = 'warn'; msg = 'Open a composition'; }
      else if (!r.perm) { cls = 'err'; msg = 'Turn on Preferences > Scripting & Expressions > Allow Scripts to Write Files and Access Network'; }
      else if (r.sel === 0) { cls = 'warn'; msg = 'Select an audio, video or pre-comp layer'; }
      else if (r.sel > 1) { cls = 'warn'; msg = 'Select only one layer'; }
      else if (r.kind === 'none') { cls = 'warn'; msg = 'This layer has no usable audio. Select an audio, video or pre-comp layer'; }
      else if (!r.hasAudio) { cls = 'warn'; msg = r.layer + ' has no audio'; }
      else { msg = KIND[r.kind] + ': ' + r.layer; valid = true; }
      var miss = [], st = STYLES[S.style];
      if (!exists(path.join(ROOT, 'assets', st.ffx))) miss.push(st.ffx);
      if (st.glow && !exists(path.join(ROOT, 'assets', 'text_glow.ffx'))) miss.push('text_glow.ffx');
      var pl = $('presetLine'); pl.classList.toggle('hidden', !miss.length);
      if (miss.length) $('presetText').textContent = 'Missing: ' + miss.join(', ') + '. Put the file in ' + path.join(ROOT, 'assets');
      S.valid = valid; $('layerLine').className = 'layer-line ' + cls; $('layerText').textContent = msg;
      $('btnGo').disabled = !valid || S.running;
    }).catch(function (e) { S.valid = false; $('btnGo').disabled = true; $('layerLine').className = 'layer-line warn'; $('layerText').textContent = e.message; });
  }

  /* ---------- python / whisper ---------- */
  function killTree(child) {
    if (!child) return;
    try {
      if (process.platform === 'win32') cp.spawn('taskkill', ['/pid', String(child.pid), '/T', '/F'], { windowsHide: true });
      else child.kill('SIGKILL');
    } catch (e) {}
  }
  function runCmd(cmd) {
    return new Promise(function (resolve) {
      var out = '', c = cp.spawn(cmd, [], { shell: true, windowsHide: true });
      c.stdout.on('data', function (d) { out += d; }); c.stderr.on('data', function (d) { out += d; });
      c.on('close', function (code) { resolve({ ok: code === 0, out: out }); });
      c.on('error', function () { resolve({ ok: false, out: '' }); });
    });
  }
  function detectPython() {
    return runCmd('py -3 --version').then(function (r) {
      if (r.ok) return 'py -3';
      return runCmd('python --version').then(function (r2) {
        if (r2.ok) return 'python';
        throw new Error('Python was not found. Install Python 3, then run: pip install -U openai-whisper');
      });
    });
  }
  function transcribe(py, audio, out) {
    return new Promise(function (resolve, reject) {
      var cli = path.join(ROOT, 'tools', 'l4_transcribe_cli.py');
      var cmd = py + ' -u "' + cli + '" --input "' + audio + '" --output "' + out + '" --model small';
      var errs = [], buf = '', done = false, cancelled = false;
      var child = cp.spawn(cmd, [], { shell: true, windowsHide: true, env: Object.assign({}, process.env, { PYTHONIOENCODING: 'utf-8' }) });
      S.child = child; $('btnCancel').classList.remove('hidden');
      $('btnCancel').onclick = function () { cancelled = true; killTree(child); };
      child.stdout.on('data', function (d) {
        buf += d.toString('utf8'); var lines = buf.split(/\r?\n/); buf = lines.pop();
        lines.forEach(function (ln) {
          var i = ln.indexOf('|'); if (i < 0) return; var k = ln.slice(0, i), v = ln.slice(i + 1);
          if (k === 'STAGE') { log('stage', v); stage(v, null); }
          else if (k === 'DONE') done = v; else if (k === 'ERR') errs.push(v);
        });
      });
      child.stderr.on('data', function (d) {
        var s = d.toString('utf8'), m = s.match(/(\d{1,3})%\|/g);
        if (m) {
          var pct = parseInt(m[m.length - 1], 10);
          if (/frames/.test(s)) { $('stage').textContent = 'Transcribing'; setBar(0.08 + 0.47 * pct / 100); }
          else if (/iB|MB/.test(s)) { $('stage').textContent = 'Downloading model'; setBar(0.08 + 0.47 * pct / 100); }
        } else if (/error|traceback|exception/i.test(s)) errs.push(s.trim().split(/\r?\n/).slice(-2).join(' '));
      });
      child.on('error', function (e) { errs.push(e.message); });
      child.on('close', function (code) {
        S.child = null; $('btnCancel').classList.add('hidden');
        if (cancelled) { var c = new Error('Cancelled'); c.cancelled = true; reject(c); return; }
        if (done && code === 0) resolve(done);
        else reject(new Error(errs.length ? errs[errs.length - 1] : 'Transcription failed (code ' + code + ')'));
      });
    });
  }

  /* ---------- host progress polling ---------- */
  function startPoll(file) {
    var seen = 0;
    S.pollTimer = setInterval(function () {
      var txt; try { txt = fs.readFileSync(file, 'utf8'); } catch (e) { return; }
      var lines = txt.split(/\r?\n/).filter(Boolean);
      for (; seen < lines.length; seen++) {
        var ln = lines[seen], i = ln.indexOf('|'); if (i < 0) continue;
        var k = ln.slice(0, i), v = ln.slice(i + 1);
        if (k === 'PROG' && S.phase === 'gen') setBar(0.6 + 0.4 * parseFloat(v));
        else if (k === 'STAGE' && S.phase === 'gen') $('stage').textContent = v;
        else if (k === 'LOG') log('info', v);
        else if (k === 'ERR') log('err', v);
      }
    }, 120);
  }
  function stopPoll() { clearInterval(S.pollTimer); S.pollTimer = null; }

  /* ---------- result ---------- */
  var ICON_OK = '<svg viewBox="0 0 24 24"><path d="M5 12.5l4.5 4.5L19 7.5"/></svg>';
  var ICON_ERR = '<svg viewBox="0 0 24 24"><path d="M12 7v6M12 17h.01"/></svg>';
  function showResult(ok, title, sub) {
    var r = $('result'); r.classList.remove('hidden'); r.classList.toggle('err', !ok);
    r.innerHTML = '<span class="ico">' + (ok ? ICON_OK : ICON_ERR) + '</span><div><b>' + esc(title) + '</b>' + (sub ? '<p>' + esc(sub) + '</p>' : '') + '</div>';
    r.style.animation = 'none'; void r.offsetWidth; r.style.animation = '';
  }
  function finish() {
    stopPoll(); S.running = false; S.phase = ''; $('btnGo').textContent = 'Auto Caption';
    document.querySelectorAll('.style-tile').forEach(function (x) { x.disabled = false; });
    $('btnCancel').classList.add('hidden'); refreshLayer();
  }
  function failRun(msg) {
    var wrap = $('bar').parentNode; wrap.classList.remove('indet'); wrap.classList.add('fail'); $('bar').style.transform = 'scaleX(1)';
    $('stage').textContent = 'Stopped'; showResult(false, 'Could not finish', msg); log('err', msg);
    setTimeout(function () { $('prog').classList.add('hidden'); }, 900); finish();
  }

  /* ---------- the one action ---------- */
  function run() {
    if (S.running || !S.valid) return;
    S.running = true; S.phase = 'prep';
    $('btnGo').disabled = true; $('btnGo').textContent = 'Working'; document.querySelectorAll('.style-tile').forEach(function (x) { x.disabled = true; }); $('result').classList.add('hidden');
    $('prog').classList.remove('hidden'); $('bar').style.transform = 'scaleX(0)'; stage('Checking project', null);
    var ST = STYLES[S.style]; log('stage', 'Auto Caption started (' + ST.name + ')');
    var pf, au, py, wavPath, wordsPath, progFile;
    host('L4_preflight').then(function (r) {
      pf = r;
      if (!r.isComp || r.sel !== 1 || r.kind === 'none' || !r.hasAudio) throw new Error('Select one audio, video or pre-comp layer.');
      if (!exists(path.join(ROOT, 'assets', STYLES[S.style].ffx))) throw new Error(STYLES[S.style].ffx + ' is missing. Put it in the extension\'s assets folder.');
      if (!r.perm) throw new Error('Turn on Preferences > Scripting & Expressions > "Allow Scripts to Write Files and Access Network", then try again.');
      progFile = path.join(pf.temp, 'l4xyvs_progress.txt'); try { fs.unlinkSync(progFile); } catch (e) {}
      startPoll(progFile);
      return detectPython();
    }).then(function (p) {
      py = p; wavPath = path.join(pf.temp, 'l4xyvs_audio.wav'); wordsPath = path.join(pf.temp, 'l4xyvs_words.json');
      stage(pf.kind === 'comp' ? 'Rendering pre-comp audio' : 'Reading audio', null);
      return host('L4_getAudio', wavPath);
    }).then(function (a) {
      if (!a.ok) throw new Error(a.message || 'Could not get audio.');
      au = a; log('ok', 'Audio ready: ' + a.layer + (a.offset ? ' (starts at ' + a.offset.toFixed(2) + 's)' : ''));
      if (Math.abs(a.stretch - 100) > 0.001) log('warn', 'Layer time-stretch is ' + a.stretch + '%. Caption timing may drift.');
      stage('Loading Whisper', 0.08);
      return transcribe(py, a.audioPath, wordsPath);
    }).then(function (jsonPath) {
      var d = JSON.parse(fs.readFileSync(jsonPath, 'utf8').replace(/^\uFEFF/, ''));
      if (!d.words || !d.words.length) throw new Error('No speech was found in this audio.');
      log('ok', d.words.length + ' words transcribed' + (d.language ? ' (' + d.language + ')' : ''));
      stage('Preparing template', 0.57);
      return host('L4_prepare', JSON.stringify({ ffx: path.join(ROOT, 'assets', ST.ffx), name: ST.name.toUpperCase() }));
    }).then(function (p) {
      if (!p.ok) throw new Error(p.message || 'Could not create the template layer.');
      S.phase = 'gen'; stage('Building captions', 0.6);
      var glow = path.join(ROOT, 'assets', 'text_glow.ffx');
      if (ST.glow && !exists(glow)) log('warn', 'text_glow.ffx not found in assets, glow will be skipped');
      var cfg = {
        jsonPath: wordsPath, pause: '0.55', width: '58', offset: String(au.offset), fade: '0.20', wipeLead: '0.15', wipeDuration: '3.00',
        hideSource: true, removeSource: true, ai: ST.glow, pythonCmd: py,
        stylingPy: path.join(ROOT, 'tools', 'L4_Styling_Intelligence.py'), glowPath: (ST.glow && exists(glow)) ? glow : ''
      };
      return host(ST.fn, JSON.stringify(cfg));
    }).then(function (res) {
      if (!res.ok) { var m = String(res.message || 'Unknown error'); log('err', m); throw new Error(m.split('\n').filter(Boolean).slice(0, 3).join(' ')); }
      setBar(1); $('bar').parentNode.classList.add('done'); $('stage').textContent = 'Done';
      var sub = res.warnings ? res.warnings + ' fit warning' + (res.warnings > 1 ? 's' : '') + '. Details in Activity.' : 'Review the timeline.';
      if (res.glowTried) sub = (res.glow === res.glowTotal ? 'Glow applied to all ' + res.glow + ' captions. ' : 'Glow applied to ' + res.glow + ' of ' + res.glowTotal + ' captions. See Activity. ') + sub;
      else if (ST.glow) sub = 'Glow skipped: text_glow.ffx not found. ' + sub;
      showResult(true, res.message, sub); log('ok', res.message);
      String(res.summary || '').split('\n').forEach(function (l) { if (l.trim() && !/^Caption \d+/.test(l)) log('info', l.trim()); });
      setTimeout(function () { $('prog').classList.add('hidden'); }, 900); finish();
    }).catch(function (e) {
      if (e.cancelled) { log('warn', 'Cancelled'); $('prog').classList.add('hidden'); finish(); return; }
      failRun(e.message);
    });
  }

  /* ---------- init ---------- */
  function init() {
    ROOT = extRoot(); initPreview();
    var saved = '1'; try { saved = localStorage.getItem('l4xyvs.style') || '1'; } catch (e) {}
    document.querySelectorAll('.style-tile').forEach(function (x) { x.onclick = function () { selectStyle(x.getAttribute('data-style')); }; });
    selectStyle(STYLES[saved] ? saved : '1');
    $('log').innerHTML = '<div class="empty">Nothing yet.</div>';
    if (!hasNode) toast('Node is disabled. Reinstall the panel.');
    document.querySelectorAll('[data-open]').forEach(function (b) { b.onclick = function () { go(b.getAttribute('data-open')); }; });
    $('btnBack').onclick = function () { go('home'); };
    $('btnGo').onclick = run; $('btnCopyLog').onclick = copyLog;
    $('logHead').onclick = function () {
      var open = !$('logWrap').classList.contains('open');
      $('logWrap').classList.toggle('open', open); $('logHead').setAttribute('aria-expanded', String(open));
    };
    setInterval(refreshLayer, 1200); window.addEventListener('focus', refreshLayer);

    var t0 = performance.now(), MIN = 1700, ready = false;
    (window.__adobe_cep__ ? host('L4_preflight') : Promise.resolve()).catch(function () {}).then(function () { ready = true; });
    (function tick(now) {
      var p = Math.min(1, (now - t0) / MIN);
      $('splashBar').style.transform = 'scaleX(' + (ready ? p : Math.min(p, .85)) + ')';
      if (p < 1 || !ready) { requestAnimationFrame(tick); return; }
      $('app').classList.remove('hidden'); requestAnimationFrame(function () { $('app').classList.add('show'); });
      $('splash').classList.add('out'); setTimeout(function () { $('splash').remove(); }, 500);
    })(t0);
  }
  document.addEventListener('DOMContentLoaded', init);
})();
