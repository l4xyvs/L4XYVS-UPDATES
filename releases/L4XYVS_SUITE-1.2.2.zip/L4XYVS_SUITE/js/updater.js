/* L4XYVS SUITE - auto updater
 * Feed:    https://raw.githubusercontent.com/l4xyvs/L4XYVS-UPDATES/main/latest.json
 * Package: zip with a top-level L4XYVS_SUITE/ folder (built by publish_update.py)
 * Safety:  HTTPS + host allow-list, SHA-256, RSA signature (updater_pubkey.pem),
 *          no downgrades, zip-slip protection, rollback if any file fails to write.
 */
(function () {
  'use strict';

  var FEED_URL = 'https://raw.githubusercontent.com/l4xyvs/L4XYVS-UPDATES/main/latest.json';
  var PRODUCT = 'L4XYVS SUITE';
  var PKG_PREFIX = 'L4XYVS_SUITE/';
  var HOSTS = ['raw.githubusercontent.com', 'github.com', 'objects.githubusercontent.com', 'release-assets.githubusercontent.com'];
  var MAX_PKG = 120 * 1024 * 1024, MAX_UNPACKED = 300 * 1024 * 1024;
  var CHECK_EVERY_MS = 6 * 60 * 60 * 1000;
  var REQUIRED_FILES = ['CSXS/manifest.xml', 'index.html', 'js/main.js', 'jsx/host.jsx', 'version.json'];

  var hasNode = typeof require === 'function';
  var fs, path, os, https, http, urlMod, crypto, zlib;
  if (hasNode) {
    fs = require('fs'); path = require('path'); os = require('os'); https = require('https'); http = require('http');
    urlMod = require('url'); crypto = require('crypto'); zlib = require('zlib');
  }

  /* ---------- versions ---------- */
  function parseVer(v) {
    var m = /^(\d+)\.(\d+)\.(\d+)$/.exec(String(v || '').trim());
    return m ? [+m[1], +m[2], +m[3]] : null;
  }
  function cmpVer(a, b) {
    var x = parseVer(a), y = parseVer(b);
    if (!x || !y) throw new Error('Bad version number');
    for (var i = 0; i < 3; i++) if (x[i] !== y[i]) return x[i] < y[i] ? -1 : 1;
    return 0;
  }

  /* ---------- http ---------- */
  function httpGet(url, o) {
    o = o || {};
    return new Promise(function (resolve, reject) {
      var hops = 0;
      (function go(u) {
        var p;
        try { p = urlMod.parse(u); } catch (e) { reject(e); return; }
        var secure = p.protocol === 'https:';
        if (!secure && !(o.allowHttp && p.protocol === 'http:')) { reject(new Error('Blocked non-HTTPS address')); return; }
        if (!o.anyHost && HOSTS.indexOf(p.hostname) < 0) { reject(new Error('Blocked host: ' + p.hostname)); return; }
        var req = (secure ? https : http).get({
          hostname: p.hostname, port: p.port, path: p.path,
          headers: { 'User-Agent': 'L4XYVS-Updater', 'Cache-Control': 'no-cache' }
        }, function (res) {
          if ([301, 302, 303, 307, 308].indexOf(res.statusCode) >= 0 && res.headers.location) {
            res.resume();
            if (++hops > 5) { reject(new Error('Too many redirects')); return; }
            go(urlMod.resolve(u, res.headers.location)); return;
          }
          if (res.statusCode !== 200) { res.resume(); reject(new Error('Server replied HTTP ' + res.statusCode)); return; }
          var total = +res.headers['content-length'] || 0, got = 0, chunks = [], max = o.maxBytes || MAX_PKG;
          res.on('data', function (c) {
            got += c.length;
            if (got > max) { req.abort(); reject(new Error('Download too large')); return; }
            chunks.push(c);
            if (o.onProgress && total) o.onProgress(Math.min(1, got / total));
          });
          res.on('end', function () { resolve(Buffer.concat(chunks)); });
          res.on('error', reject);
        });
        req.setTimeout(o.timeout || 25000, function () { req.abort(); reject(new Error('Connection timed out')); });
        req.on('error', reject);
      })(url);
    });
  }

  /* ---------- zip (central-directory reader, no dependencies) ---------- */
  function readZip(buf) {
    var min = Math.max(0, buf.length - 22 - 65535), i = buf.length - 22;
    for (; i >= min; i--) if (buf.readUInt32LE(i) === 0x06054b50) break;
    if (i < min) throw new Error('Package is not a valid zip');
    var count = buf.readUInt16LE(i + 10), p = buf.readUInt32LE(i + 16), out = [];
    for (var n = 0; n < count; n++) {
      if (buf.readUInt32LE(p) !== 0x02014b50) throw new Error('Corrupt zip directory');
      var nl = buf.readUInt16LE(p + 28), el = buf.readUInt16LE(p + 30), cl = buf.readUInt16LE(p + 32);
      var e = {
        method: buf.readUInt16LE(p + 10), csize: buf.readUInt32LE(p + 20), usize: buf.readUInt32LE(p + 24),
        lho: buf.readUInt32LE(p + 42), name: buf.toString('utf8', p + 46, p + 46 + nl)
      };
      if (e.csize === 0xFFFFFFFF || e.usize === 0xFFFFFFFF || e.lho === 0xFFFFFFFF) throw new Error('Zip64 packages are not supported');
      out.push(e); p += 46 + nl + el + cl;
    }
    return out;
  }
  function zipData(buf, e) {
    var l = e.lho;
    if (buf.readUInt32LE(l) !== 0x04034b50) throw new Error('Corrupt zip entry');
    var s = l + 30 + buf.readUInt16LE(l + 26) + buf.readUInt16LE(l + 28), raw = buf.slice(s, s + e.csize), d;
    if (e.method === 0) d = raw;
    else if (e.method === 8) d = zlib.inflateRawSync(raw);
    else throw new Error('Unsupported zip compression');
    if (d.length !== e.usize) throw new Error('Zip entry size mismatch: ' + e.name);
    return d;
  }
  function safeRel(name) {
    var n = String(name).replace(/\\/g, '/');
    if (n.indexOf(PKG_PREFIX) !== 0) throw new Error('Unexpected file in package: ' + name);
    n = n.slice(PKG_PREFIX.length);
    var parts = n.split('/');
    for (var i = 0; i < parts.length; i++) {
      if (parts[i] === '' && i === parts.length - 1) continue;          /* trailing slash = directory */
      if (!parts[i] || parts[i] === '.' || parts[i] === '..' || /[:*?"<>|\x00-\x1f]/.test(parts[i])) throw new Error('Unsafe path in package: ' + name);
    }
    return n;
  }

  /* ---------- fs helpers ---------- */
  function mkdirp(d) { if (fs.existsSync(d)) return; mkdirp(path.dirname(d)); try { fs.mkdirSync(d); } catch (e) { if (!fs.existsSync(d)) throw e; } }
  function rmrf(p) {
    if (!fs.existsSync(p)) return;
    if (fs.lstatSync(p).isDirectory()) { fs.readdirSync(p).forEach(function (f) { rmrf(path.join(p, f)); }); fs.rmdirSync(p); }
    else fs.unlinkSync(p);
  }
  function inside(root, target) {
    var r = path.resolve(root), t = path.resolve(target);
    return t === r || t.indexOf(r + path.sep) === 0;
  }

  /* ---------- core ---------- */
  function create(opts) {
    var root = opts.root, feedUrl = opts.feedUrl || FEED_URL, net = { allowHttp: !!opts.allowHttp, anyHost: !!opts.anyHost };

    function currentVersion() {
      var d = JSON.parse(fs.readFileSync(path.join(root, 'version.json'), 'utf8').replace(/^\uFEFF/, ''));
      if (!parseVer(d.version)) throw new Error('version.json is invalid');
      return d.version;
    }
    function pubKey() {
      var f = path.join(root, 'updater_pubkey.pem');
      if (!fs.existsSync(f)) return '';
      var k = fs.readFileSync(f, 'utf8');
      return /BEGIN PUBLIC KEY/.test(k) ? k : '';
    }

    function check() {
      var current = currentVersion();
      return httpGet(feedUrl + (feedUrl.indexOf('?') < 0 ? '?t=' + Date.now() : ''), { maxBytes: 200000, timeout: 15000, allowHttp: net.allowHttp, anyHost: net.anyHost })
        .then(function (b) {
          var f;
          try { f = JSON.parse(b.toString('utf8').replace(/^\uFEFF/, '')); } catch (e) { throw new Error('Update feed is not valid JSON'); }
          if (f.product !== PRODUCT) throw new Error('Update feed is for a different product');
          if (!parseVer(f.version)) throw new Error('Update feed has a bad version');
          var res = { current: current, latest: f.version, available: cmpVer(f.version, current) > 0, required: false, info: f };
          if (res.available && f.minimumVersion && parseVer(f.minimumVersion)) res.required = cmpVer(current, f.minimumVersion) < 0;
          return res;
        });
    }

    function install(info, progress) {
      progress = progress || function () {};
      var current = currentVersion();
      if (cmpVer(info.version, current) <= 0) return Promise.reject(new Error('That version is not newer than the installed one'));
      var key = pubKey();
      if (!key) return Promise.reject(new Error('updater_pubkey.pem is missing, updates are disabled'));
      var sha = String(info.sha256 || '').toLowerCase();
      if (!/^[0-9a-f]{64}$/.test(sha)) return Promise.reject(new Error('Update feed has no SHA-256'));
      if (!info.signature) return Promise.reject(new Error('Update feed is not signed'));
      if (!info.packageUrl) return Promise.reject(new Error('Update feed has no package address'));

      progress('Downloading', 0);
      var backup = path.join(os.tmpdir(), 'l4xyvs_backup_' + Date.now()), done = [];
      return httpGet(info.packageUrl, { allowHttp: net.allowHttp, anyHost: net.anyHost, onProgress: function (p) { progress('Downloading', p * 0.7); } })
        .then(function (buf) {
          progress('Verifying', 0.72);
          if (crypto.createHash('sha256').update(buf).digest('hex') !== sha) throw new Error('Download is corrupted (checksum mismatch)');
          var ok = false;
          try { ok = crypto.createVerify('RSA-SHA256').update('L4XYVS-SUITE|' + info.version + '|' + sha).verify(key, String(info.signature), 'base64'); } catch (e) { ok = false; }
          if (!ok) throw new Error('Signature check failed. Update rejected.');

          progress('Unpacking', 0.78);
          var files = [], total = 0;
          readZip(buf).forEach(function (e) {
            var rel = safeRel(e.name);
            if (rel === '' || rel.slice(-1) === '/') return;
            total += e.usize; if (total > MAX_UNPACKED) throw new Error('Package is too large when unpacked');
            var target = path.join(root, rel);
            if (!inside(root, target)) throw new Error('Unsafe path in package: ' + e.name);
            files.push({ rel: rel, target: target, data: zipData(buf, e) });
          });
          REQUIRED_FILES.forEach(function (r) { if (!files.some(function (f) { return f.rel === r; })) throw new Error('Package is incomplete (' + r + ')'); });
          var vf = files.filter(function (f) { return f.rel === 'version.json'; })[0];
          var pv = JSON.parse(vf.data.toString('utf8').replace(/^\uFEFF/, '')).version;
          if (pv !== info.version) throw new Error('Package version does not match the feed');
          files.sort(function (a, b) { return (a.rel === 'version.json') - (b.rel === 'version.json'); });   /* version.json last */

          progress('Installing', 0.85);
          var changed = [];
          try {
            files.forEach(function (f) {
              var had = fs.existsSync(f.target);
              if (had && fs.statSync(f.target).isFile() && fs.readFileSync(f.target).equals(f.data)) return;   /* unchanged */
              if (had) { var b = path.join(backup, f.rel); mkdirp(path.dirname(b)); fs.copyFileSync(f.target, b); }
              mkdirp(path.dirname(f.target));
              var tmp = f.target + '.l4new';
              fs.writeFileSync(tmp, f.data); fs.renameSync(tmp, f.target);
              done.push({ target: f.target, backup: had ? path.join(backup, f.rel) : null, rel: f.rel });
              changed.push(f.rel);
            });
          } catch (err) {
            for (var i = done.length - 1; i >= 0; i--) {
              try { if (done[i].backup) fs.copyFileSync(done[i].backup, done[i].target); else fs.unlinkSync(done[i].target); } catch (e2) {}
            }
            try { rmrf(backup); } catch (e3) {}
            throw new Error('Install failed and was rolled back: ' + err.message);
          }
          try { rmrf(backup); } catch (e4) {}
          progress('Done', 1);
          return {
            from: current, to: info.version, changed: changed,
            restartRequired: changed.some(function (r) { return /^(jsx|CSXS|tools)\//.test(r); })
          };
        });
    }

    return { check: check, install: install, currentVersion: currentVersion };
  }

  var api = { create: create, cmpVer: cmpVer, parseVer: parseVer, readZip: readZip, safeRel: safeRel, FEED_URL: FEED_URL };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  if (typeof window === 'undefined' || typeof document === 'undefined') return;
  window.L4Updater = api;

  /* ---------- panel UI ---------- */
  function $(id) { return document.getElementById(id); }
  function extRoot() {
    try {
      var p = decodeURI(window.__adobe_cep__.getSystemPath('extension').replace(/^file:\/\//, ''));
      if (/^\/[A-Za-z]:/.test(p)) p = p.slice(1);
      return p;
    } catch (e) {
      try { var q = decodeURI(location.pathname).replace(/\/[^\/]*$/, ''); if (/^\/[A-Za-z]:/.test(q)) q = q.slice(1); return q; } catch (e2) { return ''; }
    }
  }
  var tt;
  function say(m) { var t = $('toast'); if (!t) return; t.textContent = m; t.classList.add('show'); clearTimeout(tt); tt = setTimeout(function () { t.classList.remove('show'); }, 2800); }
  function jobRunning() { var p = $('prog'); return !!p && !p.classList.contains('hidden'); }

  function boot() {
    if (!hasNode) return;
    var U, pending = null, busy = false, dismissed = '';
    try { U = create({ root: extRoot() }); U.currentVersion(); } catch (e) { return; }

    var bar = $('updateBar'), txt = $('updText'), sub = $('updSub'), btn = $('updGo'), later = $('updLater'), fill = $('updFill'), wrap = $('updProg');
    function showVer() { var v = $('verText'); if (v) { try { v.textContent = 'Version ' + U.currentVersion(); } catch (e) {} } }
    function setBar(state, o) {
      o = o || {};
      bar.classList.remove('hidden'); bar.setAttribute('data-state', state);
      txt.textContent = o.title || ''; sub.textContent = o.sub || '';
      btn.textContent = o.btn || ''; btn.classList.toggle('hidden', !o.btn); btn.disabled = !!o.disabled;
      later.classList.toggle('hidden', !o.later);
      wrap.classList.toggle('hidden', state !== 'busy');
      btn.onclick = o.onBtn || null;
    }
    function hide() { bar.classList.add('hidden'); }

    function offer(r) {
      pending = r.info;
      var notes = String(r.info.releaseNotes || '').slice(0, 140);
      setBar('available', {
        title: (r.required ? 'Required update ' : 'Update ') + r.latest + ' available',
        sub: notes || ('You have ' + r.current), btn: 'Update', later: !r.required, onBtn: doInstall
      });
    }
    function doCheck(manual) {
      if (busy) return Promise.resolve();
      if (manual) say('Checking for updates');
      return U.check().then(function (r) {
        showVer();
        if (r.available) { if (manual || dismissed !== r.latest) offer(r); }
        else if (manual) say('You are up to date (v' + r.current + ')');
      }).catch(function (e) { if (manual) say('Update check failed: ' + e.message); });
    }
    function doInstall() {
      if (busy || !pending) return;
      if (jobRunning()) { say('Wait for the caption job to finish first'); return; }
      busy = true;
      setBar('busy', { title: 'Updating to ' + pending.version, sub: 'Starting', disabled: true });
      U.install(pending, function (stage, p) { sub.textContent = stage; fill.style.transform = 'scaleX(' + p + ')'; })
        .then(function (res) {
          busy = false; pending = null; showVer();
          if (!res.changed.length) { setBar('done', { title: 'Already up to date', sub: '' }); setTimeout(hide, 2500); return; }
          if (res.restartRequired) setBar('done', { title: 'Updated to ' + res.to, sub: 'Restart After Effects to finish.' });
          else setBar('done', { title: 'Updated to ' + res.to, sub: 'Reload the panel to apply.', btn: 'Reload panel', onBtn: function () { location.reload(); } });
        })
        .catch(function (e) {
          busy = false;
          var r = pending;
          setBar('error', { title: 'Update failed', sub: e.message, btn: 'Retry', later: true, onBtn: doInstall });
          pending = r;
        });
    }

    later.onclick = function () { if (pending) dismissed = pending.version; hide(); };
    var cb = $('btnCheckUpd'); if (cb) cb.onclick = function () { doCheck(true); };
    showVer();
    setTimeout(function () { doCheck(false); }, 2500);
    setInterval(function () { doCheck(false); }, CHECK_EVERY_MS);
  }
  document.addEventListener('DOMContentLoaded', boot);
})();
